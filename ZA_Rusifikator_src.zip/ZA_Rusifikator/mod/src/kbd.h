// ZAPad keyboard lighting: ASUS Aura SDK (Armoury Crate) or Windows Dynamic Lighting.
#pragma once
#include <cstdint>

namespace KB {
enum Backend { Off = 0, Aura = 1, Windows = 2 };
enum Ev { Fire, Hit, Reload, Swap, Death, Revive, Ability, TargetStart, UiSelect, UiConfirm, UiTab, FxRaw };
// game sound events that get their own lighting (and speaker sound)
enum Fx { FxNone, FxAdrenaline, FxBiocleanse, FxDash, FxDieAnotherDay, FxHaven, FxHoldTheLine, FxKinetic, FxMedkit, FxOrbitalAim, FxOrbitalFire, FxEquip, FxCooldown, FxTurret, FxGrenade };
enum AbSt { AbNone = -1, AbReady = 0, AbCharging = 1, AbActive = 2, AbCooldown = 3, AbOut = 4 };

struct State {
    bool inGame = false, mission = false, dead = false, targeting = false, reloading = false, moving = false;
    int downed = 0;
    float hp = 1, hpMax = 1, sh = 0, shMax = 0;
    int mag = 0, magMax = 0;
    int abCount = 0; int ab[3] = {AbNone, AbNone, AbNone};
};

using LogFn = void (*)(const char* fmt, ...);
void Start(int backend, int brightness, LogFn log, const wchar_t* dir);   // starts the lighting thread (no-op for Off)
void Update(const State& s);                          // any thread, cheap
void Event(Ev e, float a = 0, int i = 0);             // any thread, cheap
}
