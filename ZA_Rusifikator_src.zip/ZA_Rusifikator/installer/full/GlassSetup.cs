// Мастер установки русификатора «Зомби-штурм: Пробуждение» (Zombie Assault: Resurgence), by MeT1oR & Tianku
// Интерфейс в стиле «жидкого стекла»: акриловый фон Windows 11 (DWM), полупрозрачные панели, стеклянные кнопки.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shell;
using Microsoft.Win32;

[assembly: AssemblyTitle("Русификатор «Зомби-штурм: Пробуждение»")]
[assembly: AssemblyDescription("Русификатор Zombie Assault: Resurgence")]
[assembly: AssemblyCompany("MeT1oR & Tianku")]
[assembly: AssemblyProduct("Русификатор «Зомби-штурм: Пробуждение»")]
[assembly: AssemblyCopyright("MeT1oR & Tianku")]
[assembly: AssemblyVersion("4.0.0.0")]
[assembly: AssemblyFileVersion("4.0.0.0")]

namespace ZaSetup
{
    public class GlassWizard : Window
    {
        const string AppTitle = "Русификатор «Зомби-штурм: Пробуждение»";
        const string RegKey = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\ZA_Rusifikator";
        readonly bool uninstallMode;
        int page;
        bool busy, success, glass, closingOk;
        readonly Installer inst = new Installer();
        FrameworkElement root;
        Grid[] pages;
        Button bBack, bNext, bCancel;
        TextBox tPath; TextBlock lPathState, lTitle, lSub, lStatus, lFinTitle, lFinText, tReady, lPadReq;
        RadioButton rEn, rPt, rAuthor, rExact, rUi, rNamesRu, rNamesEn, rPadNone, rPadAuto, rPadDs, rPadXbox, rKbNone, rKbAura, rKbWin;
        CheckBox cLogos, cTex, cDiscord, cDlaa, cRunGame;
        ProgressBar bar; ListBox log; FrameworkElement gPadReq, lnkPs, lnkXb, side, header;

        static Stream Res(string n) { return Assembly.GetExecutingAssembly().GetManifestResourceStream(n); }

        // ------------------------------------------------------------------ sounds from the game: menu music, click, confirm
        MediaPlayer music; readonly MediaPlayer[] sfxClick = new MediaPlayer[3]; MediaPlayer sfxNext; int sfxI; bool musicOn = true;
        static string SndFile(string n)
        {
            string d = Path.Combine(Path.GetTempPath(), "ZA_Setup_snd"); Directory.CreateDirectory(d);
            string f = Path.Combine(d, n);
            try { using (var r = Res(n)) { if (r == null) return null; if (!File.Exists(f) || new FileInfo(f).Length != r.Length) using (var w = File.Create(f)) r.CopyTo(w); } } catch { }
            return File.Exists(f) ? f : null;
        }
        static MediaPlayer Player(string n, double vol)
        {
            string f = SndFile(n); if (f == null) return null;
            var p = new MediaPlayer(); p.Open(new Uri(f)); p.Volume = vol; return p;
        }
        void InitSound()
        {
            try { using (var k = Registry.CurrentUser.OpenSubKey(@"Software\ZA_Rusifikator")) if (k != null && (k.GetValue("MusicOff") as int? ?? 0) == 1) musicOn = false; } catch { }
            for (int i = 0; i < sfxClick.Length; ++i) sfxClick[i] = Player("snd_click.wav", 0.55);
            sfxNext = Player("snd_next.wav", 0.6);
            music = Player("music.mp3", 0.45);
            if (music != null && musicOn) music.Play();   // the game's logo theme, once when the installer opens
            var bm = F<Button>("bMusic"); bm.Content = musicOn ? "\uE767" : "\uE74F"; bm.Opacity = musicOn ? 1 : 0.6;
            bm.Click += (s, e) =>
            {
                musicOn = !musicOn; bm.Content = musicOn ? "\uE767" : "\uE74F"; bm.Opacity = musicOn ? 1 : 0.6;
                if (music != null) { if (musicOn) music.Play(); else music.Pause(); }
                try { using (var k = Registry.CurrentUser.CreateSubKey(@"Software\ZA_Rusifikator")) k.SetValue("MusicOff", musicOn ? 0 : 1, RegistryValueKind.DWord); } catch { }
            };
            // every button / tick / switch: the game's click; "Далее" / "Установить": the game's confirm
            root.AddHandler(ButtonBase.ClickEvent, new RoutedEventHandler((s, e) =>
            {
                var src = e.OriginalSource as FrameworkElement; if (src == null || src.Name == "bMusic") return;
                if (src == bNext) Play(sfxNext); else Play(sfxClick[sfxI++ % sfxClick.Length]);
            }), true);
        }
        static void Play(MediaPlayer p) { if (p == null) return; p.Stop(); p.Position = TimeSpan.Zero; p.Play(); }
        static BitmapImage Img(string n)
        {
            var b = new BitmapImage(); b.BeginInit(); b.StreamSource = Res(n); b.CacheOption = BitmapCacheOption.OnLoad; b.EndInit(); b.Freeze(); return b;
        }

        // ------------------------------------------------------------------ XAML
        const string Styles = @"
<ResourceDictionary xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'>
  <Color x:Key='Accent'>#FFFF8A1F</Color>
  <SolidColorBrush x:Key='AccentBrush' Color='#FFFF8A1F'/>
  <SolidColorBrush x:Key='Fg' Color='#F2FFFFFF'/>
  <SolidColorBrush x:Key='Dim' Color='#A8FFFFFF'/>
  <LinearGradientBrush x:Key='GlassFill' StartPoint='0,0' EndPoint='0,1'>
    <GradientStop Color='#30FFFFFF' Offset='0'/><GradientStop Color='#14FFFFFF' Offset='0.55'/><GradientStop Color='#1CFFFFFF' Offset='1'/>
  </LinearGradientBrush>
  <LinearGradientBrush x:Key='GlassEdge' StartPoint='0,0' EndPoint='1,1'>
    <GradientStop Color='#A0FFFFFF' Offset='0'/><GradientStop Color='#18FFFFFF' Offset='0.45'/><GradientStop Color='#10FFFFFF' Offset='0.6'/><GradientStop Color='#60FFFFFF' Offset='1'/>
  </LinearGradientBrush>
  <LinearGradientBrush x:Key='Sheen' StartPoint='0,0' EndPoint='0,1'>
    <GradientStop Color='#38FFFFFF' Offset='0'/><GradientStop Color='#00FFFFFF' Offset='0.5'/>
  </LinearGradientBrush>
  <LinearGradientBrush x:Key='Rim' StartPoint='0,0' EndPoint='0,1'>
    <GradientStop Color='#E6FFFFFF' Offset='0'/><GradientStop Color='#30FFFFFF' Offset='0.35'/><GradientStop Color='#10FFFFFF' Offset='0.65'/><GradientStop Color='#70FFFFFF' Offset='1'/>
  </LinearGradientBrush>
  <LinearGradientBrush x:Key='Gloss' StartPoint='0,0' EndPoint='0,1'>
    <GradientStop Color='#70FFFFFF' Offset='0'/><GradientStop Color='#18FFFFFF' Offset='0.48'/><GradientStop Color='#00FFFFFF' Offset='0.5'/>
  </LinearGradientBrush>
  <RadialGradientBrush x:Key='Glow' Center='0.5,1.1' GradientOrigin='0.5,1.1' RadiusX='0.7' RadiusY='0.9'>
    <GradientStop Color='#40FFFFFF' Offset='0'/><GradientStop Color='#00FFFFFF' Offset='1'/>
  </RadialGradientBrush>
  <LinearGradientBrush x:Key='LqRimC' StartPoint='0,0' EndPoint='1,1'>
    <GradientStop Color='#E0FFFFFF' Offset='0'/><GradientStop Color='#28FFFFFF' Offset='0.45'/><GradientStop Color='#90FFFFFF' Offset='1'/>
  </LinearGradientBrush>
  <Style x:Key='Card' TargetType='Border'>
    <Setter Property='CornerRadius' Value='16'/><Setter Property='BorderThickness' Value='1'/>
    <Setter Property='Background' Value='#24FFFFFF'/><Setter Property='BorderBrush' Value='{StaticResource LqRimC}'/>
    <Setter Property='Padding' Value='16,12'/><Setter Property='Margin' Value='0,0,0,10'/>
  </Style>
  <Style x:Key='CardTitle' TargetType='TextBlock'>
    <Setter Property='Foreground' Value='{StaticResource Dim}'/><Setter Property='FontSize' Value='12'/><Setter Property='FontWeight' Value='SemiBold'/><Setter Property='Margin' Value='0,0,0,6'/>
  </Style>
  <Style x:Key='Note' TargetType='TextBlock'>
    <Setter Property='Foreground' Value='{StaticResource Dim}'/><Setter Property='FontSize' Value='12'/><Setter Property='TextWrapping' Value='Wrap'/><Setter Property='Margin' Value='28,0,0,4'/>
  </Style>
  <Style TargetType='TextBlock'><Setter Property='Foreground' Value='{StaticResource Fg}'/><Setter Property='TextWrapping' Value='Wrap'/></Style>

  <Style TargetType='RadioButton'>
    <Setter Property='Foreground' Value='{StaticResource Fg}'/><Setter Property='Margin' Value='0,3'/><Setter Property='Cursor' Value='Hand'/>
    <Setter Property='Template'><Setter.Value>
      <ControlTemplate TargetType='RadioButton'>
        <Grid Background='Transparent'><Grid.ColumnDefinitions><ColumnDefinition Width='Auto'/><ColumnDefinition/></Grid.ColumnDefinitions>
          <Grid Width='18' Height='18' VerticalAlignment='Top' Margin='0,1,10,0'>
            <Ellipse x:Name='o' Fill='#26FFFFFF' Stroke='{StaticResource LqRimC}' StrokeThickness='1'/>
            <Ellipse x:Name='d' Width='8' Height='8' Fill='White' Opacity='0'/>
          </Grid>
          <ContentPresenter Grid.Column='1' VerticalAlignment='Center' RecognizesAccessKey='False'/>
        </Grid>
        <ControlTemplate.Triggers>
          <Trigger Property='IsChecked' Value='True'><Setter TargetName='o' Property='Fill' Value='{StaticResource AccentBrush}'/><Setter TargetName='o' Property='Stroke' Value='#FFFFC38A'/><Setter TargetName='d' Property='Opacity' Value='1'/></Trigger>
          <Trigger Property='IsMouseOver' Value='True'><Setter TargetName='o' Property='Stroke' Value='White'/></Trigger>
          <Trigger Property='IsEnabled' Value='False'><Setter Property='Opacity' Value='0.45'/></Trigger>
        </ControlTemplate.Triggers>
      </ControlTemplate></Setter.Value></Setter>
  </Style>

  <Style TargetType='CheckBox'>
    <Setter Property='Foreground' Value='{StaticResource Fg}'/><Setter Property='Margin' Value='0,3'/><Setter Property='Cursor' Value='Hand'/>
    <Setter Property='Template'><Setter.Value>
      <ControlTemplate TargetType='CheckBox'>
        <Grid Background='Transparent'><Grid.ColumnDefinitions><ColumnDefinition Width='Auto'/><ColumnDefinition/></Grid.ColumnDefinitions>
          <Grid Width='34' Height='20' VerticalAlignment='Top' Margin='0,0,10,0'>
            <Border x:Name='t' CornerRadius='10' Background='#26FFFFFF' BorderBrush='{StaticResource LqRimC}' BorderThickness='1'/>
            <Ellipse x:Name='k' Width='14' Height='14' HorizontalAlignment='Left' Margin='3,0,0,0'><Ellipse.Fill><LinearGradientBrush StartPoint='0,0' EndPoint='0,1'><GradientStop Color='#FFFFFFFF' Offset='0'/><GradientStop Color='#C8E8ECF4' Offset='1'/></LinearGradientBrush></Ellipse.Fill><Ellipse.Effect><DropShadowEffect BlurRadius='5' ShadowDepth='1' Opacity='0.45'/></Ellipse.Effect></Ellipse>
          </Grid>
          <ContentPresenter Grid.Column='1' VerticalAlignment='Center' RecognizesAccessKey='False'/>
        </Grid>
        <ControlTemplate.Triggers>
          <Trigger Property='IsChecked' Value='True'><Setter TargetName='t' Property='Background' Value='{StaticResource AccentBrush}'/><Setter TargetName='t' Property='BorderBrush' Value='#FFFFC38A'/><Setter TargetName='k' Property='HorizontalAlignment' Value='Right'/><Setter TargetName='k' Property='Margin' Value='0,0,3,0'/></Trigger>
          <Trigger Property='IsMouseOver' Value='True'><Setter TargetName='t' Property='BorderBrush' Value='White'/></Trigger>
          <Trigger Property='IsEnabled' Value='False'><Setter Property='Opacity' Value='0.45'/></Trigger>
        </ControlTemplate.Triggers>
      </ControlTemplate></Setter.Value></Setter>
  </Style>

  <LinearGradientBrush x:Key='LqRim' StartPoint='0,0' EndPoint='1,1'>
    <GradientStop Color='#D8FFFFFF' Offset='0'/><GradientStop Color='#30FFFFFF' Offset='0.22'/><GradientStop Color='#06FFFFFF' Offset='0.5'/><GradientStop Color='#30FFFFFF' Offset='0.78'/><GradientStop Color='#A0FFFFFF' Offset='1'/>
  </LinearGradientBrush>
  <LinearGradientBrush x:Key='LqInner' StartPoint='0,0' EndPoint='0,1'>
    <GradientStop Color='#22FFFFFF' Offset='0'/><GradientStop Color='#00FFFFFF' Offset='0.35'/><GradientStop Color='#00000000' Offset='0.7'/><GradientStop Color='#22000000' Offset='1'/>
  </LinearGradientBrush>
  <RadialGradientBrush x:Key='LqLens' Center='0.3,0.1' GradientOrigin='0.3,0.1' RadiusX='1.0' RadiusY='1.4'>
    <GradientStop Color='#66FFFFFF' Offset='0'/><GradientStop Color='#3CFFFFFF' Offset='1'/>
  </RadialGradientBrush>
  <Style x:Key='Pill' TargetType='Button'>
    <Setter Property='Foreground' Value='{StaticResource Fg}'/><Setter Property='FontSize' Value='13'/><Setter Property='Padding' Value='24,9'/><Setter Property='MinWidth' Value='112'/><Setter Property='Cursor' Value='Hand'/>
    <Setter Property='Tag' Value='#00FFFFFF'/>
    <Setter Property='Template'><Setter.Value>
      <ControlTemplate TargetType='Button'>
        <Grid x:Name='g' RenderTransformOrigin='0.5,0.5'>
          <Border CornerRadius='20' Background='#01000000'>
            <Border.Effect><DropShadowEffect BlurRadius='24' ShadowDepth='6' Direction='270' Opacity='0.28' Color='Black'/></Border.Effect>
          </Border>
          <Border x:Name='b' CornerRadius='20' Background='{StaticResource LqLens}'/>
          <Border x:Name='tint' CornerRadius='20' Background='{Binding Tag, RelativeSource={RelativeSource TemplatedParent}}'/>
          <Border CornerRadius='20' Background='{StaticResource LqInner}' IsHitTestVisible='False'/>
          <Border x:Name='rim' CornerRadius='20' BorderBrush='{StaticResource LqRim}' BorderThickness='1.3' IsHitTestVisible='False'/>
          <Border CornerRadius='19' Margin='1.5' BorderThickness='0.8' IsHitTestVisible='False'>
            <Border.BorderBrush><LinearGradientBrush StartPoint='0,0' EndPoint='0,1'><GradientStop Color='#50FFFFFF' Offset='0'/><GradientStop Color='#00FFFFFF' Offset='0.4'/></LinearGradientBrush></Border.BorderBrush>
          </Border>
          <ContentPresenter Margin='{TemplateBinding Padding}' HorizontalAlignment='Center' VerticalAlignment='Center' RecognizesAccessKey='False'><ContentPresenter.Effect><DropShadowEffect BlurRadius='6' ShadowDepth='0' Opacity='0.55' Color='Black'/></ContentPresenter.Effect></ContentPresenter>
        </Grid>
        <ControlTemplate.Triggers>
          <Trigger Property='IsMouseOver' Value='True'><Setter TargetName='b' Property='Background' Value='#80FFFFFF'/><Setter TargetName='rim' Property='BorderThickness' Value='1.6'/></Trigger>
          <Trigger Property='IsPressed' Value='True'><Setter TargetName='g' Property='RenderTransform'><Setter.Value><ScaleTransform ScaleX='0.965' ScaleY='0.965'/></Setter.Value></Setter></Trigger>
          <Trigger Property='IsEnabled' Value='False'><Setter Property='Opacity' Value='0.38'/></Trigger>
        </ControlTemplate.Triggers>
      </ControlTemplate></Setter.Value></Setter>
  </Style>
  <Style x:Key='PillAccent' TargetType='Button' BasedOn='{StaticResource Pill}'>
    <Setter Property='Foreground' Value='White'/><Setter Property='FontWeight' Value='SemiBold'/>
    <Setter Property='Tag'><Setter.Value>
      <LinearGradientBrush StartPoint='0,0' EndPoint='1,1'><GradientStop Color='#C8FF9A3C' Offset='0'/><GradientStop Color='#B0FF7300' Offset='1'/></LinearGradientBrush>
    </Setter.Value></Setter>
  </Style>
  <Style x:Key='Chrome' TargetType='Button'>
    <Setter Property='Width' Value='40'/><Setter Property='Height' Value='30'/><Setter Property='Foreground' Value='{StaticResource Fg}'/><Setter Property='FontFamily' Value='Segoe MDL2 Assets'/><Setter Property='FontSize' Value='10'/>
    <Setter Property='Template'><Setter.Value>
      <ControlTemplate TargetType='Button'>
        <Border x:Name='b' CornerRadius='8' Background='Transparent'><ContentPresenter HorizontalAlignment='Center' VerticalAlignment='Center'/></Border>
        <ControlTemplate.Triggers><Trigger Property='IsMouseOver' Value='True'><Setter TargetName='b' Property='Background' Value='#30FFFFFF'/></Trigger></ControlTemplate.Triggers>
      </ControlTemplate></Setter.Value></Setter>
  </Style>
  <Style TargetType='TextBox'>
    <Setter Property='Foreground' Value='{StaticResource Fg}'/><Setter Property='CaretBrush' Value='White'/><Setter Property='Padding' Value='10,6'/>
    <Setter Property='Template'><Setter.Value>
      <ControlTemplate TargetType='TextBox'>
        <Border CornerRadius='12' Background='#22000000' BorderBrush='{StaticResource GlassEdge}' BorderThickness='1'>
          <ScrollViewer x:Name='PART_ContentHost' Margin='{TemplateBinding Padding}'/>
        </Border>
      </ControlTemplate></Setter.Value></Setter>
  </Style>
  <Style TargetType='ProgressBar'>
    <Setter Property='Height' Value='12'/>
    <Setter Property='Template'><Setter.Value>
      <ControlTemplate TargetType='ProgressBar'>
        <Grid>
          <Border x:Name='PART_Track' CornerRadius='6' Background='#22FFFFFF' BorderBrush='#50FFFFFF' BorderThickness='1'/>
          <Border x:Name='PART_Indicator' CornerRadius='6' HorizontalAlignment='Left'>
            <Border.Background><LinearGradientBrush StartPoint='0,0' EndPoint='1,0'><GradientStop Color='#FFFFB066' Offset='0'/><GradientStop Color='#FFFF7A00' Offset='1'/></LinearGradientBrush></Border.Background>
          </Border>
        </Grid>
      </ControlTemplate></Setter.Value></Setter>
  </Style>
  <Style TargetType='ListBox'>
    <Setter Property='Background' Value='Transparent'/><Setter Property='BorderThickness' Value='0'/><Setter Property='Foreground' Value='{StaticResource Fg}'/>
    <Setter Property='ScrollViewer.HorizontalScrollBarVisibility' Value='Disabled'/>
  </Style>
  <Style TargetType='ListBoxItem'>
    <Setter Property='Template'><Setter.Value><ControlTemplate TargetType='ListBoxItem'><ContentPresenter Margin='0,1'/></ControlTemplate></Setter.Value></Setter>
  </Style>
  <Style TargetType='Hyperlink'><Setter Property='Foreground' Value='#FFFFB873'/></Style>
</ResourceDictionary>";

        static string Page(string name, string body) { return "<Grid x:Name='" + name + "' Visibility='Collapsed'>" + body + "</Grid>"; }

        string BuildXaml()
        {
            string welcome = Page("pWelcome", @"
  <ScrollViewer VerticalScrollBarVisibility='Auto'><StackPanel>
    <TextBlock FontSize='13' LineHeight='20'>Русификатор для Steam-версии Zombie Assault: Resurgence.</TextBlock>
    <Border Style='{StaticResource Card}' Margin='0,12,0,10'><TextBlock x:Name='tWelcome' LineHeight='20'/></Border>
    <TextBlock Foreground='{StaticResource Dim}'>Закройте игру перед установкой. Нажмите «Далее», чтобы продолжить.</TextBlock>
  </StackPanel></ScrollViewer>");
            string folder = Page("pFolder", @"
  <StackPanel>
    <Border Style='{StaticResource Card}'><StackPanel>
      <TextBlock Style='{StaticResource CardTitle}'>ПАПКА ИГРЫ</TextBlock>
      <TextBlock Margin='0,0,0,10' Foreground='{StaticResource Dim}'>Папка, в которой лежит zombieassault.exe. Обычно она находится сама. Если нет, нажмите «Обзор…».</TextBlock>
      <Grid><Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition Width='Auto'/></Grid.ColumnDefinitions>
        <TextBox x:Name='tPath' VerticalContentAlignment='Center'/>
        <Button x:Name='bBrowse' Grid.Column='1' Style='{StaticResource Pill}' Margin='10,0,0,0' Content='Обзор…'/>
      </Grid>
      <TextBlock x:Name='lPathState' Margin='2,10,0,0'/>
    </StackPanel></Border>
  </StackPanel>");
            string tr = Page("pTr", @"
  <ScrollViewer VerticalScrollBarVisibility='Auto'><StackPanel>
    <Border Style='{StaticResource Card}'><StackPanel>
      <TextBlock Style='{StaticResource CardTitle}'>ЯЗЫК В ИГРЕ</TextBlock>
      <RadioButton x:Name='rEn' GroupName='lang' IsChecked='True'>Русский вместо английского (рекомендуется)</RadioButton>
      <RadioButton x:Name='rPt' GroupName='lang'>Русский вместо португальского (английский останется, выбрать Português)</RadioButton>
    </StackPanel></Border>
    <Border Style='{StaticResource Card}'><StackPanel>
      <TextBlock Style='{StaticResource CardTitle}'>ВАРИАНТ ПЕРЕВОДА</TextBlock>
      <RadioButton x:Name='rAuthor' GroupName='var' IsChecked='True'>Авторский: ручной, с отсебятиной (рекомендуется)</RadioButton>
      <TextBlock Style='{StaticResource Note}'>Живой язык, шутки и мат там, где они к месту.</TextBlock>
      <RadioButton x:Name='rExact' GroupName='var'>Точный: максимально близко к оригиналу</RadioButton>
      <TextBlock Style='{StaticResource Note}'>Дословно, как в английской версии. Непереводимые шутки остаются на английском.</TextBlock>
      <RadioButton x:Name='rUi' GroupName='var'>Только интерфейс: меню, снаряжение, задания</RadioButton>
      <TextBlock Style='{StaticResource Note}'>Сюжет и диалоги на английском.</TextBlock>
    </StackPanel></Border>
    <Border Style='{StaticResource Card}'><StackPanel>
      <TextBlock Style='{StaticResource CardTitle}'>НАЗВАНИЯ КОМПАНИЙ И СНАРЯЖЕНИЯ</TextBlock>
      <RadioButton x:Name='rNamesRu' GroupName='names' IsChecked='True'>Русские: «Рубикон», «Морлок», «Феникс», СОС</RadioButton>
      <RadioButton x:Name='rNamesEn' GroupName='names'>Английские, как в оригинале: Rubicon, Morlok, Regen, USI</RadioButton>
    </StackPanel></Border>
  </StackPanel></ScrollViewer>");
            string opts = Page("pOpt", @"
  <ScrollViewer VerticalScrollBarVisibility='Auto'><StackPanel>
    <Border Style='{StaticResource Card}'><StackPanel>
      <TextBlock Style='{StaticResource CardTitle}'>КАРТИНКИ</TextBlock>
      <CheckBox x:Name='cLogos' IsChecked='True'>Русские логотипы компаний и картинки интерфейса</CheckBox>
      <CheckBox x:Name='cTex' IsChecked='True'>Русские надписи на текстурах (уровни, броня, оружие, турели)</CheckBox>
    </StackPanel></Border>
    <Border Style='{StaticResource Card}'><Grid><Grid.ColumnDefinitions><ColumnDefinition Width='Auto'/><ColumnDefinition/></Grid.ColumnDefinitions>
      <Image x:Name='iDiscord' Width='40' Height='40' Margin='0,0,14,0' VerticalAlignment='Center'/>
      <StackPanel Grid.Column='1'>
        <TextBlock Style='{StaticResource CardTitle}'>DISCORD</TextBlock>
        <CheckBox x:Name='cDiscord'>Статус в Discord: персонаж, класс и уровень</CheckBox>
        <TextBlock Style='{StaticResource Note}' Margin='44,0,0,0'>Дописывается к статусу игры, например «Медик, 12 ур.»</TextBlock>
      </StackPanel></Grid></Border>
    <Border Style='{StaticResource Card}'><Grid><Grid.ColumnDefinitions><ColumnDefinition Width='Auto'/><ColumnDefinition/></Grid.ColumnDefinitions>
      <Image x:Name='iDlss' Width='96' Height='32' Margin='0,0,14,0' VerticalAlignment='Center'/>
      <StackPanel Grid.Column='1'>
        <TextBlock Style='{StaticResource CardTitle}'>СГЛАЖИВАНИЕ NVIDIA DLAA (DLSS 4.5)</TextBlock>
        <CheckBox x:Name='cDlaa'>DLAA вместо сглаживания игры</CheckBox>
        <TextBlock Style='{StaticResource Note}' Margin='44,0,0,0'>Только видеокарты NVIDIA GeForce RTX. Модель DLSS 4.5 (пресет L). В игре Ctrl+F12 включает и выключает DLAA на лету.</TextBlock>
        <Border CornerRadius='12' ClipToBounds='True' Margin='44,8,0,0' HorizontalAlignment='Left' BorderBrush='{StaticResource LqRimC}' BorderThickness='1'>
          <Image x:Name='gDlaa' Width='384' Height='216' Stretch='UniformToFill'/>
        </Border>
      </StackPanel></Grid></Border>
  </StackPanel></ScrollViewer>");
            string dev = Page("pDev", @"
  <ScrollViewer VerticalScrollBarVisibility='Auto'><StackPanel>
    <Border Style='{StaticResource Card}'><StackPanel>
      <TextBlock Style='{StaticResource CardTitle}'>ГЕЙМПАД</TextBlock>
      <RadioButton x:Name='rPadNone' GroupName='pad'>Не устанавливать</RadioButton>
      <RadioButton x:Name='rPadAuto' GroupName='pad' IsChecked='True'>Автоматически: DualSense или Xbox, какой подключён (рекомендуется)</RadioButton>
      <RadioButton x:Name='rPadDs' GroupName='pad'>Только DualSense: триггеры, HD-вибрация, подсветка, динамик, гироскоп</RadioButton>
      <RadioButton x:Name='rPadXbox' GroupName='pad'>Только Xbox: вибрация и импульсные триггеры</RadioButton>
      <StackPanel Orientation='Horizontal' Margin='0,10,0,0'>
        <Border CornerRadius='12' ClipToBounds='True' BorderBrush='{StaticResource LqRimC}' BorderThickness='1' Margin='0,0,10,0'><Image x:Name='gDs' Width='288' Height='162'/></Border>
        <Border CornerRadius='12' ClipToBounds='True' BorderBrush='{StaticResource LqRimC}' BorderThickness='1'><Image x:Name='gXb' Width='288' Height='162'/></Border>
      </StackPanel>
    </StackPanel></Border>
    <Border Style='{StaticResource Card}'><StackPanel>
      <TextBlock Style='{StaticResource CardTitle}'>ПОДСВЕТКА КЛАВИАТУРЫ</TextBlock>
      <RadioButton x:Name='rKbNone' GroupName='kb' IsChecked='True'>Не устанавливать</RadioButton>
      <Grid><RadioButton x:Name='rKbAura' GroupName='kb' Margin='0,3,40,3'>ASUS Aura: клавиатуры ASUS (нужен Armoury Crate)</RadioButton>
        <Image x:Name='iAura' Width='26' Height='26' HorizontalAlignment='Right'/></Grid>
      <Grid><RadioButton x:Name='rKbWin' GroupName='kb' Margin='0,3,40,3'>Динамическая подсветка Windows: любые клавиатуры с её поддержкой</RadioButton>
        <Image x:Name='iDl' Width='26' Height='26' HorizontalAlignment='Right'/></Grid>
      <TextBlock Style='{StaticResource Note}'>Здоровье на F1–F12, щит над стрелками, способности, перезарядка и эффекты на всю клавиатуру. Для подсветки Windows включите её: Параметры > Персонализация > Динамическое освещение.</TextBlock>
    </StackPanel></Border>
  </StackPanel></ScrollViewer>");
            string ready = Page("pReady", @"
  <Grid><Grid.RowDefinitions><RowDefinition/><RowDefinition Height='Auto'/></Grid.RowDefinitions>
    <Border Style='{StaticResource Card}'><ScrollViewer VerticalScrollBarVisibility='Auto'><TextBlock x:Name='tReady' LineHeight='19'/></ScrollViewer></Border>
    <Border x:Name='gPadReq' Grid.Row='1' Style='{StaticResource Card}' Margin='0'><StackPanel>
      <TextBlock Style='{StaticResource CardTitle}'>ЧТО НУЖНО ДЛЯ МОДА ГЕЙМПАДА</TextBlock>
      <TextBlock x:Name='lPadReq' LineHeight='19'/>
      <TextBlock x:Name='lnkPs' Margin='0,6,0,0'><Hyperlink x:Name='hPs'>PlayStation® Accessories: прошивка DualSense (сайт Sony)</Hyperlink></TextBlock>
      <TextBlock x:Name='lnkXb' Margin='0,4,0,0'><Hyperlink x:Name='hXb'>Аксессуары Xbox: прошивка Xbox-геймпада (Microsoft Store)</Hyperlink></TextBlock>
    </StackPanel></Border>
  </Grid>");
            string prog = Page("pProg", @"
  <Grid><Grid.RowDefinitions><RowDefinition Height='Auto'/><RowDefinition Height='Auto'/><RowDefinition/></Grid.RowDefinitions>
    <TextBlock x:Name='lStatus' Margin='2,0,0,8' TextTrimming='CharacterEllipsis' TextWrapping='NoWrap'/>
    <ProgressBar x:Name='bar' Grid.Row='1' Maximum='100' Margin='0,0,0,12'/>
    <Border Grid.Row='2' Style='{StaticResource Card}' Margin='0'><ListBox x:Name='log' FontSize='12'/></Border>
  </Grid>");
            string fin = Page("pFin", @"
  <StackPanel>
    <TextBlock x:Name='lFinTitle' FontSize='22' FontWeight='SemiBold' Margin='0,0,0,12'/>
    <Border Style='{StaticResource Card}'><TextBlock x:Name='lFinText' LineHeight='20'/></Border>
    <CheckBox x:Name='cRunGame' Margin='4,6,0,0'>Запустить игру</CheckBox>
  </StackPanel>");

            return @"
<Grid xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'
      xmlns:shell='clr-namespace:System.Windows.Shell;assembly=PresentationFramework' TextElement.FontSize='13'>
  <Grid.Resources>" + Styles + @"</Grid.Resources>
  <Grid.Background>
    <DrawingBrush Stretch='Fill'><DrawingBrush.Drawing><DrawingGroup ClipGeometry='M0,0 L100,0 100,100 0,100Z'>
      <GeometryDrawing Geometry='M0,0 L100,0 100,100 0,100Z'><GeometryDrawing.Brush>
        <LinearGradientBrush StartPoint='0,0' EndPoint='1,1'><GradientStop Color='#9A10121A' Offset='0'/><GradientStop Color='#B8080A10' Offset='1'/></LinearGradientBrush>
      </GeometryDrawing.Brush></GeometryDrawing>
      <GeometryDrawing><GeometryDrawing.Geometry><EllipseGeometry Center='12,10' RadiusX='45' RadiusY='38'/></GeometryDrawing.Geometry>
        <GeometryDrawing.Brush><RadialGradientBrush><GradientStop Color='#70FF7A18' Offset='0'/><GradientStop Color='#00FF7A18' Offset='1'/></RadialGradientBrush></GeometryDrawing.Brush></GeometryDrawing>
      <GeometryDrawing><GeometryDrawing.Geometry><EllipseGeometry Center='92,95' RadiusX='55' RadiusY='45'/></GeometryDrawing.Geometry>
        <GeometryDrawing.Brush><RadialGradientBrush><GradientStop Color='#5522B8C8' Offset='0'/><GradientStop Color='#0022B8C8' Offset='1'/></RadialGradientBrush></GeometryDrawing.Brush></GeometryDrawing>
      <GeometryDrawing><GeometryDrawing.Geometry><EllipseGeometry Center='70,20' RadiusX='30' RadiusY='26'/></GeometryDrawing.Geometry>
        <GeometryDrawing.Brush><RadialGradientBrush><GradientStop Color='#307A4CFF' Offset='0'/><GradientStop Color='#007A4CFF' Offset='1'/></RadialGradientBrush></GeometryDrawing.Brush></GeometryDrawing>
    </DrawingGroup></DrawingBrush.Drawing></DrawingBrush>
  </Grid.Background>
  <Grid.RowDefinitions><RowDefinition Height='44'/><RowDefinition Height='Auto'/><RowDefinition/><RowDefinition Height='Auto'/></Grid.RowDefinitions>
  <Grid.ColumnDefinitions><ColumnDefinition x:Name='sideCol' Width='236'/><ColumnDefinition/></Grid.ColumnDefinitions>

  <!-- title bar -->
  <StackPanel Grid.ColumnSpan='2' Orientation='Horizontal' Margin='16,0,0,0' VerticalAlignment='Center'>
    <Image x:Name='iApp' Width='20' Height='20' Margin='0,0,10,0'/>
    <TextBlock x:Name='lWin' Foreground='{StaticResource Dim}' FontSize='12' VerticalAlignment='Center' TextWrapping='NoWrap'/>
  </StackPanel>
  <StackPanel Grid.ColumnSpan='2' Orientation='Horizontal' HorizontalAlignment='Right' Margin='0,6,8,0' VerticalAlignment='Top'>
    <Button x:Name='bMusic' Style='{StaticResource Chrome}' Content='&#xE767;' FontSize='13' ToolTip='Звук заставки: вкл/выкл' shell:WindowChrome.IsHitTestVisibleInChrome='True'/>
    <Button x:Name='bMin' Style='{StaticResource Chrome}' Content='&#xE921;' shell:WindowChrome.IsHitTestVisibleInChrome='True'/>
    <Button x:Name='bClose' Style='{StaticResource Chrome}' Content='&#xE8BB;' shell:WindowChrome.IsHitTestVisibleInChrome='True'/>
  </StackPanel>

  <!-- side art -->
  <Border x:Name='side' Grid.Row='1' Grid.RowSpan='2' Margin='18,6,8,8' CornerRadius='20' BorderThickness='1' BorderBrush='{StaticResource GlassEdge}' ClipToBounds='True'>
    <Grid>
      <Border CornerRadius='20' x:Name='sideImg'/>
      <Border CornerRadius='20' Background='{StaticResource Sheen}' IsHitTestVisible='False'/>
    </Grid>
  </Border>

  <!-- header -->
  <Grid x:Name='header' Grid.Row='1' Grid.Column='1' Margin='16,6,22,14'>
    <Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition Width='Auto'/></Grid.ColumnDefinitions>
    <StackPanel VerticalAlignment='Center'>
      <TextBlock x:Name='lTitle' FontSize='22' FontWeight='SemiBold'/>
      <TextBlock x:Name='lSub' Foreground='{StaticResource Dim}' Margin='0,4,0,0'/>
    </StackPanel>
    <Border Grid.Column='1' Width='56' Height='56' CornerRadius='14' BorderThickness='1' BorderBrush='{StaticResource GlassEdge}' ClipToBounds='True' Margin='12,0,0,0'>
      <Border x:Name='iSmall' CornerRadius='14'/>
    </Border>
  </Grid>

  <!-- pages -->
  <Grid Grid.Row='2' Grid.Column='1' Margin='16,0,22,6'>" + welcome + folder + tr + opts + dev + ready + prog + fin + @"</Grid>

  <!-- bottom bar -->
  <Grid Grid.Row='3' Grid.ColumnSpan='2' Margin='22,10,22,18'>
    <TextBlock Text='by MeT1oR &amp; Tianku' Foreground='{StaticResource Dim}' VerticalAlignment='Center' FontSize='12'/>
    <StackPanel Orientation='Horizontal' HorizontalAlignment='Right'>
      <Button x:Name='bBack' Style='{StaticResource Pill}' Content='Назад' Margin='0,0,10,0'/>
      <Button x:Name='bNext' Style='{StaticResource PillAccent}' Content='Далее' Margin='0,0,10,0' IsDefault='True'/>
      <Button x:Name='bCancel' Style='{StaticResource Pill}' Content='Отмена'/>
    </StackPanel>
  </Grid>
</Grid>";
        }

        T F<T>(string n) where T : class { return (T)root.FindName(n); }

        static FontFamily LoadInter()
        {
            try
            {
                string dir = Path.Combine(Path.GetTempPath(), "ZA_Setup_fonts");
                Directory.CreateDirectory(dir);
                foreach (var f in new[] { "Inter-Regular.ttf", "Inter-Medium.ttf", "Inter-SemiBold.ttf", "Inter-Bold.ttf" })
                {
                    string p = Path.Combine(dir, f);
                    if (!File.Exists(p)) using (var src = Res(f)) using (var dst = File.Create(p)) src.CopyTo(dst);
                }
                return new FontFamily(new Uri(dir + Path.DirectorySeparatorChar), "./#Inter");
            }
            catch { return new FontFamily("Segoe UI"); }
        }

        // animated GIF: frames from the embedded file, swapped by a timer
        static void Animate(Image img, string res)
        {
            try
            {
                var dec = new GifBitmapDecoder(Res(res), BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.OnLoad);
                var frames = new List<BitmapSource>(); BitmapSource prev = null;
                int w = dec.Frames[0].PixelWidth, h = dec.Frames[0].PixelHeight;
                foreach (var f in dec.Frames)
                {   // compose frames (optimised GIFs store only the changed rectangle)
                    var md = (BitmapMetadata)f.Metadata;
                    int x = Convert.ToInt32(md.GetQuery("/imgdesc/Left") ?? 0), y = Convert.ToInt32(md.GetQuery("/imgdesc/Top") ?? 0);
                    var dv = new DrawingVisual();
                    using (var dc = dv.RenderOpen()) { if (prev != null) dc.DrawImage(prev, new Rect(0, 0, w, h)); dc.DrawImage(f, new Rect(x, y, f.PixelWidth, f.PixelHeight)); }
                    var rt = new RenderTargetBitmap(w, h, 96, 96, PixelFormats.Pbgra32); rt.Render(dv); rt.Freeze();
                    frames.Add(rt); prev = rt;
                }
                int i = 0; img.Source = frames[0];
                var tm = new System.Windows.Threading.DispatcherTimer { Interval = TimeSpan.FromMilliseconds(55) };
                tm.Tick += (s, e) => { if (img.IsVisible) { i = (i + 1) % frames.Count; img.Source = frames[i]; } };
                tm.Start();
            }
            catch { }
        }

        // ------------------------------------------------------------------ window
        public GlassWizard(bool uninstall)
        {
            uninstallMode = uninstall;
            Title = (uninstall ? "Удаление: " : "Установка: ") + AppTitle + " " + Installer.Version;
            Width = 860; Height = 600; ResizeMode = ResizeMode.CanMinimize; WindowStartupLocation = WindowStartupLocation.CenterScreen;
            WindowStyle = WindowStyle.SingleBorderWindow;
            WindowChrome.SetWindowChrome(this, new WindowChrome { CaptionHeight = 44, GlassFrameThickness = new Thickness(0), ResizeBorderThickness = new Thickness(0), CornerRadius = new CornerRadius(0), UseAeroCaptionButtons = false });
            Background = Brushes.Transparent;
            try { Icon = BitmapFrame.Create(Res("small.png")); } catch { }
            root = (FrameworkElement)XamlReader.Parse(BuildXaml());
            root.SetValue(TextElement.FontFamilyProperty, LoadInter());
            Content = root;

            F<Image>("iApp").Source = Img("small.png");
            F<TextBlock>("lWin").Text = Title;
            F<Border>("sideImg").Background = new ImageBrush(Img("wizard.png")) { Stretch = Stretch.UniformToFill, AlignmentX = AlignmentX.Center };
            F<Border>("iSmall").Background = new ImageBrush(Img("small.png")) { Stretch = Stretch.UniformToFill };
            F<Image>("iDiscord").Source = Img("icon_discord.png"); F<Image>("iDlss").Source = Img("icon_dlss.png");
            F<Image>("iAura").Source = Img("icon_aura.png"); F<Image>("iDl").Source = Img("icon_dl.png");
            Animate(F<Image>("gDlaa"), "dlaa_compare.gif"); Animate(F<Image>("gDs"), "pad_dualsense.gif"); Animate(F<Image>("gXb"), "pad_xbox.gif");
            F<TextBlock>("tWelcome").Text = "Установит полный перевод на выбор (авторский, точный или только интерфейс), шрифты с кириллицей, русские логотипы и надписи на уровнях, мод геймпада для DualSense и Xbox, подсветку клавиатуры, статус в Discord и сглаживание NVIDIA DLAA.\n\nВерсия " + Installer.Version + " для игры с " + Installer.GameBuild + ".";

            pages = new[] { "pWelcome", "pFolder", "pTr", "pOpt", "pDev", "pReady", "pProg", "pFin" }.Select(n => F<Grid>(n)).ToArray();
            lTitle = F<TextBlock>("lTitle"); lSub = F<TextBlock>("lSub"); side = F<FrameworkElement>("side"); header = F<FrameworkElement>("header");
            tPath = F<TextBox>("tPath"); lPathState = F<TextBlock>("lPathState");
            rEn = F<RadioButton>("rEn"); rPt = F<RadioButton>("rPt"); rAuthor = F<RadioButton>("rAuthor"); rExact = F<RadioButton>("rExact"); rUi = F<RadioButton>("rUi");
            rNamesRu = F<RadioButton>("rNamesRu"); rNamesEn = F<RadioButton>("rNamesEn");
            rPadNone = F<RadioButton>("rPadNone"); rPadAuto = F<RadioButton>("rPadAuto"); rPadDs = F<RadioButton>("rPadDs"); rPadXbox = F<RadioButton>("rPadXbox");
            rKbNone = F<RadioButton>("rKbNone"); rKbAura = F<RadioButton>("rKbAura"); rKbWin = F<RadioButton>("rKbWin");
            cLogos = F<CheckBox>("cLogos"); cTex = F<CheckBox>("cTex"); cDiscord = F<CheckBox>("cDiscord"); cDlaa = F<CheckBox>("cDlaa"); cRunGame = F<CheckBox>("cRunGame");
            tReady = F<TextBlock>("tReady"); gPadReq = F<FrameworkElement>("gPadReq"); lPadReq = F<TextBlock>("lPadReq"); lnkPs = F<FrameworkElement>("lnkPs"); lnkXb = F<FrameworkElement>("lnkXb");
            lStatus = F<TextBlock>("lStatus"); bar = F<ProgressBar>("bar"); log = F<ListBox>("log");
            lFinTitle = F<TextBlock>("lFinTitle"); lFinText = F<TextBlock>("lFinText");
            bBack = F<Button>("bBack"); bNext = F<Button>("bNext"); bCancel = F<Button>("bCancel");

            bBack.Click += (s, e) => Go(page - 1);
            bNext.Click += (s, e) => Next();
            bCancel.Click += (s, e) => Close();
            F<Button>("bClose").Click += (s, e) => Close();
            F<Button>("bMin").Click += (s, e) => WindowState = WindowState.Minimized;
            F<Button>("bBrowse").Click += (s, e) => Browse();
            F<System.Windows.Documents.Hyperlink>("hPs").Click += (s, e) => OpenUrl("https://controller.dl.playstation.net/controller/lang/gb/2100004.html");
            F<System.Windows.Documents.Hyperlink>("hXb").Click += (s, e) => OpenUrl("https://apps.microsoft.com/detail/9nblggh30xj3");
            tPath.TextChanged += (s, e) => CheckPath();
            rNamesEn.Checked += (s, e) => cLogos.IsChecked = false;
            rNamesRu.Checked += (s, e) => cLogos.IsChecked = true;

            inst.OpenPayload = () => Res("payload.zip");
            inst.Log = (m, k) => Dispatcher.BeginInvoke((Action)(() => AddLog(m, k)));
            inst.Progress = v => Dispatcher.BeginInvoke((Action)(() => bar.Value = Math.Max(0, Math.Min(100, v))));

            string g = Installer.FindGame(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
            if (g == null) try { using (var k = Registry.LocalMachine.OpenSubKey(RegKey)) if (k != null) g = k.GetValue("InstallLocation") as string; } catch { }
            if (g != null) tPath.Text = g;
            CheckPath();

            SourceInitialized += (s, e) => ApplyGlass();
            try { InitSound(); } catch { }
            Closing += (s, e) =>
            {
                if (closingOk) return;
                if (busy) { e.Cancel = true; return; }
                if (page < 6 && !uninstallMode && MessageBox.Show(this, "Установка не завершена. Выйти из программы установки?", "Выход", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) e.Cancel = true;
            };
            Go(uninstallMode ? 1 : 0);
        }

        // DWM: acrylic backdrop (Windows 11 22H2+), dark frame, rounded corners. Older Windows gets an opaque dark glass look.
        [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr h, int a, ref int v, int s);
        [StructLayout(LayoutKind.Sequential)] struct MARGINS { public int l, r, t, b; }
        [DllImport("dwmapi.dll")] static extern int DwmExtendFrameIntoClientArea(IntPtr h, ref MARGINS m);
        void ApplyGlass()
        {
            var h = new WindowInteropHelper(this).Handle;
            int on = 1, round = 2, acrylic = 3;
            try { DwmSetWindowAttribute(h, 20, ref on, 4); } catch { }
            try { DwmSetWindowAttribute(h, 33, ref round, 4); } catch { }
            try { glass = Environment.OSVersion.Version.Build >= 22621 && DwmSetWindowAttribute(h, 38, ref acrylic, 4) == 0; } catch { glass = false; }
            HwndSource src = null;
            try { src = HwndSource.FromHwnd(h); } catch { }
            if (glass && src != null)
            {
                src.CompositionTarget.BackgroundColor = Colors.Transparent;
                var m = new MARGINS { l = -1, r = -1, t = -1, b = -1 };
                try { DwmExtendFrameIntoClientArea(h, ref m); } catch { }
            }
            else Background = new SolidColorBrush(Color.FromRgb(16, 18, 26));
        }

        // ------------------------------------------------------------------ navigation
        static readonly string[,] Heads = {
            {"Вас приветствует мастер установки", "Русификатор «Зомби-штурм: Пробуждение»"},
            {"Папка игры", "Где установлена Zombie Assault: Resurgence?"},
            {"Перевод", "Язык, вариант перевода и названия."},
            {"Дополнительно", "Картинки, Discord и сглаживание."},
            {"Геймпад и подсветка", "Мод внутри игры: геймпад и клавиатура."},
            {"Всё готово к установке", "Проверьте параметры и нажмите «Установить»."},
            {"Установка", "Подождите, русификатор устанавливается…"},
            {"", ""}};

        void Go(int n)
        {
            page = n;
            for (int i = 0; i < pages.Length; i++) pages[i].Visibility = i == n ? Visibility.Visible : Visibility.Collapsed;
            bool art = n == 0 || n == 7;
            side.Visibility = art ? Visibility.Visible : Visibility.Collapsed;
            F<ColumnDefinition>("sideCol").Width = new GridLength(art ? 236 : 0);
            header.Visibility = n == 7 ? Visibility.Collapsed : Visibility.Visible;
            lTitle.Text = Heads[n, 0]; lSub.Text = Heads[n, 1];
            if (n == 6 && uninstallMode) { lTitle.Text = "Удаление"; lSub.Text = "Подождите, русификатор удаляется…"; }
            if (n == 1 && uninstallMode) { lTitle.Text = "Удаление русификатора"; lSub.Text = "Укажите папку игры и нажмите «Удалить»."; }
            bBack.IsEnabled = n > 0 && n < 6 && !(uninstallMode && n <= 1);
            bNext.Content = n == 5 ? "Установить" : n == 7 ? "Завершить" : (uninstallMode && n == 1 ? "Удалить" : "Далее");
            bCancel.IsEnabled = n < 6;
            bNext.IsEnabled = n != 6 && (n != 1 || Installer.IsGame(tPath.Text));
            if (n == 5) { tReady.Text = Summary(); UpdatePadReq(); }
        }

        void Next()
        {
            if (page == 7) { Finish(); return; }
            if (page == 1 && uninstallMode) { Run(true); return; }
            if (page == 1 && !CheckRunning()) return;
            if (page == 5) { Run(false); return; }
            Go(page + 1);
        }

        string Summary()
        {
            var l = new List<string>();
            l.Add("Папка игры: " + tPath.Text); l.Add("");
            l.Add("Будет установлено:");
            l.Add("•  Перевод текста и шрифты с кириллицей (" + (rPt.IsChecked == true ? "вместо португальского" : "вместо английского") + ")");
            l.Add("•  Вариант: " + (rUi.IsChecked == true ? "только интерфейс (сюжет и диалоги на английском)" : rExact.IsChecked == true ? "точный (близко к оригиналу)" : "авторский (ручной, с отсебятиной)"));
            l.Add("•  Названия: " + (rNamesEn.IsChecked == true ? "английские" : "русские"));
            l.Add("•  Шрифт засекреченного текста и исправление диалогов");
            if (cLogos.IsChecked == true) l.Add("•  Русские логотипы компаний и картинки интерфейса");
            if (cTex.IsChecked == true) l.Add("•  Русские надписи на текстурах в игре");
            if (rPadAuto.IsChecked == true) l.Add("•  Мод геймпада: DualSense или Xbox (автоматически)");
            if (rPadDs.IsChecked == true) l.Add("•  Мод геймпада: DualSense");
            if (rPadXbox.IsChecked == true) l.Add("•  Мод геймпада: Xbox");
            if (rKbAura.IsChecked == true) l.Add("•  Подсветка клавиатуры: ASUS Aura");
            if (rKbWin.IsChecked == true) l.Add("•  Подсветка клавиатуры: динамическая подсветка Windows");
            if (cDiscord.IsChecked == true) l.Add("•  Статус в Discord: персонаж, класс и уровень");
            if (cDlaa.IsChecked == true) l.Add("•  Сглаживание NVIDIA DLAA (DLSS 4.5)");
            l.Add(""); l.Add("Оригинальные файлы сохраняются рядом (*.orig) и возвращаются при удалении.");
            l.Add("Удалить русификатор можно через «Параметры > Приложения» Windows или запустив эту программу снова.");
            return string.Join("\n", l);
        }

        void UpdatePadReq()
        {
            bool ds = rPadAuto.IsChecked == true || rPadDs.IsChecked == true, xb = rPadAuto.IsChecked == true || rPadXbox.IsChecked == true;
            gPadReq.Visibility = ds || xb ? Visibility.Visible : Visibility.Collapsed;
            var l = new List<string>();
            l.Add("Обновите прошивку геймпада до последней версии (программы по ссылкам ниже).");
            if (ds) l.Add("DualSense: кабелем USB. HD-вибрация и динамик работают только по проводу.");
            if (xb) l.Add("Xbox: кабелем или через адаптер Xbox Wireless (по Bluetooth нет импульсных триггеров).");
            l.Add("Выключите Steam Input для игры: Свойства > Контроллер. Закройте DSX и DS4Windows.");
            lPadReq.Text = string.Join("\n", l.Select(x => "•  " + x));
            lnkPs.Visibility = ds ? Visibility.Visible : Visibility.Collapsed; lnkXb.Visibility = xb ? Visibility.Visible : Visibility.Collapsed;
        }

        void CheckPath()
        {
            bool ok = Installer.IsGame(tPath.Text);
            lPathState.Foreground = new SolidColorBrush(ok ? Color.FromRgb(120, 230, 150) : Color.FromRgb(255, 130, 120));
            lPathState.Text = ok ? "✓  Игра найдена." : (string.IsNullOrWhiteSpace(tPath.Text) ? "Папка игры не найдена автоматически. Укажите её вручную." : "В этой папке нет zombieassault.exe.");
            if (page == 1) bNext.IsEnabled = ok;
        }

        void Browse()
        {
            using (var d = new System.Windows.Forms.FolderBrowserDialog { Description = "Укажите папку игры Zombie Assault (где лежит zombieassault.exe)", ShowNewFolderButton = false })
            {
                if (Directory.Exists(tPath.Text)) d.SelectedPath = tPath.Text;
                if (d.ShowDialog() == System.Windows.Forms.DialogResult.OK) tPath.Text = d.SelectedPath;
            }
        }

        bool CheckRunning()
        {
            while (Process.GetProcessesByName("zombieassault").Length > 0)
                if (MessageBox.Show(this, "Игра запущена. Закройте её и нажмите «ОК».", AppTitle, MessageBoxButton.OKCancel, MessageBoxImage.Information) == MessageBoxResult.Cancel) return false;
            return true;
        }

        void AddLog(string m, Kind k)
        {
            string pre = k == Kind.Ok ? "✓  " : k == Kind.Warn ? "!  " : k == Kind.Error ? "✗  " : "";
            var t = new TextBlock { Text = pre + m, TextWrapping = TextWrapping.Wrap };
            if (k == Kind.Ok) t.Foreground = new SolidColorBrush(Color.FromRgb(150, 235, 170));
            else if (k == Kind.Warn) t.Foreground = new SolidColorBrush(Color.FromRgb(255, 210, 120));
            else if (k == Kind.Error) t.Foreground = new SolidColorBrush(Color.FromRgb(255, 140, 130));
            else if (k == Kind.Head) t.FontWeight = FontWeights.SemiBold;
            log.Items.Add(t); log.ScrollIntoView(t);
            lStatus.Text = m;
        }

        static void OpenUrl(string u) { try { Process.Start(new ProcessStartInfo(u) { UseShellExecute = true }); } catch { } }

        // ------------------------------------------------------------------ run
        void Run(bool uninstall)
        {
            if (uninstall && !CheckRunning()) return;
            inst.Game = tPath.Text; inst.Lang = rPt.IsChecked == true ? "portuguese" : "english";
            inst.Variant = (rUi.IsChecked == true ? "ui_" : rExact.IsChecked == true ? "exact_" : "author_") + (rNamesEn.IsChecked == true ? "en" : "ru");
            inst.Logos = cLogos.IsChecked == true; inst.Textures = cTex.IsChecked == true;
            inst.Pad = rPadAuto.IsChecked == true ? "auto" : rPadDs.IsChecked == true ? "dualsense" : rPadXbox.IsChecked == true ? "xbox" : "";
            inst.Kbd = rKbAura.IsChecked == true ? "aura" : rKbWin.IsChecked == true ? "windows" : "";
            inst.Discord = cDiscord.IsChecked == true; inst.Dlaa = cDlaa.IsChecked == true;
            inst.Voice = false; inst.VoiceTest = false;
            Go(6); busy = true; bNext.IsEnabled = bBack.IsEnabled = bCancel.IsEnabled = false;
            var th = new Thread(() =>
            {
                bool ok = true;
                try
                {
                    if (uninstall) { inst.Uninstall(); Unregister(); }
                    else { ok = inst.Install(); if (ok) Register(); }
                }
                catch (UnauthorizedAccessException) { ok = false; inst.Log("Нет доступа к папке игры. Запустите программу от имени администратора.", Kind.Error); }
                catch (Exception ex) { ok = false; inst.Log("Ошибка: " + ex.Message, Kind.Error); }
                Dispatcher.BeginInvoke((Action)(() => Done(uninstall, ok)));
            }) { IsBackground = true };
            th.Start();
        }

        void Done(bool uninstall, bool ok)
        {
            busy = false; success = ok;
            if (uninstall)
            {
                lFinTitle.Text = "Русификатор удалён";
                lFinText.Text = "Игра возвращена к оригиналу.\n\nНажмите «Завершить», чтобы закрыть программу.";
                cRunGame.Visibility = Visibility.Collapsed;
            }
            else if (ok)
            {
                lFinTitle.Text = "Установка завершена";
                lFinText.Text = "Игра переведена на русский язык." + (inst.Lang == "portuguese" ? " В настройках игры выберите язык Português." : "") +
                    "\n\nЕсли Steam обновит игру, перевод может слететь: просто запустите установку снова (или скачайте новую версию русификатора).\n\nПриятной игры!";
                cRunGame.IsChecked = false;
            }
            else
            {
                lFinTitle.Text = "Установка не завершена";
                lFinText.Text = "Часть файлов не удалось установить: скорее всего, игра обновилась и эта версия русификатора ей не подходит, или нет доступа к папке игры.\n\nПодробности были в списке на предыдущем шаге. Оригинальные файлы игры не повреждены.";
                cRunGame.Visibility = Visibility.Collapsed;
            }
            Go(7);
        }

        void Finish()
        {
            try
            {
                if (cRunGame.Visibility == Visibility.Visible && cRunGame.IsChecked == true)
                    Process.Start(new ProcessStartInfo(Path.Combine(tPath.Text, "zombieassault.exe")) { WorkingDirectory = tPath.Text, UseShellExecute = true });
            }
            catch { }
            if (uninstallMode) ScheduleSelfDelete();
            closingOk = true; Close();
        }

        // ------------------------------------------------------------------ Programs & Features
        static string Exe { get { return Process.GetCurrentProcess().MainModule.FileName; } }
        void Register()
        {
            try
            {
                string dir = Path.Combine(inst.Game, "ZA_Rusifikator");
                Directory.CreateDirectory(dir);
                string un = Path.Combine(dir, "uninstall.exe");
                if (!string.Equals(Path.GetFullPath(Exe), Path.GetFullPath(un), StringComparison.OrdinalIgnoreCase)) File.Copy(Exe, un, true);
                using (var k = Registry.LocalMachine.CreateSubKey(RegKey))
                {
                    k.SetValue("DisplayName", "Русификатор Zombie Assault: Resurgence");
                    k.SetValue("DisplayVersion", Installer.Version);
                    k.SetValue("Publisher", "MeT1oR & Tianku");
                    k.SetValue("DisplayIcon", un);
                    k.SetValue("InstallLocation", inst.Game);
                    k.SetValue("UninstallString", "\"" + un + "\" /uninstall");
                    k.SetValue("NoModify", 1, RegistryValueKind.DWord);
                    k.SetValue("NoRepair", 1, RegistryValueKind.DWord);
                    k.SetValue("EstimatedSize", (int)(new FileInfo(un).Length / 1024 + 30000), RegistryValueKind.DWord);
                }
            }
            catch (Exception ex) { inst.Log("Не удалось добавить в список программ: " + ex.Message, Kind.Warn); }
        }
        void Unregister() { try { Registry.LocalMachine.DeleteSubKeyTree(RegKey, false); } catch { } }
        void ScheduleSelfDelete()
        {
            try
            {
                string me = Exe;
                if (!Path.GetFileName(me).Equals("uninstall.exe", StringComparison.OrdinalIgnoreCase)) return;
                Process.Start(new ProcessStartInfo("cmd.exe", "/c ping 127.0.0.1 -n 3 >nul & del /f /q \"" + me + "\"") { CreateNoWindow = true, UseShellExecute = false, WindowStyle = ProcessWindowStyle.Hidden });
            }
            catch { }
        }

        // ------------------------------------------------------------------ screenshots for the readme (/shots DIR)
        public void Shots(string dir)
        {
            Directory.CreateDirectory(dir);
            for (int i = 0; i < 6; i++) { Go(i); Snap(Path.Combine(dir, "page" + i + ".png")); }
            closingOk = true; Close();
        }
        void Snap(string file)
        {
            Dispatcher.Invoke(() => { }, System.Windows.Threading.DispatcherPriority.ApplicationIdle);
            UpdateLayout();
            var c = (FrameworkElement)Content;
            var rtb = new RenderTargetBitmap((int)(c.ActualWidth * 1.5), (int)(c.ActualHeight * 1.5), 144, 144, PixelFormats.Pbgra32);
            var dv = new DrawingVisual();
            using (var dc = dv.RenderOpen())
            {
                dc.DrawRectangle(new LinearGradientBrush(Color.FromRgb(38, 34, 44), Color.FromRgb(14, 20, 30), 45), null, new Rect(0, 0, c.ActualWidth, c.ActualHeight));
                dc.DrawRectangle(new VisualBrush(c), null, new Rect(0, 0, c.ActualWidth, c.ActualHeight));
            }
            rtb.Render(dv);
            var enc = new PngBitmapEncoder(); enc.Frames.Add(BitmapFrame.Create(rtb));
            using (var f = File.Create(file)) enc.Save(f);
        }
    }

    static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            bool un = args.Any(a => a.Equals("/uninstall", StringComparison.OrdinalIgnoreCase) || a.Equals("-uninstall", StringComparison.OrdinalIgnoreCase));
            var app = new Application { ShutdownMode = ShutdownMode.OnMainWindowClose };
            int si = Array.FindIndex(args, a => a == "/shots");
            if (si >= 0 && si + 1 < args.Length) { var w = new GlassWizard(false); app.MainWindow = w; w.ContentRendered += (s, e) => w.Dispatcher.BeginInvoke((Action)(() => w.Shots(args[si + 1])), System.Windows.Threading.DispatcherPriority.ContextIdle); app.Run(w); return; }
            app.Run(new GlassWizard(un));
        }
    }
}
