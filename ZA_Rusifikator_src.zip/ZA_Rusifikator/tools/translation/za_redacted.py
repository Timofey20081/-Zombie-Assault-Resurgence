"""Redacted text font -> "space interference" look.

* Adds Cyrillic (and other missing) characters to the game's 'redacted' TMP font
  (resources.assets), each mapped to one of the existing glyph cells (varied, not one block).
* Repaints every glyph cell of its atlas (512x512 Alpha8 SDF, cells 20x50) with
  signal-noise: broken horizontal scanlines, dropouts, glitch-shifted bands.
* The new atlas is stored inline in resources.assets (resources.assets.resS untouched).
usage: za_redacted.py <loc bundle> <resources.assets> <resources.assets.resS> <out>
"""
import sys, zlib, UnityPy, numpy as np
bundle, src, ress, out = sys.argv[1:5]
b = UnityPy.load(bundle)
node = [o for o in b.objects if o.type.name == "MonoBehaviour"][0]._get_typetree_node()
env = UnityPy.load(src)
font = d = None
for o in env.objects:
    if o.type.name == "MonoBehaviour" and b"redacted" in o.get_raw_data()[:200]:
        try:
            dd = o.read_typetree(nodes=node)
        except Exception:
            continue
        if dd.get("m_Name") == "redacted":
            font, d = o, dd
            break
assert font, "redacted font not found"

# ---- character table -------------------------------------------------------
have = {c["m_Unicode"] for c in d["m_CharacterTable"]}
cells = sorted({g["m_Index"] for g in d["m_GlyphTable"] if g["m_GlyphRect"]["m_Width"] >= 10})
tmpl = next(c for c in d["m_CharacterTable"] if c["m_Unicode"] == ord("A"))
want = list(range(0x400, 0x460)) + [0x2116, 0x2026, 0x2014, 0x2013, 0xAB, 0xBB, 0x201E, 0x201C, 0xD7]
added = 0
for cp in want:
    if cp not in have:
        e = dict(tmpl); e["m_Unicode"] = cp
        e["m_GlyphIndex"] = cells[(cp * 2654435761 >> 7) % len(cells)]
        d["m_CharacterTable"].append(e); added += 1
font.save_typetree(d, nodes=node)

# ---- atlas -----------------------------------------------------------------
mat = env.objects[[o.path_id for o in env.objects].index(d["m_Material"]["m_PathID"])].read_typetree()
tex_id = next(t[1]["m_Texture"]["m_PathID"] for t in mat["m_SavedProperties"]["m_TexEnvs"] if t[0] == "_MainTex")
tex = next(o for o in env.objects if o.path_id == tex_id)
td = tex.read_typetree()
W, H = td["m_Width"], td["m_Height"]
sd = td["m_StreamData"]
raw = open(ress, "rb").read()[sd["offset"]:sd["offset"] + sd["size"]] if sd["size"] else bytes(td["image data"])
atlas = np.frombuffer(raw, np.uint8).reshape(H, W).copy()

rng = np.random.default_rng(0x5EED)


def noise_cell(w, h):
    """Binary interference pattern: broken horizontal scanlines with gaps;
    features >= 3 px so they survive downscaling to UI text size."""
    c = np.zeros((h, w), np.uint8)
    y = int(rng.integers(0, 3))
    while y < h:
        bh = int(rng.integers(3, 7))             # band height
        row = np.zeros(w + 40, np.uint8)
        x = int(rng.integers(0, 6))
        while x < w + 40:
            on = int(rng.integers(4, 22))
            off = int(rng.integers(2, 9))
            row[x:x + on] = 255
            x += on + off
        shift = int(rng.integers(0, 20))         # glitch shift of the band
        seg = row[shift:shift + w]
        for yy in range(y, min(h, y + bh)):
            c[yy] = seg
        if rng.random() < 0.35:                  # torn edge: offset last line of band
            yy = min(h - 1, y + bh - 1)
            c[yy] = np.roll(c[yy], int(rng.integers(-4, 5)))
        y += bh + int(rng.integers(2, 5))        # dark gap between scanlines
    return c


painted = 0
for g in d["m_GlyphTable"]:
    r = g["m_GlyphRect"]
    if r["m_Width"] < 10:
        continue
    x0, y0, w, h = r["m_X"], r["m_Y"], r["m_Width"], r["m_Height"]
    atlas[y0:y0 + h, x0:x0 + w] = noise_cell(w, h)
    painted += 1

data = atlas.tobytes()
td["image data"] = data
td["m_CompleteImageSize"] = len(data)
td["m_StreamData"] = {"offset": 0, "size": 0, "path": ""}
tex.save_typetree(td)
open(out, "wb").write(env.file.save())
np.save(out + ".atlas.npy", atlas)
print("chars added", added, "cells painted", painted)
