@echo off
rem Сборка мода ZAPad (version.dll) в "x64 Native Tools Command Prompt for VS".
rem Нужны (не входят в репозиторий):
rem   src\minhook\      - https://github.com/TsudaKageyu/minhook (BSD-2)
rem   src\ngx\          - заголовки и nvsdk_ngx_s.lib из NVIDIA DLSS SDK: https://github.com/NVIDIA/DLSS
rem   src\Unity\        - IUnityInterface.h, IUnityGraphics.h, IUnityGraphicsD3D12.h (папка PluginAPI в установке Unity)
rem   GameInput.h       - NuGet-пакет Microsoft.GameInput (v4)
cd /d "%~dp0src"
cl /nologo /std:c++20 /O2 /EHsc /LD /MT /utf-8 /W3 /I. /Iminhook\include zapad.cpp kbd.cpp dlaa.cpp minhook\src\buffer.c minhook\src\hook.c minhook\src\trampoline.c minhook\src\hde\hde64.c /Fe:ZAPad_version.dll /link ole32.lib oleaut32.lib user32.lib windowsapp.lib ngx\nvsdk_ngx_s.lib
if errorlevel 1 exit /b 1
rem Помощник подсветки ASUS Aura (C#, .NET Framework 4.8):
C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe /nologo /target:winexe /out:ZAAura.exe ZAAura.cs
echo Готово: src\ZAPad_version.dll (положить в папку игры как version.dll)
