"""UI-only variants: menus, gear, settings, objectives in Russian; story, dialogue, lore and tutorials in English."""
import sys, json, re, UnityPy
sys.argv = [sys.argv[0]]
sys.path.insert(0, "/home/claude/scripts")
import za_variants as V
B = V.B
W = "/home/claude/work"
rows = json.load(open(f"{W}/tr/en_all.json"))
def story(sec):
    return ("/Dialogue" in sec or sec.startswith("Language/Tutorial") or "/Lore" in sec or "ProfilePrompt" in sec
            or "Cinematic" in sec or sec == "Language/Characters" or sec.endswith("Chat"))
skeys = {r["id"] for r in rows if story(r["sec"])}
print("story keys", len(skeys))
for base, name in (("author_ru", "ui_ru"), ("author_en", "ui_en")):
    d = {k: v for k, v in V.variants[base].items() if k not in skeys}
    xml = f"{W}/out/var/{name}.xml"; n = B.build(d, xml)
    text = open(xml, encoding="utf-8").read()
    for lang in ("english", "portuguese"):
        src = f"{W}/out/v4/{base}/{lang}/localization_assets_all_fc03e8144bbdc66b764b78538acd9411.bundle"
        env = UnityPy.load(src)
        for o in env.objects:
            if o.type.name == "TextAsset":
                t = o.read_typetree()
                if t["m_Name"].lower() == lang: t["m_Script"] = text; o.save_typetree(t); break
        else: raise SystemExit("no " + lang)
        import os; os.makedirs(f"{W}/out/v4/{name}/{lang}", exist_ok=True)
        open(f"{W}/out/v4/{name}/{lang}/localization_assets_all_fc03e8144bbdc66b764b78538acd9411.bundle", "wb").write(env.file.save(packer="lz4"))
    print(name, "entries", len(d), "replaced", n)
