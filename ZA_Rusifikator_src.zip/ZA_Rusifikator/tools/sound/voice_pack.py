import json, subprocess, struct, re, os, sys
from concurrent.futures import ThreadPoolExecutor
W = "/home/claude/work"
d = json.load(open(f"{W}/vo/kit_media2.json"))
RATE = 16000
FILT = "highpass=f=300,lowpass=f=3400,afftdn=nf=-30,acompressor=threshold=0.2:ratio=3:attack=5:release=80:makeup=1.5,loudnorm=I=-16:TP=-1.5:LRA=7,alimiter=limit=0.9"
def enc(x):
    src = f"{W}/vo/ogg/{x['id']}.ogg"
    if not os.path.exists(src): return x['id'], None
    pcm = subprocess.run(["ffmpeg", "-v", "error", "-i", src, "-af", FILT, "-ac", "1", "-ar", str(RATE), "-f", "s16le", "-"], capture_output=True).stdout
    ad = subprocess.run(["./adpcm"], input=pcm, capture_output=True).stdout
    return x['id'], (len(pcm) // 2, ad)
with ThreadPoolExecutor(16) as ex: clips = dict(ex.map(enc, d))
ids = [i for i in dict.fromkeys(x['id'] for x in d) if clips.get(i)]
cidx = {m: k for k, m in enumerate(ids)}
# texts per tid: english + all translation variants
en = json.load(open(f"{W}/tr/en_all.json"))
texts = {}
def addt(tid, t):
    if t: texts.setdefault(tid, set()).add(t.replace("¶", "\n"))
for x in d: addt(x['tid'], x.get('en')); addt(x['tid'], x.get('ru')); addt(x['tid'], en.get(x['tid']) if isinstance(en, dict) else None)
for v in ("author_ru", "author_en", "exact_en", "exact_ru"):
    for line in open(f"{W}/out/var/{v}.tsv", encoding="utf-8"):
        k, _, t = line.rstrip("\n").partition("\t")
        if k in texts or any(k == x['tid'] for x in d[:0]): addt(k, t)
tids = {x['tid'] for x in d}
for v in ("author_ru", "author_en", "exact_en", "exact_ru"):
    for line in open(f"{W}/out/var/{v}.tsv", encoding="utf-8"):
        k, _, t = line.rstrip("\n").partition("\t")
        if k in tids: addt(k, t)
def norm(t):
    t = re.sub(r"<[^>]*>", "", t); t = re.sub(r"\{[^}]*\}", "", t)
    return [c for c in t if ('0' <= c <= '9') or ('a' <= c.lower() <= 'z') or ('Ѐ' <= c <= 'ӿ')]
def low(c):
    o = ord(c)
    if 0x41 <= o <= 0x5a: return o + 32
    if 0x410 <= o <= 0x42f: return o + 32
    if 0x400 <= o <= 0x40f: return o + 80
    return o
def fnv(chars):
    h = 2166136261
    for c in chars:
        o = low(c)
        h ^= o & 0xff; h = (h * 16777619) & 0xffffffff
        h ^= o >> 8; h = (h * 16777619) & 0xffffffff
    return h
keys = {}
for x in d:
    if x['id'] not in cidx: continue
    g = 1 if x['folder'] == 'Герой_Ж' else 0
    for t in texts.get(x['tid'], ()):
        n = norm(t)
        if len(n) < 4: continue
        for h in {fnv(n), fnv(n[:40]) ^ 0x5a5a5a5a}:
            e = keys.setdefault(h, [0xffff, 0xffff]); 
            if e[g] == 0xffff: e[g] = cidx[x['id']]
for x in d:   # toast lines arrive as localisation ids
    if x['id'] in cidx:
        g = 1 if x['folder'] == 'Герой_Ж' else 0
        e = keys.setdefault(fnv(norm(x['tid'])) ^ 0x7e7e7e7e, [0xffff, 0xffff])
        if e[g] == 0xffff: e[g] = cidx[x['id']]
for e in keys.values():
    if e[0] == 0xffff: e[0] = e[1]
    if e[1] == 0xffff: e[1] = e[0]
out = bytearray(b"ZSPK") + struct.pack("<III", RATE, len(ids), len(keys))
hdr = 16 + 8 * len(ids) + 8 * len(keys); off = hdr; tab = bytearray(); blob = bytearray()
RADIO = {"Самсон", "Циммерман", "Пилот", "ИИ_станции"}
radio_ids = {x['id'] for x in d if x['folder'] in RADIO}
for m in ids:
    n, ad = clips[m]; tab += struct.pack("<II", off + len(blob), n | (0x80000000 if m in radio_ids else 0)); blob += ad
kt = bytearray()
for h in sorted(keys): kt += struct.pack("<IHH", h, *keys[h])
out += tab + kt + blob
open("ZASpk.dat", "wb").write(out)
print("clips", len(ids), "keys", len(keys), "size MB", round(len(out) / 1e6, 2), "tids", len(texts))
