// ZAPad — DualSense / Xbox controller features inside Zombie Assault: Resurgence.
// by MeT1oR & Tianku
//
// Loaded as version.dll from the game folder. Reads game state through IL2CPP hooks and drives
// the controller through Microsoft GameInput v4 (DualSense raw reports, Xbox impulse triggers).
//
//   DualSense: adaptive triggers per weapon class and state, rumble (game + events),
//              HD haptics over USB audio (shots, hits, abilities, footsteps by surface),
//              lightbar by health, player LEDs = magazine, mute LED = low health,
//              gyro fine-aim while aiming, touchpad swipes = weapon switch, tap = reload.
//   Xbox:      rumble + impulse triggers (shots, overheat, hits).

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include "proxy_version.h"
#include "il2cpp_api.h"
#include <GameInput.h>
#include "DualSenseHelper.h"
#include "MinHook.h"
#include "hdhaptics.h"
#include "kbd.h"
#include "dlaa.h"
#include "spk.h"
#include "akevents.h"
#include "discord.h"
#include "akroute.h"
#include <unordered_map>
#include <unordered_set>
#ifndef DISCORD_APP_ID
#define DISCORD_APP_ID ""
#endif

#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <vector>
#include <algorithm>

using namespace GameInput::v4;
namespace GDS = GameInput::DualSense;

// ------------------------------------------------------------------------------------------------
// log + config
// ------------------------------------------------------------------------------------------------
static std::wstring g_dir;          // <game>\ZA_Rusifikator\pad
static FILE* g_log;
static std::mutex g_logMx;
static void Log(const char* fmt, ...) {
    std::lock_guard<std::mutex> lk(g_logMx);
    if (!g_log) return;
    SYSTEMTIME t; GetLocalTime(&t);
    fprintf(g_log, "[%02d:%02d:%02d.%03d] ", t.wHour, t.wMinute, t.wSecond, t.wMilliseconds);
    va_list a; va_start(a, fmt); vfprintf(g_log, fmt, a); va_end(a);
    fputc('\n', g_log); fflush(g_log);
}

struct Config {
    int mode = 0;              // 0 auto, 1 DualSense, 2 Xbox
    int triggers = 100;        // %
    int rumble = 100;          // %
    int haptics = 100;         // % (HD, USB only)
    int footsteps = 1;
    int lightbar = 1;
    int playerLeds = 1;
    int gyro = 1;              // 0 off, 1 while aiming, 2 always
    float gyroSens = 1.0f;
    int gyroInvert = 0;
    int touchpad = 1;
    int touchAim = 1;          // touchpad chooses the target while throwing / placing
    int impulse = 100;         // Xbox impulse triggers %
    int speaker = 1;           // sounds from the controller speaker
    int speakerVol = 80;
    int kbMode = 0;            // keyboard lighting: 0 off, 1 ASUS Aura, 2 Windows Dynamic Lighting
    int kbBright = 100;
    int discord = 0;           // Discord rich presence
    int dlaa = 0;              // NVIDIA DLAA instead of the game's anti-aliasing
    DLAA::Cfg dl;
    std::string discordId;
} C;

static int IniInt(const wchar_t* sec, const wchar_t* key, int def) {
    return GetPrivateProfileIntW(sec, key, def, (g_dir + L"\\ZAPad.ini").c_str());
}
static void LoadConfig() {
    std::wstring ini = g_dir + L"\\ZAPad.ini";
    if (GetFileAttributesW(ini.c_str()) == INVALID_FILE_ATTRIBUTES) {
        FILE* f = _wfopen(ini.c_str(), L"w, ccs=UTF-16LE");
        if (f) {
            fwprintf(f, L"; ZAPad: настройки геймпада. Сохраните файл и перезапустите игру.\n"
                        L"[Main]\n; 0 = автоматически (DualSense или Xbox), 1 = только DualSense, 2 = только Xbox, 3 = без геймпада\nMode=%d\n\n"
                        L"[DualSense]\n; сила адаптивных триггеров, %%\nTriggers=100\n; вибрация, %%\nRumble=100\n"
                        L"; HD-вибрация (только по USB), %%\nHaptics=100\n; шаги по поверхностям: 1/0\nFootsteps=1\n"
                        L"; подсветка по здоровью: 1/0\nLightbar=1\n; индикаторы под тачпадом: 1 = здоровье (5 делений по 20%%), 2 = патроны в магазине, 0 = выкл\nPlayerLeds=1\n"
                        L"; гироскоп: 0 выкл, 1 только при прицеливании, 2 всегда\nGyro=1\n; чувствительность гироскопа, %%\nGyroSensitivity=100\n; 1 = инвертировать гироскоп\nGyroInvert=0\n"
                        L"; тачпад: свайп влево/вправо = смена оружия, тап двумя пальцами = перезарядка\nTouchpad=1\n; тачпад выбирает, куда бросить гранату, поставить турель или навести способность: 1/0\nTouchAim=1\n; звуки из динамика геймпада (перезарядка, сердцебиение, способности): 1/0\nSpeaker=1\n; громкость динамика, %%\nSpeakerVolume=80\n\n"
                        L"[Xbox]\nRumble=100\n; импульсные триггеры, %%\nImpulseTriggers=100\n\n"
                        L"[Keyboard]\n; подсветка клавиатуры: 0 выкл, 1 = ASUS Aura (Armoury Crate), 2 = динамическая подсветка Windows\nMode=0\n; яркость, %%\nBrightness=100\n\n"
                        L"[Discord]\n; дописывать в статус Discord персонажа, класс и уровень. 1/0\nEnabled=0\n\n"
                        L"[DLAA]\n; сглаживание NVIDIA DLAA вместо сглаживания игры (видеокарты GeForce RTX). 1/0\nEnabled=0\n; модель DLSS: K = DLSS 4, L или M = DLSS 4.5\nPreset=L\n", C.mode);
            fclose(f);
        }
    }
    C.mode = IniInt(L"Main", L"Mode", C.mode);
    const wchar_t* s = C.mode == 2 ? L"Xbox" : L"DualSense";   // (auto mode reads per-device sections below)
    C.triggers = IniInt(L"DualSense", L"Triggers", 100);
    C.rumble = IniInt(s, L"Rumble", 100);
    C.haptics = IniInt(L"DualSense", L"Haptics", 100);
    C.footsteps = IniInt(L"DualSense", L"Footsteps", 1);
    C.lightbar = IniInt(L"DualSense", L"Lightbar", 1);
    C.playerLeds = IniInt(L"DualSense", L"PlayerLeds", 1);
    C.gyro = IniInt(L"DualSense", L"Gyro", 1);
    C.gyroSens = IniInt(L"DualSense", L"GyroSensitivity", 100) / 100.0f;
    C.gyroInvert = IniInt(L"DualSense", L"GyroInvert", 0);
    C.touchpad = IniInt(L"DualSense", L"Touchpad", 1);
    C.touchAim = IniInt(L"DualSense", L"TouchAim", 1);
    C.impulse = IniInt(L"Xbox", L"ImpulseTriggers", 100);
    C.speaker = IniInt(L"DualSense", L"Speaker", 1);
    C.speakerVol = IniInt(L"DualSense", L"SpeakerVolume", 80);
    C.kbMode = IniInt(L"Keyboard", L"Mode", 0);
    C.kbBright = IniInt(L"Keyboard", L"Brightness", 100);
    C.discord = IniInt(L"Discord", L"Enabled", 0);
    C.dlaa = IniInt(L"DLAA", L"Enabled", 0);
    { wchar_t b[16] = {}; GetPrivateProfileStringW(L"DLAA", L"Preset", L"L", b, 15, (g_dir + L"\\ZAPad.ini").c_str()); wchar_t c = towupper(b[0]); if (c >= L'J' && c <= L'M') C.dl.preset = c - L'A' + 1; }
    C.dl.mipBias = IniInt(L"DLAA", L"MipBias", 0) / 100.0f;
    C.dl.jitterX = IniInt(L"DLAA", L"JitterX", -1) < 0 ? -1.f : 1.f; C.dl.jitterY = IniInt(L"DLAA", L"JitterY", -1) < 0 ? -1.f : 1.f;
    C.dl.mvX = IniInt(L"DLAA", L"MotionX", -1) < 0 ? -1.f : 1.f; C.dl.mvY = IniInt(L"DLAA", L"MotionY", -1) < 0 ? -1.f : 1.f;
    C.dl.autoExposure = IniInt(L"DLAA", L"AutoExposure", 1);
    C.dl.split = IniInt(L"DLAA", L"Split", 0);
    { wchar_t b[64] = {}; GetPrivateProfileStringW(L"Discord", L"ClientId", L"", b, 63, (g_dir + L"\\ZAPad.ini").c_str()); for (wchar_t* q = b; *q; ++q) if (*q >= L'0' && *q <= L'9') C.discordId += (char)*q; }
    if (C.discordId.empty()) C.discordId = DISCORD_APP_ID;
}

static double Now() {
    static LARGE_INTEGER f = [] { LARGE_INTEGER x; QueryPerformanceFrequency(&x); return x; }();
    LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart / f.QuadPart;
}

// ------------------------------------------------------------------------------------------------
// shared game state (written on the Unity main thread, read by the output thread)
// ------------------------------------------------------------------------------------------------
enum Cat { CatNone, CatPistol, CatRifle, CatShotgun, CatSMG, CatLMG, CatSniper, CatRocket, CatMelee };
enum WState { WReady, WFiring, WReloading, WCooldown, WPutAway, WLiftingUp, WFireRecovery, WOverheated };
enum Surface { SDefault, SStone, SGravel, SMud, SMetal, SShrub, SWood, SHumanoid, SSnow, SNone };

struct Weapon {
    int cat = CatNone; float tbs = 0.2f; int mag = 0; float heatUp = 0; int pellets = 1; int burst = 1;
    int chargeMode = 0; float reloadTime = 1.5f; char title[64] = {};
};

struct State {
    bool inGame = false; double lastUpdate = 0;
    float hp = 1, hpMax = 1, sh = 0, shMax = 0; int downed = 0; bool dead = false;
    int wstate = WReady; int magAmmo = 0; float charge = 0, heat = 0; bool targeting = false;
    Weapon w;
    int surface = SDefault; float speed = 0; float sprint = 0;
    int abState = -1; float abCharge = 0; int sceneSurface = SDefault;
    int abCount = 0; int abAll[3] = {-1, -1, -1};
};
static std::mutex g_stMx;
static State g_st;

struct Diag { std::atomic<int> fire{0}, hit{0}, step{0}, ability{0}, reload{0}, hitch{0}; std::atomic<float> speed{0}; } g_diag;

// events (main thread -> output thread)
enum EvType { EvFire, EvHit, EvReload, EvSwap, EvDeath, EvRevive, EvStep, EvAbility, EvTargetStart, EvUi };
struct Event { EvType t; float a = 0; int i = 0; double time = 0; };
static std::mutex g_evMx;
static std::vector<Event> g_events;
static void Push(EvType t, float a = 0, int i = 0) {
    if (t == EvFire) ++g_diag.fire; else if (t == EvHit) ++g_diag.hit; else if (t == EvStep) ++g_diag.step; else if (t == EvAbility) ++g_diag.ability; else if (t == EvReload) ++g_diag.reload;
    switch (t) {
    case EvFire: KB::Event(KB::Fire, a, i); break; case EvHit: KB::Event(KB::Hit, a, i); break;
    case EvReload: KB::Event(KB::Reload, a, i); break; case EvSwap: KB::Event(KB::Swap, a, i); break;
    case EvDeath: KB::Event(KB::Death); break; case EvRevive: KB::Event(KB::Revive); break;
    case EvAbility: KB::Event(KB::Ability, a, i); break; case EvTargetStart: KB::Event(KB::TargetStart); break;
    case EvUi: if (i == 4) KB::Event(KB::UiConfirm); else if (i == 5) KB::Event(KB::UiTab); break;
    default: break;
    }
    std::lock_guard<std::mutex> lk(g_evMx);
    if (g_events.size() < 256) g_events.push_back({t, a, i, Now()});
}

// game's own rumble requests
static std::atomic<float> g_gameLo{0}, g_gameHi{0};
static std::atomic<double> g_gameRumbleTime{0};
static std::atomic<bool> g_outputActive{false};
static std::atomic<bool> g_inMission{false};   // gyro only in real missions, never in the hub / quarters / lobby
static std::atomic<bool> g_activeDs{false};   // the controller being driven right now is a DualSense

// gyro / touchpad (output thread -> main thread)
static std::atomic<float> g_gyroYaw{0};        // integrated radians while aiming
static std::atomic<int> g_pendingSwap{0};      // -1 / +1
static std::atomic<bool> g_pendingReload{false};
static std::atomic<int> g_radioClip{-1};       // dialogue line to replay on the speaker
static std::atomic<bool> g_radioStop{false};
static std::atomic<int> g_tpX{-1}, g_tpY{-1};      // finger on the touchpad (0..1919, 0..1079), -1 = none
static std::atomic<double> g_tgtTime{0};           // last frame the local player was choosing a target
static HWND g_gameWnd = nullptr;

// ------------------------------------------------------------------------------------------------
// IL2CPP resolution
// ------------------------------------------------------------------------------------------------
static uintptr_t g_ga;
struct Off {
    // GameEntity (native struct, offsets without object header)
    size_t e_id = 0x0, e_pos = 0x28, e_terrain = 0x12, e_downed = 0x13, e_vel = 0x44, e_health = 0xf0, e_shield = 0x100, e_sprint = 0x264;
    // HealthState
    size_t h_cur = 0x0, h_max = 0x4;
    // ShieldState.health
    size_t s_health = 0x10;
    // ClientUpdateResult
    size_t w_ctrl = 0x6c;
    // WeaponState
    size_t ws_mag = 0x14, ws_state = 0x18, ws_charge = 0x30, ws_heat = 0x38, ws_fire = 0x6a;
    // HitEventData / HitEventDamageInfo
    size_t hit_dmg = 0x14, di_hp = 0x0c, di_sh = 0x10;
    // WeaponDefinitionSO (object)
    size_t wd_cat = 0x33, wd_mag = 0xe2, wd_reload = 0xe8, wd_tbs = 0xec, wd_pellets = 0x15b, wd_burst = 0x1d8, wd_heat = 0x244, wd_charge = 0x200, wd_title = 0x278;
    // AbilitySlot (native)
    size_t ab_last = 0x0c, ab_state = 0x2d, ab_cool = 0x14, ab_size = 0x38;
    // NkCharacterAnimatorController / EntityDisplay (objects)
    size_t ac_terrain = 0xb8, ed_abilityTime = 0x160;
} O;

static const Il2CppImage* FindImage(Il2CppDomain* d, const char* name) {
    size_t n = 0; auto as = il2cpp_domain_get_assemblies(d, &n);
    for (size_t i = 0; i < n; ++i) { auto img = il2cpp_assembly_get_image(as[i]); if (strcmp(il2cpp_image_get_name(img), name) == 0) return img; }
    return nullptr;
}
static size_t FOff(Il2CppClass* k, const char* f, size_t def, bool valueType) {
    if (!k) return def;
    FieldInfo* fi = il2cpp_class_get_field_from_name(k, f);
    if (!fi) { Log("field %s not found, using 0x%zx", f, def); return def; }
    size_t o = il2cpp_field_get_offset(fi);
    return valueType ? o - 0x10 : o;
}
static const MethodInfo* FindMethod(Il2CppClass* k, const char* name, int argc, int typedArg = -1, const char* typeHas = nullptr) {
    if (!k) return nullptr;
    void* it = nullptr; const MethodInfo* m;
    while ((m = il2cpp_class_get_methods(k, &it))) {
        if (strcmp(il2cpp_method_get_name(m), name) != 0) continue;
        if (argc >= 0 && (int)il2cpp_method_get_param_count(m) != argc) continue;
        if (typedArg >= 0) {
            char* tn = il2cpp_type_get_name(il2cpp_method_get_param(m, typedArg));
            bool ok = tn && strstr(tn, typeHas); if (tn) il2cpp_free(tn);
            if (!ok) continue;
        }
        return m;
    }
    return nullptr;
}
static int EnumVal(Il2CppClass* k, const char* name, int def) {
    if (!k) return def;
    FieldInfo* fi = il2cpp_class_get_field_from_name(k, name);
    if (!fi) return def;
    int v = 0; il2cpp_field_static_get_value(fi, &v);
    return v & 0xff;
}
static int g_catMap[256], g_wsMap[256], g_abMap[256];
enum AbSt { AbFails, AbReady, AbActive, AbCooldown, AbOut, AbDisabled, AbCharging };
static std::atomic<int> g_abSel{0};
using GetSel_t = int (*)(void*, const MethodInfo*);
static GetSel_t g_getSel; static const MethodInfo* g_getSelMi;
static const MethodInfo *g_getScene, *g_sceneName;
static std::atomic<bool> g_sceneDirty{false};
typedef void (*SceneChg_t)(int32_t, int32_t, const MethodInfo*);
static SceneChg_t o_SceneChg;
static void h_SceneChg(int32_t a, int32_t b, const MethodInfo* mi) { o_SceneChg(a, b, mi); g_sceneDirty = true; DLAA::ResetHistory(); }

// AbilitySlot accessors (compiled static helpers)
using AbArr_t = uint8_t* (*)(uint8_t*, const MethodInfo*);
using AbLen_t = int64_t (*)(uint8_t*, const MethodInfo*);
static AbArr_t g_abArr; static AbLen_t g_abLen; static const MethodInfo *g_abArrMi, *g_abLenMi;

// CharacterInputController helpers for touchpad
using ReqChange_t = void (*)(void*, int8_t, const MethodInfo*);
using ReqReload_t = void (*)(void*, const MethodInfo*);
static ReqChange_t g_reqChange; static const MethodInfo* g_reqChangeMi;
static ReqReload_t g_reqReload; static const MethodInfo* g_reqReloadMi;

// ------------------------------------------------------------------------------------------------
// hooks
// ------------------------------------------------------------------------------------------------
static uint32_t g_localId = 0xffffffff;
static inline bool IsLocal(uint8_t* world, uint8_t* ent) {
    if (!world || !ent) return false;
    uint32_t ctrl = *(uint32_t*)(world + O.w_ctrl);
    g_localId = ctrl;
    return *(uint32_t*)(ent + O.e_id) == ctrl;
}

static void ReadWeaponDef(void* def, Weapon& w) {
    if (!def) return;
    uint8_t* p = (uint8_t*)def;
    w.cat = g_catMap[p[O.wd_cat]];
    w.mag = *(uint16_t*)(p + O.wd_mag);
    w.reloadTime = *(float*)(p + O.wd_reload);
    w.tbs = *(float*)(p + O.wd_tbs);
    w.pellets = p[O.wd_pellets];
    w.burst = p[O.wd_burst];
    w.heatUp = *(float*)(p + O.wd_heat);
    w.chargeMode = p[O.wd_charge];
    w.title[0] = 0;
    void* str = *(void**)(p + O.wd_title);
    if (str) {   // System.String: length @0x10, chars @0x14
        int len = *(int*)((uint8_t*)str + 0x10); const wchar_t* c = (const wchar_t*)((uint8_t*)str + 0x14);
        WideCharToMultiByte(CP_UTF8, 0, c, std::min(len, 30), w.title, sizeof(w.title) - 1, nullptr, nullptr);
    }
}


// ---- Discord: who and where
static FieldInfo* g_runnerInst; static const MethodInfo *g_profMi, *g_charMi; static size_t g_pcName = 0x20, g_pcClass = 0x38, g_pcLevel = 0x4c;
static std::wstring g_curScene;
static std::mutex g_drpMx; static std::wstring g_drpLine;   // "Медик, 12 ур." for the game's own Discord status
static void DrpResend();
static void UpdatePresence() {
    if (!C.discord) return;
    static double next = 0; double now = Now(); if (now < next) return; next = now + 5;
    DRP::Info i; i.menu = false; { std::lock_guard<std::mutex> lk(g_stMx); i.scene = g_curScene; }
    if (g_runnerInst && g_profMi && g_charMi) {
        void* runner = nullptr; il2cpp_field_static_get_value(g_runnerInst, &runner);
        Il2CppObject* exc = nullptr;
        Il2CppObject* prof = runner ? il2cpp_runtime_invoke(g_profMi, runner, nullptr, &exc) : nullptr;
        Il2CppObject* ch = prof && !exc ? il2cpp_runtime_invoke(g_charMi, prof, nullptr, &exc) : nullptr;
        if (ch && !exc) {
            uint8_t* c = (uint8_t*)ch;
            auto str = [](void* p) { if (!p) return std::wstring(); int n = *(int*)((uint8_t*)p + 0x10); return std::wstring((const wchar_t*)((uint8_t*)p + 0x14), std::min(n, 64)); };
            i.hero = str(*(void**)(c + g_pcName)); i.cls = str(*(void**)(c + g_pcClass)); i.level = *(int*)(c + g_pcLevel);
        }
    }
    std::wstring line;
    if (!i.cls.empty()) { std::wstring cl = i.cls; for (auto& ch : cl) ch = towlower(ch); line = DRP::ClassName(cl); }
    if (i.level) line += (line.empty() ? L"" : L", ") + std::to_wstring(i.level) + L" ур.";
    if (!i.hero.empty()) line = i.hero + (line.empty() ? L"" : L" (" + line + L")");
    { std::lock_guard<std::mutex> lk(g_drpMx); g_drpLine = line; }
    DrpResend();
}
// the game sends its own Discord activity ("Гуляет по «Эгиде»", "Играет: …"); add who is playing to it
static const MethodInfo *g_actSetDetails, *g_actSetState, *g_actDetails, *g_actState;
typedef void (*UpdRP_t)(void*, void*, void*, const MethodInfo*);
static UpdRP_t o_UpdRP;
static uint32_t g_rpH[3]; static const MethodInfo* g_rpMi; static std::wstring g_rpSent;   // strong GC handles: the objects must stay alive for a re-send
static void h_UpdRP(void* client, void* activity, void* cb, const MethodInfo* mi) {
    std::wstring line; { std::lock_guard<std::mutex> lk(g_drpMx); line = g_drpLine; }
    g_rpMi = mi; g_rpSent = line;
    { static int n = 0; if (n++ < 12) Log("discord: game status update #%d, our line %s", n, line.empty() ? "not ready" : "added"); }
    if (activity && g_actSetDetails && !line.empty()) {
        Il2CppObject* exc = nullptr;
        auto get = [&](const MethodInfo* m) { if (!m) return std::wstring(); Il2CppObject* r = il2cpp_runtime_invoke(m, activity, nullptr, &exc); if (exc || !r) return std::wstring(); int n = *(int*)((uint8_t*)r + 0x10); return std::wstring((const wchar_t*)((uint8_t*)r + 0x14), std::min(n, 200)); };
        std::wstring det = get(g_actDetails), st = get(g_actState);
        // the game's text stays; ours goes into the free line (or after the game's details)
        const MethodInfo* target = g_actSetDetails; std::wstring text = line;
        if (!det.empty() && det.find(line) == det.npos) {
            if (st.empty() && g_actSetState) { target = g_actSetState; }
            else text = det + L" · " + line;
        } else if (!det.empty()) target = nullptr;
        if (target) {
            std::string u = DRP::U8(text);
            void* args[1] = {il2cpp_string_new(u.c_str())};
            il2cpp_runtime_invoke(target, activity, args, &exc);
        }
    }
    o_UpdRP(client, activity, cb, mi);
}
static void DrpResend() {   // main thread: re-send the game's last activity once our line is known or changed
    std::wstring line; { std::lock_guard<std::mutex> lk(g_drpMx); line = g_drpLine; }
    // Re-sending is disabled: the game disposes its Activity right after the call, so a re-send hands the Discord SDK
    // a freed native object (crash in Discord_RunCallbacks). Our line is added on the game's next status update.
    (void)line;
}
static Il2CppClass* FindClassAny(Il2CppDomain* d, const char* ns, const char* name) {
    size_t n = 0; auto as = il2cpp_domain_get_assemblies(d, &n);
    for (size_t i = 0; i < n; ++i) if (Il2CppClass* k = il2cpp_class_from_name(il2cpp_assembly_get_image(as[i]), ns, name)) return k;
    return nullptr;
}

// per-character per-frame
using UpdAnim_t = void (*)(void*, void*, uint8_t*, void*, void*, uint8_t*, uint8_t*, const MethodInfo*);
static UpdAnim_t o_UpdAnim;
static double g_stepDist = 0; static int g_stepFoot = 0; static float g_lastHp = -1; static int g_lastDowned = 0;
static float g_abLast[8]; static double g_lastFrame = 0;
static void h_UpdAnim(void* self, void* client, uint8_t* world, void* wc, void* disp, uint8_t* ent, uint8_t* aw, const MethodInfo* mi) {
    o_UpdAnim(self, client, world, wc, disp, ent, aw, mi);
    if (!IsLocal(world, ent)) return;
    UpdatePresence();
    double now = Now(); double rawDt = g_lastFrame ? now - g_lastFrame : 0; double dt = std::min(0.1, rawDt); g_lastFrame = now;
    if (rawDt > 0.05 && rawDt < 2.0) ++g_diag.hitch;
    float* pos = (float*)(ent + O.e_pos);
    static float lp[3]; static bool hasLp = false;
    float spd = 0;
    if (hasLp && dt > 0.0005) { float dx = pos[0] - lp[0], dz = pos[2] - lp[2]; spd = sqrtf(dx * dx + dz * dz) / (float)dt; if (spd > 30) spd = 0; }
    memcpy(lp, pos, sizeof lp); hasLp = true;
    { float* vel = (float*)(ent + O.e_vel); float vs = sqrtf(vel[0] * vel[0] + vel[2] * vel[2]); if (vs > spd) spd = vs; }
    static float spdS = 0; spdS = spdS * 0.8f + spd * 0.2f; spd = spdS;
    g_diag.speed = spd;
    State s;
    {
        std::lock_guard<std::mutex> lk(g_stMx);
        g_st.inGame = true; g_st.lastUpdate = now;
        g_st.hp = *(float*)(ent + O.e_health + O.h_cur); g_st.hpMax = *(float*)(ent + O.e_health + O.h_max);
        g_st.sh = *(float*)(ent + O.e_shield + O.s_health + O.h_cur); g_st.shMax = *(float*)(ent + O.e_shield + O.s_health + O.h_max);
        g_st.downed = ent[O.e_downed];
        g_st.surface = self ? *((uint8_t*)self + O.ac_terrain) : ent[O.e_terrain];
        g_st.speed = spd;
        g_st.sprint = *(float*)(ent + O.e_sprint + 4);
        if (aw) {
            g_st.magAmmo = *(uint16_t*)(aw + O.ws_mag);
            g_st.wstate = g_wsMap[aw[O.ws_state]];
            g_st.charge = *(float*)(aw + O.ws_charge + 4);
            g_st.heat = *(float*)(aw + O.ws_heat + 4);
        }
        g_st.dead = g_st.hp <= 0.0f;
        s = g_st;
    }
    // level's main ground material (used when the physics category is just "Default")
    static double nextScene = 0;
    if (g_getScene && g_sceneName && (now > nextScene || g_sceneDirty.exchange(false))) {
        nextScene = now + 1e9;   // once; afterwards only when the active scene changes
        Il2CppObject* exc = nullptr;
        Il2CppObject* boxed = il2cpp_runtime_invoke(g_getScene, nullptr, nullptr, &exc);
        if (boxed && !exc) {
            Il2CppObject* str = il2cpp_runtime_invoke(g_sceneName, (uint8_t*)boxed + 0x10, nullptr, &exc);
            if (str && !exc) {
                int len = *(int*)((uint8_t*)str + 0x10); const wchar_t* c = (const wchar_t*)((uint8_t*)str + 0x14);
                std::wstring n(c, std::min(len, 120)); for (auto& ch : n) ch = towlower(ch);
                static std::wstring lastScene;
                int sf = SDefault;
                if (n.find(L"ice") != n.npos || n.find(L"snow") != n.npos || n.find(L"frozen") != n.npos) sf = SSnow;
                else if (n.find(L"hub") != n.npos || n.find(L"aegis") != n.npos || n.find(L"regen") != n.npos || n.find(L"void") != n.npos || n.find(L"station") != n.npos) sf = SMetal;
                else if (n.find(L"mining") != n.npos || n.find(L"raktaa") != n.npos || n.find(L"outpost") != n.npos || n.find(L"asteroid") != n.npos) sf = SGravel;
                else if (n.find(L"geode") != n.npos || n.find(L"rupture") != n.npos) sf = SStone;
                else if (n.find(L"colony") != n.npos || n.find(L"terra") != n.npos) sf = SMud;
                else if (n.find(L"prologue") != n.npos || n.find(L"trusgan") != n.npos) sf = SGravel;
                if (n != lastScene) { lastScene = n; char a[128] = {}; WideCharToMultiByte(CP_UTF8, 0, n.c_str(), -1, a, 127, 0, 0); Log("scene: %s -> ground %d", a, sf); }
                { std::lock_guard<std::mutex> lk(g_stMx); g_curScene = n; }
                g_inMission = n.rfind(L"mission_", 0) == 0 || n.rfind(L"op_", 0) == 0 || n.find(L"prologue") != n.npos || n.find(L"operation") != n.npos;
                std::lock_guard<std::mutex> lk(g_stMx); g_st.sceneSurface = sf;
            }
        }
    }
    // selected ability slot state for the L2 trigger
    if (g_abArr && g_abLen) {
        uint8_t* arr = g_abArr(ent, g_abArrMi); int64_t n = g_abLen(ent, g_abLenMi);
        int sel = g_abSel; if (sel < 0 || sel >= n) sel = 0;
        std::lock_guard<std::mutex> lk(g_stMx);
        if (arr && n > 0) {
            uint8_t* slot = arr + sel * O.ab_size;
            g_st.abState = g_abMap[slot[O.ab_state]];
            float cs = *(float*)(slot + O.ab_cool - 0x0c);   // charge_start_time sits 3 floats before cooldown
            (void)cs; g_st.abCharge = 0;
        } else g_st.abState = -1;
        g_st.abCount = (int)std::min<int64_t>(3, arr ? n : 0);
        for (int i = 0; i < g_st.abCount; ++i) g_st.abAll[i] = g_abMap[arr[i * O.ab_size + O.ab_state]];
    }
    {
        KB::State k; State c; { std::lock_guard<std::mutex> lk(g_stMx); c = g_st; }
        k.inGame = true; k.mission = g_inMission; k.dead = c.dead; k.targeting = c.targeting; k.reloading = c.wstate == WReloading;
        k.moving = spd > 0.6f; k.downed = c.downed; k.hp = c.hp; k.hpMax = c.hpMax; k.sh = c.sh; k.shMax = c.shMax;
        k.mag = c.magAmmo; k.magMax = c.w.mag; k.abCount = c.abCount;
        for (int i = 0; i < 3; ++i) { int a = c.abAll[i]; k.ab[i] = a == AbReady ? KB::AbReady : a == AbActive ? KB::AbActive : a == AbCooldown ? KB::AbCooldown : a == AbOut ? KB::AbOut : a == AbCharging ? KB::AbCharging : a < 0 ? KB::AbNone : KB::AbOut; }
        KB::Update(k);
    }
    // damage that did not come through OnHit (poison, void, fall)
    if (g_lastHp >= 0 && s.hp < g_lastHp - 0.5f && s.hpMax > 0) Push(EvHit, (g_lastHp - s.hp) / s.hpMax, 1);
    g_lastHp = s.hp;
    // footsteps from distance travelled (stride ~1.25 m walking, longer when sprinting)
    if (C.footsteps && spd > 0.6f && !s.dead) {
        g_stepDist += spd * dt;
        double stride = 1.25 + 0.5 * std::min(1.0f, s.sprint);
        int surf = (s.surface == SDefault || s.surface >= SNone) ? s.sceneSurface : s.surface;
        if (g_stepDist >= stride) { g_stepDist = 0; g_stepFoot ^= 1; Push(EvStep, std::min(1.0f, spd / 7.0f), (surf << 1) | g_stepFoot); }
    } else g_stepDist = 0.9;
    // abilities: EntityDisplay.lastAbilityTriggerTime changes whenever the player triggers one
    if (disp) {
        static double lastAb = -1;
        double t = *(double*)((uint8_t*)disp + O.ed_abilityTime);
        if (lastAb >= 0 && t != lastAb && t > 0) {
            int slot = 0; float cool = 20;
            if (g_abArr && g_abLen) {
                uint8_t* arr = g_abArr(ent, g_abArrMi); int64_t n = g_abLen(ent, g_abLenMi); float best = -1;
                for (int64_t i = 0; arr && i < n && i < 8; ++i) { float lt = *(float*)(arr + i * O.ab_size + O.ab_last); if (lt > best) { best = lt; slot = (int)i; cool = *(float*)(arr + i * O.ab_size + O.ab_cool); } }
            }
            Push(EvAbility, cool, slot);
        }
        lastAb = t;
    }
    if (false) {
    // (old) abilities: detect a new trigger time on any activated slot
    if (g_abArr && g_abLen) {
        uint8_t* arr = g_abArr(ent, g_abArrMi); int64_t n = g_abLen(ent, g_abLenMi);
        for (int64_t i = 0; arr && i < n && i < 8; ++i) {
            float lt = *(float*)(arr + i * O.ab_size + O.ab_last);
            if (g_abLast[i] != 0 && lt != g_abLast[i] && lt > 0) Push(EvAbility, *(float*)(arr + i * O.ab_size + O.ab_cool), (int)i);
            g_abLast[i] = lt;
        }
    }
    }
}

using OnAttack_t = void (*)(void*, uint8_t*, void*, void*, uint8_t*, void*, uint8_t, const MethodInfo*);
static OnAttack_t o_OnAttack;
static void h_OnAttack(void* self, uint8_t* world, void* wc, void* disp, uint8_t* ent, void* def, uint8_t idx, const MethodInfo* mi) {
    o_OnAttack(self, world, wc, disp, ent, def, idx, mi);
    if (!IsLocal(world, ent)) return;
    Weapon w; ReadWeaponDef(def, w);
    { std::lock_guard<std::mutex> lk(g_stMx); g_st.w = w; }
    Push(EvFire, 1.0f, w.cat);
}

using OnReload_t = void (*)(void*, uint8_t*, void*, void*, uint8_t*, void*, uint8_t, const MethodInfo*);
static OnReload_t o_OnReload;
static void h_OnReload(void* self, uint8_t* world, void* wc, void* disp, uint8_t* ent, void* def, uint8_t idx, const MethodInfo* mi) {
    o_OnReload(self, world, wc, disp, ent, def, idx, mi);
    if (!IsLocal(world, ent)) return;
    Weapon w; ReadWeaponDef(def, w);
    { std::lock_guard<std::mutex> lk(g_stMx); g_st.w = w; }
    Push(EvReload, w.reloadTime, w.cat);
}

using OnLift_t = void (*)(void*, uint8_t*, void*, void*, uint8_t*, void*, const MethodInfo*);
static OnLift_t o_OnLift;
static void h_OnLift(void* self, uint8_t* world, void* wc, void* disp, uint8_t* ent, void* def, const MethodInfo* mi) {
    o_OnLift(self, world, wc, disp, ent, def, mi);
    if (!IsLocal(world, ent) || !def) return;
    Weapon w; ReadWeaponDef(def, w);
    { std::lock_guard<std::mutex> lk(g_stMx); g_st.w = w; }
    Log("weapon: %s cat=%d tbs=%.3f mag=%d heat=%.2f pellets=%d charge=%d", w.title, w.cat, w.tbs, w.mag, w.heatUp, w.pellets, w.chargeMode);
    Push(EvSwap, 0, w.cat);
}

using OnHit_t = void (*)(void*, uint8_t*, void*, void*, uint8_t*, uint8_t*, const MethodInfo*);
static OnHit_t o_OnHit;
static void h_OnHit(void* self, uint8_t* world, void* wc, void* disp, uint8_t* ent, uint8_t* hit, const MethodInfo* mi) {
    o_OnHit(self, world, wc, disp, ent, hit, mi);
    if (!IsLocal(world, ent) || !hit) return;
    float dh = *(float*)(hit + O.hit_dmg + O.di_hp), ds = *(float*)(hit + O.hit_dmg + O.di_sh);
    float mx; { std::lock_guard<std::mutex> lk(g_stMx); mx = std::max(1.0f, g_st.hpMax); }
    g_lastHp = -1;   // avoid double counting in the poll
    Push(EvHit, std::min(1.0f, (dh + ds * 0.5f) / mx * 3.0f + 0.15f), 0);
}

using Ent4_t = void (*)(void*, uint8_t*, void*, void*, uint8_t*, const MethodInfo*);
static Ent4_t o_Death, o_Revive, o_Targeting, o_Prep;
static void h_Death(void* s, uint8_t* w, void* wc, void* d, uint8_t* e, const MethodInfo* mi) { o_Death(s, w, wc, d, e, mi); if (IsLocal(w, e)) Push(EvDeath); }
static void h_Revive(void* s, uint8_t* w, void* wc, void* d, uint8_t* e, const MethodInfo* mi) { o_Revive(s, w, wc, d, e, mi); if (IsLocal(w, e)) Push(EvRevive); }
static void h_Targeting(void* s, uint8_t* w, void* wc, void* d, uint8_t* e, const MethodInfo* mi) {
    o_Targeting(s, w, wc, d, e, mi);
    if (IsLocal(w, e)) { g_tgtTime = Now(); std::lock_guard<std::mutex> lk(g_stMx); g_st.targeting = true; }
}
static void h_Prep(void* s, uint8_t* w, void* wc, void* d, uint8_t* e, const MethodInfo* mi) {
    o_Prep(s, w, wc, d, e, mi);
    if (IsLocal(w, e)) { g_tgtTime = Now(); Push(EvTargetStart); std::lock_guard<std::mutex> lk(g_stMx); g_st.targeting = true; }
}

// aim: gyro fine-aim + touchpad actions (runs on the main thread with the input controller)
struct V2 { float x, y; };
using DoAim_t = void (*)(void*, void*, void*, void*, uint8_t*, uint64_t, bool, const MethodInfo*);
static DoAim_t o_DoAim;
static std::atomic<bool> g_aiming{false};
static std::atomic<bool> g_rightStick{false};
static void h_DoAim(void* self, void* res, void* client, void* wc, uint8_t* ent, uint64_t aimBits, bool isPointer, const MethodInfo* mi) {
    if (g_reqChange) { int sw = g_pendingSwap.exchange(0); if (sw) g_reqChange(self, (int8_t)sw, g_reqChangeMi); }
    if (g_reqReload && g_pendingReload.exchange(false)) g_reqReload(self, g_reqReloadMi);
    if (g_getSel) g_abSel = g_getSel(self, g_getSelMi);
    // touchpad = point on the screen while choosing where to throw a grenade / place a turret / aim an ability
    if (C.touchAim && g_activeDs && g_inMission && Now() - g_tgtTime < 0.3 && g_tpX >= 0 && g_gameWnd) {
        RECT rc{}; GetClientRect(g_gameWnd, &rc);
        if (rc.right > 0 && rc.bottom > 0) {
            V2 p{g_tpX / 1919.f * rc.right, (1.f - g_tpY / 1079.f) * rc.bottom};
            uint64_t bits; memcpy(&bits, &p, 8);
            static bool told = false; if (!told) { told = true; Log("touch aim: pointer %.0f,%.0f", p.x, p.y); }
            o_DoAim(self, res, client, wc, ent, bits, true, mi); return;
        }
    }
    V2 v; memcpy(&v, &aimBits, 8);
    float mag = sqrtf(v.x * v.x + v.y * v.y);
    bool aiming = !isPointer && mag > 0.3f && (!g_activeDs || g_rightStick);
    g_aiming = aiming;
    if (aiming && g_activeDs && C.gyro && g_inMission) {
        float a = g_gyroYaw.load();
        float c = cosf(a), sn = sinf(a);
        V2 r{v.x * c - v.y * sn, v.x * sn + v.y * c};
        memcpy(&aimBits, &r, 8);
    }
    o_DoAim(self, res, client, wc, ent, aimBits, isPointer, mi);
}

// Unity Input System: catch the game's rumble so we merge it with ours (and stop Unity from
// overwriting our DualSense reports)
using Motor_t = void (*)(void*, float, float, const MethodInfo*);
static Motor_t o_GpMotor, o_DsMotor;
static void h_GpMotor(void* s, float lo, float hi, const MethodInfo* mi) {
    g_gameLo = lo; g_gameHi = hi; g_gameRumbleTime = Now();
    if (!g_outputActive) o_GpMotor(s, lo, hi, mi);
}
static void h_DsMotor(void* s, float lo, float hi, const MethodInfo* mi) {
    g_gameLo = lo; g_gameHi = hi; g_gameRumbleTime = Now();
    if (!g_outputActive || !g_activeDs) o_DsMotor(s, lo, hi, mi);
}
using DsMotorLb_t = bool (*)(void*, uint64_t, uint64_t, void*, const MethodInfo*);
static DsMotorLb_t o_DsMotorLb;
static bool h_DsMotorLb(void* s, uint64_t lo, uint64_t hi, void* col, const MethodInfo* mi) {
    if (lo & 0xff) { float f; uint32_t b = (uint32_t)(lo >> 32); memcpy(&f, &b, 4); g_gameLo = f; g_gameRumbleTime = Now(); }
    if (hi & 0xff) { float f; uint32_t b = (uint32_t)(hi >> 32); memcpy(&f, &b, 4); g_gameHi = f; g_gameRumbleTime = Now(); }
    if (g_outputActive && g_activeDs) return true;
    return o_DsMotorLb(s, lo, hi, col, mi);
}
using DsLb_t = void (*)(void*, void*, const MethodInfo*);
static DsLb_t o_DsLb;
static void h_DsLb(void* s, void* col, const MethodInfo* mi) { if (!(g_outputActive && g_activeDs)) o_DsLb(s, col, mi); }

// menu feel: tiny ticks on navigation, a click on press, detents on sliders
enum UiEv { UiSelect, UiClick, UiSlider, UiToggle, UiConfirm, UiTab };
static std::atomic<double> g_uiLast{0};
static void UiPush(int k) {
    double n = Now();
    if (k == UiSelect && n - g_uiLast < 0.03) return;
    if (k == UiSlider && n - g_uiLast < 0.035) return;
    g_uiLast = n; Push(EvUi, 0, k);
}
using Sel_t = void (*)(void*, void*, const MethodInfo*);
static Sel_t o_SelOnSelect, o_ZaOnSelect;
static void h_SelOnSelect(void* s, void* e, const MethodInfo* mi) { o_SelOnSelect(s, e, mi); UiPush(UiSelect); }
static void h_ZaOnSelect(void* s, void* e, const MethodInfo* mi) { o_ZaOnSelect(s, e, mi); UiPush(UiSelect); }
using V0_t = void (*)(void*, const MethodInfo*);
static V0_t o_Click;
static void h_Click(void* s, const MethodInfo* mi) { o_Click(s, mi); if (Now() - g_uiLast > 0.08) UiPush(UiClick); }
using Sub_t = void (*)(void*, void*, const MethodInfo*);
static Sub_t o_Submit;
static void h_Submit(void* s, void* ctx, const MethodInfo* mi) { o_Submit(s, ctx, mi); g_uiLast = 0; UiPush(UiConfirm); }
static V0_t o_BtnPress;
static void h_BtnPress(void* s, const MethodInfo* mi) { o_BtnPress(s, mi); if (Now() - g_uiLast > 0.08) { g_uiLast = 0; UiPush(UiConfirm); } }
using Tab_t = void (*)(void*, int, const MethodInfo*);
static Tab_t o_ZaTab, o_SetTab, o_SocTab;
static void h_ZaTab(void* s, int i, const MethodInfo* mi) { o_ZaTab(s, i, mi); g_uiLast = 0; UiPush(UiTab); }
static void h_SetTab(void* s, int d, const MethodInfo* mi) { o_SetTab(s, d, mi); g_uiLast = 0; UiPush(UiTab); }
static void h_SocTab(void* s, int t, const MethodInfo* mi) { o_SocTab(s, t, mi); g_uiLast = 0; UiPush(UiTab); }
using SliderSet_t = void (*)(void*, float, bool, const MethodInfo*);
static SliderSet_t o_SliderSet;
static void h_SliderSet(void* s, float v, bool cb, const MethodInfo* mi) { o_SliderSet(s, v, cb, mi); if (cb) UiPush(UiSlider); }
using ToggleSet_t = void (*)(void*, bool, bool, const MethodInfo*);
static ToggleSet_t o_ToggleSet;
static void h_ToggleSet(void* s, bool v, bool cb, const MethodInfo* mi) { o_ToggleSet(s, v, cb, mi); if (cb) UiPush(UiToggle); }


// ---- Wwise event log (to find which sounds the game plays for abilities / weapon swaps)
struct AkRec { uint32_t id; double t; };
static AkRec g_akRing[256]; static std::atomic<uint32_t> g_akPos{0};
typedef uint32_t (*AkPostId_t)(uint32_t, uint64_t, uint32_t, void*, void*, uint32_t, void*, uint32_t);
typedef uint32_t (*AkPostName_t)(const char*, uint64_t, uint32_t, void*, void*, uint32_t, void*, uint32_t);
static AkPostId_t o_AkPostId; static AkPostName_t o_AkPostName;
static uint32_t (*g_akGetId)(const char*);
static int FxOf(uint32_t id) {
    using namespace AKE;
    switch (id) {
    case Ability_Adrenaline: return KB::FxAdrenaline; case Ability_Biocleanse: return KB::FxBiocleanse; case Ability_Dash: return KB::FxDash;
    case Ability_DieAnotherDay: return KB::FxDieAnotherDay; case Ability_Haven: return KB::FxHaven; case Ability_HoldTheLine: return KB::FxHoldTheLine;
    case Ability_KineticBurst: return KB::FxKinetic; case Ability_Medkit: return KB::FxMedkit; case Ability_Orbital_Aim: return KB::FxOrbitalAim;
    case Ability_Orbital_Fire: return KB::FxOrbitalFire; case PlayerEquipGun: return KB::FxEquip; case Ability_CooldownComplete: return KB::FxCooldown;
    case TurretSpawn: return KB::FxTurret;
    }
    return 0;
}
struct AkFx { int fx; uint32_t id; double t; };
static std::mutex g_akMx; static std::vector<AkFx> g_akq;
static uint32_t AkHash(const char* n) { uint32_t h = 2166136261u; for (; *n; ++n) { h *= 16777619u; h ^= (uint8_t)tolower((uint8_t)*n); } return h; }
static void AkNote(uint32_t id) {
    static uint32_t lastId; static double lastT;
    double t = Now(); if (id == lastId && t - lastT < 0.03) return; lastId = id; lastT = t;
    uint32_t i = g_akPos++ & 255; g_akRing[i] = {id, t};
    if (int fx = FxOf(id)) { KB::Event(KB::FxRaw, 0, fx); std::lock_guard<std::mutex> lk(g_akMx); if (g_akq.size() < 32) g_akq.push_back({fx, id, t}); }
}
// ---- game sounds that play on the DualSense speaker *instead of* the PC: the event is re-posted on a game object
// with no listeners (silent, but callbacks / timing stay intact) and the same sound from ZASfx.dat plays in the controller.
static std::atomic<bool> g_spkLive{false}, g_voiceLive{false};
static constexpr uint64_t kMuteGo = 0x5A50AD0000000001ull;
typedef int (*AkRegGo_t)(uint64_t); typedef int (*AkSetLis_t)(uint64_t, const uint64_t*, uint32_t);
typedef int (*AkSwId_t)(uint32_t, uint32_t, uint64_t); typedef int (*AkSwNm_t)(const char*, const char*, uint64_t);
typedef int (*AkRtId_t)(uint32_t, float, uint64_t, int, int, bool); typedef int (*AkRtNm_t)(const char*, float, uint64_t, int, int, bool);
static AkRegGo_t p_AkRegGo; static AkSetLis_t p_AkSetLis; static AkSwId_t o_AkSwId, p_AkSwId; static AkSwNm_t o_AkSwNm; static AkRtId_t o_AkRtId; static AkRtNm_t o_AkRtNm;
static std::mutex g_goMx; static std::unordered_map<uint64_t, std::vector<std::pair<uint32_t, uint32_t>>> g_goSw; static std::unordered_set<uint64_t> g_localGo;
static bool g_muteReady = false;
static std::mutex g_sfxMx; static std::vector<uint32_t> g_sfxq;
static void NoteSwitch(uint32_t grp, uint32_t st, uint64_t go) {
    if (go == kMuteGo) return;
    std::lock_guard<std::mutex> lk(g_goMx); auto& v = g_goSw[go];
    for (auto& x : v) if (x.first == grp) { x.second = st; return; }
    v.push_back({grp, st});
}
static void NoteLocal(float v, uint64_t go) { std::lock_guard<std::mutex> lk(g_goMx); if (v > 0.5f) g_localGo.insert(go); else g_localGo.erase(go); }
static int h_AkSwId(uint32_t g, uint32_t st, uint64_t go) { NoteSwitch(g, st, go); return o_AkSwId(g, st, go); }
static int h_AkSwNm(const char* g, const char* st, uint64_t go) { if (g && st) NoteSwitch(AkHash(g), AkHash(st), go); return o_AkSwNm(g, st, go); }
static int h_AkRtId(uint32_t id, float v, uint64_t go, int ms, int c, bool b) { if (id == AKR::IsLocalPlayer) NoteLocal(v, go); return o_AkRtId(id, v, go, ms, c, b); }
static int h_AkRtNm(const char* nm, float v, uint64_t go, int ms, int c, bool b) { if (nm && AkHash(nm) == AKR::IsLocalPlayer) NoteLocal(v, go); return o_AkRtNm(nm, v, go, ms, c, b); }
typedef int (*AkStId_t)(uint32_t, uint32_t); typedef int (*AkStNm_t)(const char*, const char*);
static AkStId_t o_AkStId; static AkStNm_t o_AkStNm;
static int h_AkStId(uint32_t g, uint32_t st) { Log("wwise state %u = %u", g, st); return o_AkStId(g, st); }
static int h_AkStNm(const char* g, const char* st) { Log("wwise state %s = %s", g ? g : "?", st ? st : "?"); return o_AkStNm(g, st); }
template <size_t N> static bool InIds(const uint32_t (&a)[N], uint32_t v) { return std::binary_search(a, a + N, v); }
// 0 = leave it to the game, 1 = dialogue (radio plays from the subtitle), otherwise the ZASfx key to play
static uint32_t RouteOf(uint32_t ev, uint64_t go) {
    if (go == kMuteGo || !p_AkRegGo || !p_AkSetLis) return 0;
    if (InIds(AKR::Dialogue, ev)) {
        if (!g_voiceLive || !g_inMission) return 0;
        std::lock_guard<std::mutex> lk(g_goMx); auto it = g_goSw.find(go); if (it == g_goSw.end()) return 0;
        for (auto& x : it->second) if (x.first == AKR::CharGroup) return InIds(AKR::RadioChars, x.second) ? 1 : 0;
        return 0;
    }
    if (!g_spkLive) return 0;
    uint32_t key = ev;
    std::lock_guard<std::mutex> lk(g_goMx);
    if (ev == AKR::WeaponReload) {
        auto it = g_goSw.find(go);
        if (it != g_goSw.end()) for (auto& x : it->second) if (x.first == AKR::WeaponTypeGroup && SPK::g_sfx.Lookup(ev ^ x.second)) key = ev ^ x.second;
    }
    if (!SPK::g_sfx.Lookup(key)) return 0;
    if (InIds(AKR::LocalOnly, ev) && !g_localGo.empty() && !g_localGo.count(go)) return 0;
    return key;
}
static bool MuteGo(uint64_t from) {
    if (!g_muteReady) {
        int a = p_AkRegGo(kMuteGo), b = p_AkSetLis(kMuteGo, nullptr, 0);
        g_muteReady = true; Log("speaker routing: muted object ready (reg=%d listeners=%d)", a, b);
    }
    std::vector<std::pair<uint32_t, uint32_t>> sw;
    { std::lock_guard<std::mutex> lk(g_goMx); auto it = g_goSw.find(from); if (it != g_goSw.end()) sw = it->second; }
    for (auto& x : sw) (o_AkSwId ? o_AkSwId : p_AkSwId)(x.first, x.second, kMuteGo);
    return true;
}
static void Routed(uint32_t key) { if (key > 1) { std::lock_guard<std::mutex> lk(g_sfxMx); if (g_sfxq.size() < 16) g_sfxq.push_back(key); } }
static void AkTrace(uint32_t ev, uint64_t go, uint32_t k) {
    static std::mutex mx; static std::unordered_set<uint32_t> seen; std::lock_guard<std::mutex> lk(mx);
    if (seen.size() < 600 && seen.insert(ev).second) Log("wwise event %u go=%llx %s", ev, (unsigned long long)go, k ? (k == 1 ? "-> radio" : "-> speaker") : "");
}
static uint32_t h_AkPostId(uint32_t ev, uint64_t go, uint32_t fl, void* cb, void* ck, uint32_t n, void* ext, uint32_t pid) {
    AkNote(ev);
    if (g_muteReady && InIds(AKR::Stops, ev)) o_AkPostId(ev, kMuteGo, 0, nullptr, nullptr, 0, nullptr, 0);
    uint32_t k = RouteOf(ev, go); AkTrace(ev, go, k);
    if (k) { MuteGo(go); Routed(k); return o_AkPostId(ev, kMuteGo, fl, cb, ck, n, ext, pid); }
    return o_AkPostId(ev, go, fl, cb, ck, n, ext, pid);
}
static uint32_t h_AkPostName(const char* nm, uint64_t go, uint32_t fl, void* cb, void* ck, uint32_t n, void* ext, uint32_t pid) {
    if (!nm) return o_AkPostName(nm, go, fl, cb, ck, n, ext, pid);
    uint32_t ev = AkHash(nm); AkNote(ev);
    if (g_muteReady && InIds(AKR::Stops, ev)) o_AkPostName(nm, kMuteGo, 0, nullptr, nullptr, 0, nullptr, 0);
    uint32_t k = RouteOf(ev, go); AkTrace(ev, go, k);
    if (k) { MuteGo(go); Routed(k); return o_AkPostName(nm, kMuteGo, fl, cb, ck, n, ext, pid); }
    return o_AkPostName(nm, go, fl, cb, ck, n, ext, pid);
}
// find an export by its mangled-name prefix + a fragment of the signature (robust to small SDK differences)
static void* AkExport(HMODULE m, const char* prefix, const char* sig) {
    auto b = (uint8_t*)m; auto nt = (IMAGE_NT_HEADERS*)(b + ((IMAGE_DOS_HEADER*)b)->e_lfanew);
    auto& dd = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT]; if (!dd.VirtualAddress) return nullptr;
    auto ed = (IMAGE_EXPORT_DIRECTORY*)(b + dd.VirtualAddress);
    auto names = (DWORD*)(b + ed->AddressOfNames); auto ords = (WORD*)(b + ed->AddressOfNameOrdinals); auto funcs = (DWORD*)(b + ed->AddressOfFunctions);
    for (DWORD i = 0; i < ed->NumberOfNames; ++i) {
        const char* n = (const char*)(b + names[i]);
        if (strncmp(n, prefix, strlen(prefix)) == 0 && strstr(n, sig)) return b + funcs[ords[i]];
    }
    return nullptr;
}
static void AkDump(const char* why, double t) {
    char buf[1024]; int len = snprintf(buf, sizeof buf, "wwise around %s:", why);
    uint32_t end = g_akPos;
    for (uint32_t k = end > 256 ? end - 256 : 0; k < end && len < 1000; ++k) { auto& r = g_akRing[k & 255]; if (fabs(r.t - t) < 0.6) len += snprintf(buf + len, sizeof buf - len, " %u(%+.2f)", r.id, r.t - t); }
    Log("%s", buf);
}
static void HookWwise() {
    HMODULE ak = nullptr;
    for (int i = 0; i < 300 && !(ak = GetModuleHandleW(L"AkUnitySoundEngine.dll")); ++i) Sleep(100);
    if (!ak) { Log("wwise: AkUnitySoundEngine.dll not loaded"); return; }
    void* a = (void*)GetProcAddress(ak, "?PostEvent@SoundEngine@AK@@YAII_KIP6AXW4AkCallbackType@@PEAUAkEventCallbackInfo@@PEAX3@Z3IPEAUAkExternalSourceInfo@@I@Z");
    void* b = (void*)GetProcAddress(ak, "?PostEvent@SoundEngine@AK@@YAIPEBD_KIP6AXW4AkCallbackType@@PEAUAkEventCallbackInfo@@PEAX4@Z4IPEAUAkExternalSourceInfo@@I@Z");
    int ok = 0;
    if (a && MH_CreateHook(a, (void*)h_AkPostId, (void**)&o_AkPostId) == MH_OK && MH_EnableHook(a) == MH_OK) ++ok;
    if (b && MH_CreateHook(b, (void*)h_AkPostName, (void**)&o_AkPostName) == MH_OK && MH_EnableHook(b) == MH_OK) ++ok;
    p_AkRegGo = (AkRegGo_t)AkExport(ak, "?RegisterGameObj@SoundEngine@AK@@", "@@_K@Z");
    p_AkSetLis = (AkSetLis_t)AkExport(ak, "?SetListeners@SoundEngine@AK@@", "_KPEB_KI@Z");
    void* sw1 = AkExport(ak, "?SetSwitch@SoundEngine@AK@@", "@@II_K@Z"); p_AkSwId = (AkSwId_t)sw1;
    void* sw2 = AkExport(ak, "?SetSwitch@SoundEngine@AK@@", "@@PEBD0_K@Z");
    void* rt1 = AkExport(ak, "?SetRTPCValue@SoundEngine@AK@@", "@@IM_KHW4AkCurveInterpolation@@_N@Z");
    void* rt2 = AkExport(ak, "?SetRTPCValue@SoundEngine@AK@@", "@@PEBDM_KHW4AkCurveInterpolation@@_N@Z");
    int ok2 = 0;
    void* st1 = AkExport(ak, "?SetState@SoundEngine@AK@@", "@@II@Z"); void* st2 = AkExport(ak, "?SetState@SoundEngine@AK@@", "@@PEBD0@Z");
    if (st1 && MH_CreateHook(st1, (void*)h_AkStId, (void**)&o_AkStId) == MH_OK && MH_EnableHook(st1) == MH_OK) ++ok2;
    if (st2 && MH_CreateHook(st2, (void*)h_AkStNm, (void**)&o_AkStNm) == MH_OK && MH_EnableHook(st2) == MH_OK) ++ok2;
    if (sw1 && MH_CreateHook(sw1, (void*)h_AkSwId, (void**)&o_AkSwId) == MH_OK && MH_EnableHook(sw1) == MH_OK) ++ok2;
    if (sw2 && MH_CreateHook(sw2, (void*)h_AkSwNm, (void**)&o_AkSwNm) == MH_OK && MH_EnableHook(sw2) == MH_OK) ++ok2;
    if (rt1 && MH_CreateHook(rt1, (void*)h_AkRtId, (void**)&o_AkRtId) == MH_OK && MH_EnableHook(rt1) == MH_OK) ++ok2;
    if (rt2 && MH_CreateHook(rt2, (void*)h_AkRtNm, (void**)&o_AkRtNm) == MH_OK && MH_EnableHook(rt2) == MH_OK) ++ok2;
    Log("wwise hooks: %d post, %d switch/rtpc, reg=%d listeners=%d", ok, ok2, !!p_AkRegGo, !!p_AkSetLis);
}

// ---- dialogue lines -> radio on the DualSense speaker
static const MethodInfo* g_vsMi;     // DialogueDisplay.TryGetLocalPlayerPortraitVoiceOverCharacterSwitch
static int g_female = -1;
static Il2CppObject* CallObj(const MethodInfo* m, void* obj) { Il2CppObject* exc = nullptr; auto r = il2cpp_runtime_invoke(m, obj, nullptr, &exc); return exc ? nullptr : r; }
static std::wstring StrOf(void* str) { if (!str) return L""; int n = *(int*)((uint8_t*)str + 0x10); return std::wstring((const wchar_t*)((uint8_t*)str + 0x14), std::min(n, 4000)); }
static void DetectGender(void* self) {
    if (g_female >= 0 || !g_vsMi || !self) return;
    Il2CppObject* sw = CallObj(g_vsMi, self); if (!sw) return;
    for (Il2CppClass* k = il2cpp_object_get_class(sw); k; k = il2cpp_class_get_parent(k)) {
        const MethodInfo* gn = FindMethod(k, "get_Name", 0);
        if (!gn) continue;
        std::wstring n = StrOf(CallObj(gn, sw)); for (auto& c : n) c = towlower(c);
        g_female = (n.find(L"fem") != n.npos || n.find(L"woman") != n.npos || (n.size() > 2 && n.compare(n.size() - 2, 2, L"_f") == 0)) ? 1 : 0;
        char a[96] = {}; WideCharToMultiByte(CP_UTF8, 0, n.c_str(), -1, a, 95, 0, 0); Log("player voice switch: %s -> %s", a, g_female ? "female" : "male");
        return;
    }
}
static void RadioLine(void* self, const std::wstring& t, uint32_t xorKey) {
    if (!C.speaker || SPK::g_voice.g_dat.empty()) return;
    static uint32_t last = 0; static double lastT = 0;
    uint32_t full, pre; SPK::Hashes(t.c_str(), (int)t.size(), full, pre);
    if (!full) return;
    if (xorKey) { full ^= xorKey; pre = 0; }
    double now = Now();
    if (full == last && now - lastT < 20) return;
    DetectGender(self);
    int c = SPK::g_voice.Find(full, g_female == 1); if (c < 0 && pre) c = SPK::g_voice.Find(pre, g_female == 1);
    last = full; lastT = now;
    if (c >= 0 && SPK::g_voice.IsRadio(c) && g_inMission) { g_radioClip = c; Log("radio: line %d", c); }
    else if (c >= 0) Log("radio: line %d is not a radio call, left to the game", c);
}
typedef void (*Page_t)(void*, void*, void*, void*, const MethodInfo*);
static Page_t o_PageA, o_PageB;
static void h_PageA(void* s, void* text, void* spr, void* name, const MethodInfo* mi) { o_PageA(s, text, spr, name, mi); RadioLine(s, StrOf(text), 0); }
static void h_PageB(void* s, void* text, void* spr, void* name, const MethodInfo* mi) { o_PageB(s, text, spr, name, mi); RadioLine(s, StrOf(text), 0); }
typedef void (*Toast_t)(void*, void*, float, uint8_t*, const MethodInfo*);
static Toast_t o_Toast;
static void h_Toast(void* s, void* loc, float dur, uint8_t* id, const MethodInfo* mi) { o_Toast(s, loc, dur, id, mi); RadioLine(s, StrOf(loc), 0x7e7e7e7eu); }
typedef void (*Stop_t)(void*, void*, const MethodInfo*);
static Stop_t o_StopDlg;
static void h_StopDlg(void* s, void* gr, const MethodInfo* mi) { o_StopDlg(s, gr, mi); g_radioStop = true; }

static bool Hook(const MethodInfo* m, void* det, void** orig, const char* name) {
    if (!m) { Log("hook %s: method not found", name); return false; }
    void* p = MethodPtr(m);
    if (MH_CreateHook(p, det, orig) != MH_OK || MH_EnableHook(p) != MH_OK) { Log("hook %s: MinHook failed", name); return false; }
    Log("hook %s @ rva 0x%llx", name, (unsigned long long)((uintptr_t)p - g_ga));
    return true;
}

static bool InstallHooks(Il2CppDomain* dom) {
    auto rt = FindImage(dom, "NinjaKiwi.ZombieAssault.Runtime.dll");
    auto is = FindImage(dom, "Unity.InputSystem.dll");
    if (!rt) { Log("game image not found"); return false; }
    Il2CppClass* anim = il2cpp_class_from_name(rt, "NkAnimation", "NkCharacterAnimatorController");
    Il2CppClass* ge = il2cpp_class_from_name(rt, "NativeBuildInterop", "GameEntity");
    Il2CppClass* hs = il2cpp_class_from_name(rt, "NativeBuildInterop", "HealthState");
    Il2CppClass* ss = il2cpp_class_from_name(rt, "NativeBuildInterop", "ShieldState");
    Il2CppClass* cu = il2cpp_class_from_name(rt, "NativeBuildInterop", "ClientUpdateResult");
    Il2CppClass* ws = il2cpp_class_from_name(rt, "NativeBuildInterop", "WeaponState");
    Il2CppClass* he = il2cpp_class_from_name(rt, "NativeBuildInterop", "HitEventData");
    Il2CppClass* di = il2cpp_class_from_name(rt, "NativeBuildInterop", "HitEventDamageInfo");
    Il2CppClass* wd = il2cpp_class_from_name(rt, "Assets.DataDefinitions", "WeaponDefinitionSO");
    Il2CppClass* ab = il2cpp_class_from_name(rt, "NativeBuildInterop", "AbilitySlot");
    Il2CppClass* dv = il2cpp_class_from_name(rt, "NativeBuildInterop", "DecayingValue");
    Il2CppClass* ci = il2cpp_class_from_name(rt, "", "CharacterInputController");
    O.e_id = FOff(ge, "id", O.e_id, true); O.e_terrain = FOff(ge, "on_terrain_with_category", O.e_terrain, true);
    O.e_downed = FOff(ge, "downed_count", O.e_downed, true); O.e_pos = FOff(ge, "pos", O.e_pos, true); O.e_vel = FOff(ge, "velocity", O.e_vel, true);
    O.e_health = FOff(ge, "health", O.e_health, true); O.e_shield = FOff(ge, "shield", O.e_shield, true);
    O.e_sprint = FOff(ge, "sprint_value", O.e_sprint, true);
    O.h_cur = FOff(hs, "current", O.h_cur, true); O.h_max = FOff(hs, "max", O.h_max, true);
    O.s_health = FOff(ss, "health", O.s_health, true); O.w_ctrl = FOff(cu, "client_controlling_entity_id", O.w_ctrl, true);
    O.ws_mag = FOff(ws, "mag_ammo_remaining", O.ws_mag, true); O.ws_state = FOff(ws, "state", O.ws_state, true);
    O.ws_charge = FOff(ws, "charge", O.ws_charge, true); O.ws_heat = FOff(ws, "heat", O.ws_heat, true);
    O.ws_fire = FOff(ws, "fire_count", O.ws_fire, true);
    O.hit_dmg = FOff(he, "damage_info", O.hit_dmg, true);
    O.di_hp = FOff(di, "damage_applied_to_health", O.di_hp, true); O.di_sh = FOff(di, "damage_applied_to_shield", O.di_sh, true);
    O.wd_cat = FOff(wd, "category", O.wd_cat, false); O.wd_mag = FOff(wd, "magazineCapacity", O.wd_mag, false);
    O.wd_reload = FOff(wd, "reloadTime", O.wd_reload, false); O.wd_tbs = FOff(wd, "timeBetweenShots", O.wd_tbs, false);
    O.wd_pellets = FOff(wd, "projectilePelletCount", O.wd_pellets, false); O.wd_burst = FOff(wd, "burstSize", O.wd_burst, false);
    O.wd_heat = FOff(wd, "heatUpRate", O.wd_heat, false); O.wd_charge = FOff(wd, "chargeSettings", O.wd_charge, false);
    O.wd_title = FOff(wd, "title", O.wd_title, false);
    O.ab_last = FOff(ab, "last_trigger_time", O.ab_last, true); O.ab_state = FOff(ab, "state", O.ab_state, true);
    O.ab_cool = FOff(ab, "cooldown_duration", O.ab_cool, true);
    if (dv && FOff(dv, "value", 4, true) != 4) Log("DecayingValue layout changed");
    O.ac_terrain = FOff(anim, "currentTerrain", O.ac_terrain, false);
    O.ed_abilityTime = FOff(il2cpp_class_from_name(rt, "", "EntityDisplay"), "lastAbilityTriggerTime", O.ed_abilityTime, false);
    // enums
    Il2CppClass* wc = il2cpp_class_from_name(rt, "NativeBuildInterop", "WeaponCategory");
    Il2CppClass* wst = il2cpp_class_from_name(rt, "NativeBuildInterop", "WeaponStateType");
    const char* cats[] = {"None", "Pistol", "Rifle", "Shotgun", "SMG", "LMG", "SniperRifle", "RocketLauncher", "Melee"};
    const char* sts[] = {"Ready", "Firing", "Reloading", "Cooldown", "PutAway", "LiftingUp", "FireRecovery", "Overheated"};
    for (int i = 0; i < 256; ++i) g_catMap[i] = CatNone, g_wsMap[i] = WReady;
    for (int i = 0; i < 9; ++i) g_catMap[EnumVal(wc, cats[i], i)] = i;
    for (int i = 0; i < 8; ++i) g_wsMap[EnumVal(wst, sts[i], i)] = i;
    {
        Il2CppClass* ast = il2cpp_class_from_name(rt, "NativeBuildInterop", "AbilitySlotState");
        const char* as_[] = {"FailsTriggerConditions", "Ready", "Active", "InCooldown", "OutOfUses", "Disabled", "Charging"};
        for (int i = 0; i < 256; ++i) g_abMap[i] = AbFails;
        for (int i = 0; i < 7; ++i) g_abMap[EnumVal(ast, as_[i], i)] = i;
        auto core = FindImage(dom, "UnityEngine.CoreModule.dll");
        Il2CppClass* sm = core ? il2cpp_class_from_name(core, "UnityEngine.SceneManagement", "SceneManager") : nullptr;
        Il2CppClass* sc = core ? il2cpp_class_from_name(core, "UnityEngine.SceneManagement", "Scene") : nullptr;
        g_getScene = FindMethod(sm, "GetActiveScene", 0); g_sceneName = FindMethod(sc, "get_name", 0);
        Log("scene api: %s", g_getScene && g_sceneName ? "ok" : "missing");
        Hook(FindMethod(sm, "Internal_ActiveSceneChanged", 2), (void*)h_SceneChg, (void**)&o_SceneChg, "SceneManager.Internal_ActiveSceneChanged");
    }
    // ability accessors
    if (ge) {
        auto a = FindMethod(ge, "activated_abilities", 1), l = FindMethod(ge, "activated_abilities_Length", 1);
        if (a && l) { g_abArr = (AbArr_t)MethodPtr(a); g_abArrMi = a; g_abLen = (AbLen_t)MethodPtr(l); g_abLenMi = l; }
        Il2CppClass* abs = ab; (void)abs;
    }
    if (ab) {  // AbilitySlot stride: last field + its size, rounded to 4/8
        FieldInfo* f = il2cpp_class_get_field_from_name(ab, "auto_trigger_count");
        if (f) O.ab_size = ((il2cpp_field_get_offset(f) - 0x10 + 2) + 3) & ~size_t(3);
    }
    if (ci) {
        auto m1 = FindMethod(ci, "RequestChangeWeapon", 1), m2 = FindMethod(ci, "RequestReloadWeapon", 0);
        if (m1) { g_reqChange = (ReqChange_t)MethodPtr(m1); g_reqChangeMi = m1; }
        auto m3 = FindMethod(ci, "get_selectedActivitedAbilityIndex", 0);
        if (m3) { g_getSel = (GetSel_t)MethodPtr(m3); g_getSelMi = m3; }
        if (m2) { g_reqReload = (ReqReload_t)MethodPtr(m2); g_reqReloadMi = m2; }
    }
    int ok = 0;
    ok += Hook(FindMethod(anim, "UpdateAnimator", 6), (void*)h_UpdAnim, (void**)&o_UpdAnim, "UpdateAnimator");
    ok += Hook(FindMethod(anim, "OnAttack", 6, 4, "WeaponDefinitionSO"), (void*)h_OnAttack, (void**)&o_OnAttack, "OnAttack");
    ok += Hook(FindMethod(anim, "OnReload", 6, 4, "WeaponDefinitionSO"), (void*)h_OnReload, (void**)&o_OnReload, "OnReload");
    ok += Hook(FindMethod(anim, "OnLiftUpWeapon", 5), (void*)h_OnLift, (void**)&o_OnLift, "OnLiftUpWeapon");
    ok += Hook(FindMethod(anim, "OnHit", 5), (void*)h_OnHit, (void**)&o_OnHit, "OnHit");
    Hook(FindMethod(anim, "SwitchToDeathState", 4), (void*)h_Death, (void**)&o_Death, "SwitchToDeathState");
    Hook(FindMethod(anim, "OnRevive", 4), (void*)h_Revive, (void**)&o_Revive, "OnRevive");
    Hook(FindMethod(anim, "OnTargeting", 4), (void*)h_Targeting, (void**)&o_Targeting, "OnTargeting");
    Hook(FindMethod(anim, "OnPreparingToTarget", 4), (void*)h_Prep, (void**)&o_Prep, "OnPreparingToTarget");
    if (ci) Hook(FindMethod(ci, "DoAimForEntity", 6), (void*)h_DoAim, (void**)&o_DoAim, "DoAimForEntity");
    {
        Il2CppClass* za = il2cpp_class_from_name(rt, "", "ZAButton");
        Hook(FindMethod(za, "PlayClickSFX", 0), (void*)h_Click, (void**)&o_Click, "ZAButton.PlayClickSFX");
        Hook(FindMethod(za, "OnSubmitAction", 1), (void*)h_Submit, (void**)&o_Submit, "ZAButton.OnSubmitAction");
        Hook(FindMethod(il2cpp_class_from_name(rt, "", "ZATabs"), "SelectTab", 1), (void*)h_ZaTab, (void**)&o_ZaTab, "ZATabs.SelectTab");
        Hook(FindMethod(il2cpp_class_from_name(rt, "", "MenuSettings"), "ChangeTab", 1), (void*)h_SetTab, (void**)&o_SetTab, "MenuSettings.ChangeTab");
        Hook(FindMethod(il2cpp_class_from_name(rt, "", "SocialWidget"), "SwitchTab", 1), (void*)h_SocTab, (void**)&o_SocTab, "SocialWidget.SwitchTab");
        auto ui = FindImage(dom, "UnityEngine.UI.dll");
        if (ui) {
            Il2CppClass* sel = il2cpp_class_from_name(ui, "UnityEngine.UI", "Selectable");
            Il2CppClass* sl = il2cpp_class_from_name(ui, "UnityEngine.UI", "Slider");
            Il2CppClass* tg = il2cpp_class_from_name(ui, "UnityEngine.UI", "Toggle");
            if (!Hook(FindMethod(sel, "OnSelect", 1), (void*)h_SelOnSelect, (void**)&o_SelOnSelect, "Selectable.OnSelect"))
                Hook(FindMethod(za, "OnSelect", 1), (void*)h_ZaOnSelect, (void**)&o_ZaOnSelect, "ZAButton.OnSelect");
            Hook(FindMethod(sl, "Set", 2), (void*)h_SliderSet, (void**)&o_SliderSet, "Slider.Set");
            Il2CppClass* bt = il2cpp_class_from_name(ui, "UnityEngine.UI", "Button");
            Hook(FindMethod(bt, "Press", 0), (void*)h_BtnPress, (void**)&o_BtnPress, "Button.Press");
            Hook(FindMethod(tg, "Set", 2), (void*)h_ToggleSet, (void**)&o_ToggleSet, "Toggle.Set");
        }
    }
    {
        if (Il2CppClass* gr = il2cpp_class_from_name(rt, "", "GameRunner")) {
            g_runnerInst = il2cpp_class_get_field_from_name(gr, "<Instance>k__BackingField");
            g_profMi = FindMethod(gr, "get_CurrentPlayerProfile", 0);
        }
        if (Il2CppClass* pp = il2cpp_class_from_name(rt, "", "PlayerProfile")) g_charMi = FindMethod(pp, "GetCurrentCharacter", 0);
        if (Il2CppClass* pc = il2cpp_class_from_name(rt, "", "PlayerProfileCharacter")) { g_pcName = FOff(pc, "name", 0x20, false); g_pcClass = FOff(pc, "className", 0x38, false); g_pcLevel = FOff(pc, "level", 0x4c, false); }
        Log("profile api: %s", g_runnerInst && g_profMi && g_charMi ? "ok" : "missing");
        if (C.discord) {
            Il2CppClass* act = FindClassAny(dom, "Discord.Sdk", "Activity");
            Il2CppClass* cli = FindClassAny(dom, "Discord.Sdk", "Client");
            g_actSetDetails = FindMethod(act, "SetDetails", 1); g_actSetState = FindMethod(act, "SetState", 1);
            g_actDetails = FindMethod(act, "Details", 0); g_actState = FindMethod(act, "State", 0);
            const MethodInfo* upd = FindMethod(cli, "UpdateRichPresence", 2);
            if (!g_actSetDetails || !upd) {
                Log("discord api missing (Activity %p, Client %p)", act, cli);
                for (Il2CppClass* k : {act, cli}) { if (!k) continue; void* it = nullptr; const MethodInfo* m; while ((m = il2cpp_class_get_methods(k, &it))) Log("  %s.%s(%d)", il2cpp_class_get_name(k), il2cpp_method_get_name(m), (int)il2cpp_method_get_param_count(m)); }
            } else Hook(upd, (void*)h_UpdRP, (void**)&o_UpdRP, "Discord.Sdk.Client.UpdateRichPresence");
        }
        Il2CppClass* dd = il2cpp_class_from_name(rt, "", "DialogueDisplay");
        g_vsMi = FindMethod(dd, "TryGetLocalPlayerPortraitVoiceOverCharacterSwitch", 0);
        Hook(FindMethod(dd, "UpdateDialoguePageDisplay", 3, 1, "UnityEngine.Sprite"), (void*)h_PageA, (void**)&o_PageA, "DialogueDisplay.UpdateDialoguePageDisplay(Sprite)");
        Hook(FindMethod(dd, "UpdateDialoguePageDisplay", 3, 1, "AssetReferenceSprite"), (void*)h_PageB, (void**)&o_PageB, "DialogueDisplay.UpdateDialoguePageDisplay(AssetRef)");
        Hook(FindMethod(dd, "UpdateDialogueToastDisplay", 3), (void*)h_Toast, (void**)&o_Toast, "DialogueDisplay.UpdateDialogueToastDisplay");
        Hook(FindMethod(dd, "StopDialogue", 1), (void*)h_StopDlg, (void**)&o_StopDlg, "DialogueDisplay.StopDialogue");
    }
    if (is) {
        Il2CppClass* gp = il2cpp_class_from_name(is, "UnityEngine.InputSystem", "Gamepad");
        Il2CppClass* ds = il2cpp_class_from_name(is, "UnityEngine.InputSystem.DualShock", "DualSenseGamepadHID");
        Hook(FindMethod(gp, "SetMotorSpeeds", 2), (void*)h_GpMotor, (void**)&o_GpMotor, "Gamepad.SetMotorSpeeds");
        Hook(FindMethod(ds, "SetMotorSpeeds", 2), (void*)h_DsMotor, (void**)&o_DsMotor, "DualSense.SetMotorSpeeds");
        Hook(FindMethod(ds, "SetMotorSpeedsAndLightBarColor", 3), (void*)h_DsMotorLb, (void**)&o_DsMotorLb, "DualSense.SetMotorSpeedsAndLightBarColor");
        Hook(FindMethod(ds, "SetLightBarColor", 1), (void*)h_DsLb, (void**)&o_DsLb, "DualSense.SetLightBarColor");
    }
    Log("offsets: ctrl=0x%zx hp=0x%zx terrain=0x%zx wd.cat=0x%zx ab.size=0x%zx", O.w_ctrl, O.e_health, O.e_terrain, O.wd_cat, O.ab_size);
    return ok >= 3;
}

// ------------------------------------------------------------------------------------------------
// GameInput
// ------------------------------------------------------------------------------------------------
static IGameInput* g_gi;
static std::mutex g_devMx;
static std::vector<IGameInputDevice*> g_devs;
static void CALLBACK OnDevice(GameInputCallbackToken, void*, GameInputDeviceEvent ev, IGameInputDevice* d) {
    if (!d) return;
    std::lock_guard<std::mutex> lk(g_devMx);
    auto it = std::find(g_devs.begin(), g_devs.end(), d);
    if (ev == GameInputDeviceEventConnected) { if (it == g_devs.end()) { d->AddRef(); g_devs.push_back(d); } }
    else if (ev == GameInputDeviceEventDisconnected && it != g_devs.end()) { (*it)->Release(); g_devs.erase(it); }
}
static bool InitGameInput() {
    using Init_t = HRESULT(WINAPI*)(REFIID, void**);
    std::wstring cand[] = {g_dir + L"\\GameInputRedist.dll", L"GameInputRedist.dll", L"GameInput.dll"};
    for (auto& c : cand) {
        HMODULE m = c.find(L'\\') != std::wstring::npos ? LoadLibraryW(c.c_str()) : LoadLibraryExW(c.c_str(), nullptr, LOAD_LIBRARY_SEARCH_SYSTEM32);
        if (!m) continue;
        auto init = (Init_t)GetProcAddress(m, "GameInputInitialize");
        if (!init) continue;
        HRESULT hr = init(__uuidof(IGameInput), (void**)&g_gi);
        Log("GameInput %ls -> 0x%08lx", c.c_str(), hr);
        if (SUCCEEDED(hr) && g_gi) break;
        g_gi = nullptr;
    }
    if (!g_gi) { Log("GameInput not available: install GameInputRedist or keep GameInputRedist.dll in the pad folder"); return false; }
    g_gi->EnableBackgroundInput(true);
    GameInputCallbackToken tok;
    g_gi->RegisterDeviceCallback(nullptr, GameInputKindController | GameInputKindGamepad | GameInputKindRawDeviceReport,
                                 nullptr, OnDevice, &tok);
    return true;
}
static IGameInputDevice* PickDevice(bool dualsense) {
    std::lock_guard<std::mutex> lk(g_devMx);
    for (auto d : g_devs) {
        bool ds = GDS::IsDualSense(d->GetVendorId(), d->GetProductId());
        if (dualsense == ds) {
            if (!dualsense && !(d->GetSupportedRumbleMotors() & (GameInputRumbleLowFrequency | GameInputRumbleRightTrigger))) continue;
            d->AddRef(); return d;
        }
    }
    return nullptr;
}

// ------------------------------------------------------------------------------------------------
// effect design
// ------------------------------------------------------------------------------------------------
struct Pulse { double t0, dur; float lo, hi, lt, rt; };   // motor / impulse envelope
static std::vector<Pulse> g_pulses;
static void AddPulse(double dur, float lo, float hi, float lt = 0, float rt = 0) { g_pulses.push_back({Now(), dur, lo, hi, lt, rt}); }
static void AddPulseAt(double delay, double dur, float lo, float hi, float lt = 0, float rt = 0) { g_pulses.push_back({Now() + delay, dur, lo, hi, lt, rt}); }

static float Clamp01(float v) { return v < 0 ? 0 : v > 1 ? 1 : v; }
static uint8_t Z(float v01) { int z = (int)lroundf(v01 * 9.0f); return (uint8_t)std::max(0, std::min(9, z)); }
static uint8_t S8(float v01) { int z = (int)lroundf(v01 * 8.0f * C.triggers / 100.0f); return (uint8_t)std::max(0, std::min(8, z)); }

// R2 effect for current weapon + state
static void RightTrigger(const State& s, DS5::TriggerEffect& e, double now, double lastFire) {
    using namespace DS5;
    bool firingNow = (now - lastFire) < std::max(0.12, s.w.tbs * 1.6);
    if (s.dead || s.downed) { EncodeTriggerOff(e); return; }
    if (s.wstate == WOverheated) { uint8_t a[10] = {0, 0, 2, 4, 6, 8, 8, 8, 8, 8}; EncodeMultiFeedback(e, a); return; }    // jammed
    if (s.wstate == WReloading || (s.magAmmo == 0 && s.w.mag > 0 && s.w.heatUp <= 0)) {
        uint8_t a[10] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1}; EncodeMultiFeedback(e, a); return;      // empty, limp trigger
    }
    float rpm = s.w.tbs > 0.001f ? 1.0f / s.w.tbs : 10.0f;
    uint8_t freq = (uint8_t)std::max(4.0f, std::min(40.0f, rpm));
    switch (s.w.cat) {
    case CatPistol:  EncodeWeapon(e, 3, 6, S8(0.75f)); break;
    case CatShotgun: EncodeWeapon(e, 2, 6, S8(1.0f)); break;
    case CatSniper:  if (s.targeting) EncodeBow(e, 1, 7, S8(0.8f), S8(1.0f)); else EncodeWeapon(e, 5, 7, S8(0.9f)); break;
    case CatRocket:  if (s.targeting) EncodeBow(e, 2, 8, S8(1.0f), S8(1.0f)); else EncodeSlopeFeedback(e, 1, 8, S8(0.3f) ? S8(0.3f) : 1, S8(1.0f) ? S8(1.0f) : 1); break;
    case CatMelee:   EncodeFeedback(e, 2, S8(0.4f)); break;
    case CatSMG:     if (firingNow) EncodeVibration(e, 2, S8(0.55f), freq); else EncodeFeedback(e, 2, S8(0.25f)); break;
    case CatLMG:
        if (s.w.heatUp > 0 && s.heat > 0.6f) EncodeMachine(e, 1, 9, 6, 3, (uint8_t)std::max(8.0f, freq * (1.2f - s.heat * 0.5f)), 1);
        else if (firingNow) EncodeVibration(e, 2, S8(0.9f), freq);
        else EncodeFeedback(e, 2, S8(0.55f));
        break;
    case CatRifle:
    default:
        if (s.w.chargeMode && s.charge > 0.02f) EncodeGalloping(e, 1, 8, 2, 4, (uint8_t)(4 + s.charge * 20));
        else if (firingNow) EncodeVibration(e, 2, S8(0.7f), freq);
        else EncodeFeedback(e, 2, S8(0.4f));
        break;
    }
}
static void LeftTrigger(const State& s, DS5::TriggerEffect& e, bool aiming) {
    using namespace DS5;
    if (s.dead || s.downed) { EncodeTriggerOff(e); return; }
    if (s.abState >= 0) {
        switch (s.abState) {
        case AbReady:    EncodeWeapon(e, 2, 5, S8(0.8f)); return;                               // ready: firm click to unleash
        case AbCharging: EncodeSlopeFeedback(e, 1, 8, 1, std::max<uint8_t>(1, S8(1.0f))); return;   // charging: builds up
        case AbActive:   EncodeVibration(e, 1, S8(0.5f), 30); return;                            // active: hums
        case AbCooldown: { uint8_t a[10] = {S8(0.15f), S8(0.15f), S8(0.15f), S8(0.15f), S8(0.15f), S8(0.15f), S8(0.15f), S8(0.15f), S8(0.15f), S8(0.15f)}; EncodeMultiFeedback(e, a); return; }  // recharging: limp but not empty
        case AbOut: case AbDisabled: case AbFails: { uint8_t a[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}; a[0] = 1; EncodeMultiFeedback(e, a); return; }
        }
    }
    if (s.targeting && (s.w.cat == CatSniper || s.w.cat == CatRocket)) { EncodeFeedback(e, 1, S8(0.7f)); return; }
    if (aiming) { EncodeFeedback(e, 3, S8(0.2f)); return; }
    EncodeTriggerOff(e);
}

static void FirePulse(int cat, bool xbox) {
    float k = (xbox ? C.rumble : C.rumble) / 100.0f, it = C.impulse / 100.0f;
    switch (cat) {
    case CatPistol:  AddPulse(0.07, 0.25f * k, 0.55f * k, 0, 0.55f * it); break;
    case CatSMG:     AddPulse(0.04, 0.15f * k, 0.45f * k, 0, 0.35f * it); break;
    case CatRifle:   AddPulse(0.06, 0.30f * k, 0.55f * k, 0, 0.45f * it); break;
    case CatLMG:     AddPulse(0.06, 0.45f * k, 0.60f * k, 0, 0.55f * it); break;
    case CatShotgun: AddPulse(0.16, 0.90f * k, 0.70f * k, 0, 1.00f * it); break;
    case CatSniper:  AddPulse(0.18, 0.85f * k, 0.50f * k, 0, 1.00f * it); break;
    case CatRocket:  AddPulse(0.30, 1.00f * k, 0.40f * k, 0, 0.90f * it); break;
    case CatMelee:   AddPulse(0.08, 0.40f * k, 0.30f * k, 0, 0.30f * it); break;
    default:         AddPulse(0.06, 0.30f * k, 0.50f * k, 0, 0.40f * it); break;
    }
}

// HD haptics voices
static void HdFire(int cat) {
    float g = C.haptics / 100.0f;
    switch (cat) {
    case CatPistol:  HD::Play(95, 0.06f, 0.85f * g, HD::Both, 1); break;
    case CatSMG:     HD::Play(140, 0.035f, 0.6f * g, HD::Right, 1); break;
    case CatRifle:   HD::Play(85, 0.05f, 0.8f * g, HD::Both, 1); break;
    case CatLMG:     HD::Play(60, 0.06f, 0.9f * g, HD::Both, 1); break;
    case CatShotgun: HD::Play(45, 0.14f, 1.0f * g, HD::Both, 2); HD::Noise(0.06f, 0.5f * g, HD::Both); break;
    case CatSniper:  HD::Play(40, 0.18f, 1.0f * g, HD::Both, 2); break;
    case CatRocket:  HD::Play(32, 0.30f, 1.0f * g, HD::Both, 2); HD::Noise(0.12f, 0.4f * g, HD::Both); break;
    case CatMelee:   HD::Play(170, 0.05f, 0.7f * g, HD::Right, 1); break;
    default:         HD::Play(90, 0.05f, 0.8f * g, HD::Both, 1); break;
    }
}
static void HdStep(int surface, int foot, float strength) {
    float g = C.haptics / 100.0f * (0.7f + 0.3f * strength);
    HD::Side side = foot ? HD::Right : HD::Left;
    switch (surface) {
    case SMetal:  HD::Play(220, 0.035f, 0.55f * g, side, 1); HD::Play(330, 0.05f, 0.2f * g, side, 2); break;   // clank
    case SWood:   HD::Play(120, 0.04f, 0.6f * g, side, 1); break;                                             // knock
    case SStone:  HD::Play(160, 0.025f, 0.55f * g, side, 1); HD::Noise(0.015f, 0.2f * g, side); break;       // hard tap
    case SGravel: HD::Noise(0.07f, 0.45f * g, side); HD::Play(90, 0.03f, 0.25f * g, side, 1); break;        // crunch
    case SMud:    HD::Play(55, 0.09f, 0.55f * g, side, 2); break;                                             // squelch
    case SSnow:   HD::Noise(0.09f, 0.3f * g, side); HD::Play(70, 0.06f, 0.2f * g, side, 2); break;          // soft crunch
    case SShrub:  HD::Noise(0.06f, 0.25f * g, side); break;                                                   // rustle
    case SNone:   break;
    default:      HD::Play(100, 0.035f, 0.4f * g, side, 1); break;
    }
}
static void HdAbility(int slot, float cooldown) {
    float g = C.haptics / 100.0f * 1.2f;
    float big = Clamp01(cooldown / 60.0f);          // long-cooldown abilities feel bigger
    HD::Sweep(60 + 40 * slot, 220 + 120 * slot, 0.25f + 0.35f * big, (0.6f + 0.4f * big) * g, HD::Both);
}

// lightbar colour by health
static void HealthColor(float f, uint8_t& r, uint8_t& g, uint8_t& b) {
    f = Clamp01(f);
    if (f > 0.5f) { float t = (f - 0.5f) * 2; r = (uint8_t)(255 * (1 - t)); g = 220; b = (uint8_t)(40 * t); }
    else { float t = f * 2; r = 255; g = (uint8_t)(200 * t); b = 0; }
}

// ------------------------------------------------------------------------------------------------
// output thread
// ------------------------------------------------------------------------------------------------
static DWORD WINAPI OutputThread(LPVOID) {
    CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    if (!InitGameInput()) return 0;
    bool ds = C.mode != 2;
    int rumbleDs = IniInt(L"DualSense", L"Rumble", 100), rumbleX = IniInt(L"Xbox", L"Rumble", 100);
    IGameInputDevice* dev = nullptr; DS5::Transport tr = DS5::Transport::Usb;
    double lastFire = -10, hitFlash = -10, deathTime = -10, lastSend = 0, lastPick = -10;
    uint8_t lastCommon[47] = {}; GameInputRumbleParams lastRp{-1, -1, -1, -1};
    double lastGyroTs = 0; uint32_t lastSensorTs = 0; bool hdReady = false;
    // touch tracking
    bool touchDown = false; int touchStartX = 0, touchLastX = 0; double touchStart = 0; int maxFingers = 0;
    for (;;) {
        Sleep(4);
        double now = Now();
        double anim = floor(now * 30.0) / 30.0; (void)anim;
        if (!dev && now - lastPick > 1.0) {
            lastPick = now;
            if (C.mode == 0) { dev = PickDevice(true); ds = dev != nullptr; if (!dev) dev = PickDevice(false); }
            else dev = PickDevice(ds);
            if (dev) { g_activeDs = ds; C.rumble = ds ? rumbleDs : rumbleX; }
            if (dev) {
                if (ds) { tr = GDS::DetectTransport(dev); GDS::ReleaseDualSenseLightbar(dev); hdReady = tr == DS5::Transport::Usb && C.haptics > 0 && HD::Start(); }
                if (ds) { DS5::OutputReport h; h.Lightbar(0, 120, 255); if (hdReady) h.common[DS5::Common::ValidFlag0] |= DS5::Flag0::CompatibleVibration; GDS::SendDualSenseReport(dev, h, tr); Sleep(30); }
                if (hdReady) { HD::Sweep(80, 250, 0.35f, 0.9f, HD::Both); if (C.speaker) HD::Tone(0.05f, 700, 1100, 0.15f, 0.4f); }   // "hello"
                else if (ds) AddPulse(0.3, 0.6f, 0.6f);
                Log("controller connected: %04X:%04X %s%s", dev->GetVendorId(), dev->GetProductId(),
                    ds ? (tr == DS5::Transport::Bluetooth ? "Bluetooth" : "USB") : "Xbox", hdReady ? ", HD haptics on" : "");
                g_outputActive = true;
            }
        }
        if (!dev) { g_outputActive = false; continue; }
        if (!dev->IsConnected()) {
            Log("controller disconnected"); dev->Release(); dev = nullptr; g_outputActive = false; HD::Stop(); hdReady = false; continue;
        }
        State s; { std::lock_guard<std::mutex> lk(g_stMx); s = g_st; if (now - g_st.lastUpdate > 0.5) { g_st.inGame = false; g_st.targeting = false; } else g_st.targeting = false; s.inGame = now - s.lastUpdate < 0.5; }
        std::vector<Event> ev; { std::lock_guard<std::mutex> lk(g_evMx); ev.swap(g_events); }
        {
            static double akA = 0, akS = 0;
            for (auto& e : ev) { if (e.t == EvAbility) akA = e.time; if (e.t == EvSwap) akS = e.time; }
            if (akA && now - akA > 0.7) { AkDump("ability", akA); akA = 0; }
            if (akS && now - akS > 0.7) { AkDump("swap", akS); akS = 0; }
        }
        {   // real game sounds for the local player's abilities / weapon swap / turret
            static double lastAb = -10, lastSwap = -10, lastTarget = -10; static std::vector<AkFx> pend;
            for (auto& e : ev) { if (e.t == EvAbility) lastAb = e.time; if (e.t == EvSwap) lastSwap = e.time; if (e.t == EvTargetStart) lastTarget = e.time; }
            { std::lock_guard<std::mutex> lk(g_akMx); pend.insert(pend.end(), g_akq.begin(), g_akq.end()); g_akq.clear(); }
            for (auto it = pend.begin(); it != pend.end();) {
                bool ability = it->fx >= KB::FxAdrenaline && it->fx <= KB::FxOrbitalFire && it->fx != KB::FxOrbitalAim;
                bool ok = ability ? fabs(it->t - lastAb) < 0.6 : it->fx == KB::FxEquip ? fabs(it->t - lastSwap) < 0.6 : it->fx == KB::FxOrbitalAim ? it->t - lastTarget < 2.0 : true;
                if (ok || now - it->t > 0.7) {
                    it = pend.erase(it);
                } else ++it;
            }
        }
        g_spkLive = hdReady && C.speaker && !SPK::g_sfx.g_dat.empty();
        g_voiceLive = hdReady && C.speaker && !SPK::g_voice.g_dat.empty();
        {   // game sounds routed to the speaker
            std::vector<uint32_t> q; { std::lock_guard<std::mutex> lk(g_sfxMx); q.swap(g_sfxq); }
            if (hdReady && C.speaker) for (uint32_t key : q) if (auto k = SPK::g_sfx.Lookup(key))
                HD::PlaySample(SPK::g_sfx.Decode(k->m + (int)(GetTickCount() % std::max<uint16_t>(1, k->f)), false), 1.35f * C.speakerVol / 80.0f);
        }
        { int rc = g_radioClip.exchange(-1); if (rc >= 0 && hdReady && C.speaker) { auto pcm = SPK::g_voice.Decode(rc, true); Log("radio: playing %d (%.1f s)", rc, pcm.size() / 48000.0); HD::PlayRadio(std::move(pcm)); }
          else if (rc >= 0) Log("radio: skipped (hd=%d speaker=%d)", (int)hdReady, C.speaker); g_radioStop = false; }
        for (auto& e : ev) {
            switch (e.t) {
            case EvFire: lastFire = now; FirePulse(e.i, !ds); if (hdReady) HdFire(e.i); break;
            case EvHit: if (hdReady && C.speaker && e.a > 0.3f) HD::Noise(0.07f, 0.25f * e.a, HD::Speaker);
                hitFlash = now; AddPulse(0.12 + 0.2 * e.a, 0.8f * e.a * C.rumble / 100.0f, 0.3f * e.a, 0.8f * e.a * C.impulse / 100.0f, 0);
                if (hdReady) { HD::Play(50, 0.1f + 0.1f * e.a, std::min(1.0f, 0.4f + e.a) * C.haptics / 100.0f, HD::Both, 2); HD::Noise(0.05f, 0.3f * e.a, HD::Both); } break;
            case EvReload: if (!ds) { float it = C.impulse / 100.0f; AddPulse(0.04, 0, 0.2f, 0, 0.45f * it); AddPulseAt(std::max(0.2f, e.a * 0.85f), 0.05, 0, 0.25f, 0, 0.6f * it); }
                if (hdReady && C.speaker && SPK::g_sfx.g_dat.empty()) { HD::Click(0, 0.7f); HD::Tone(0.01f, 900, 500, 0.05f, 0.35f); HD::Click(std::max(0.2f, e.a * 0.85f), 0.9f); HD::Tone(std::max(0.2f, e.a * 0.85f) + 0.01f, 600, 1100, 0.06f, 0.4f); }
                if (hdReady) { HD::Play(260, 0.02f, 0.5f * C.haptics / 100.0f, HD::Right, 1); HD::PlayAt(std::max(0.2f, e.a * 0.85f), 300, 0.025f, 0.6f * C.haptics / 100.0f, HD::Right); } break;
            case EvSwap: if (!ds) AddPulse(0.05, 0, 0.25f, 0, 0.25f * C.impulse / 100.0f);
                if (hdReady) { HD::Play(200, 0.03f, 0.45f * C.haptics / 100.0f, HD::Both, 1); if (C.speaker && SPK::g_sfx.g_dat.empty()) { HD::Click(0, 0.6f); HD::Click(0.06f, 0.5f); } } break;
            case EvDeath: if (hdReady && C.speaker) HD::Tone(0, 300, 80, 0.9f, 0.5f);
                deathTime = now; AddPulse(0.6, 1.0f * C.rumble / 100.0f, 0.2f, 0.6f, 0.6f); if (hdReady) HD::Sweep(120, 30, 0.8f, 0.9f * C.haptics / 100.0f, HD::Both); break;
            case EvRevive: if (hdReady && C.speaker) { HD::Tone(0, 440, 660, 0.15f, 0.4f); HD::Tone(0.15f, 660, 880, 0.2f, 0.4f); }
                if (hdReady) HD::Sweep(60, 240, 0.5f, 0.7f * C.haptics / 100.0f, HD::Both); break;
            case EvStep:
                if (hdReady && C.footsteps) HdStep(e.i >> 1, e.i & 1, e.a);
                else if (!ds && C.footsteps) {
                    // Xbox: light footfall on the motor of that foot's side (strong = left, weak = right), by ground
                    float r = C.rumble / 100.0f * (0.6f + 0.4f * e.a); int sf = e.i >> 1; bool left = !(e.i & 1);
                    float lo = 0.16f, hi = 0.10f; double d = 0.045;
                    switch (sf) { case SMetal: lo = 0.10f; hi = 0.26f; d = 0.035; break; case SStone: lo = 0.12f; hi = 0.22f; d = 0.035; break;
                                  case SGravel: lo = 0.20f; hi = 0.18f; d = 0.06; break; case SMud: lo = 0.26f; hi = 0.04f; d = 0.08; break;
                                  case SSnow: lo = 0.18f; hi = 0.06f; d = 0.07; break; case SWood: lo = 0.16f; hi = 0.14f; d = 0.045; break; default: break; }
                    if (left) AddPulse(d, lo * r, hi * 0.4f * r); else AddPulse(d, lo * 0.4f * r, hi * r + 0.05f * r);
                }
                break;
            case EvAbility: if (hdReady && C.speaker && SPK::g_sfx.g_dat.empty()) { HD::Tone(0, 500, 1400, 0.18f, 0.45f); HD::Tone(0.12f, 1400, 1800, 0.12f, 0.3f); }
                AddPulse(0.25, 0.5f * C.rumble / 100.0f, 0.5f * C.rumble / 100.0f, 0.4f, 0.4f); if (hdReady) HdAbility(e.i, e.a); break;
            case EvUi: {
                float g = C.haptics / 100.0f;
                if (hdReady) {
                    if (e.i == UiSelect) HD::Play(190, 0.014f, 0.45f * g, HD::Both, 1);
                    else if (e.i == UiClick || e.i == UiConfirm) { HD::Play(110, 0.05f, 1.0f * g, HD::Both, 1); HD::PlayAt(0.05f, 220, 0.025f, 0.7f * g, HD::Both); if (e.i == UiConfirm && C.speaker && SPK::g_sfx.g_dat.empty()) HD::Click(0, 0.4f); }
                    else if (e.i == UiSlider) HD::Play(280, 0.008f, 0.4f * g, HD::Both, 1);
                    else if (e.i == UiTab) { HD::Sweep(140, 320, 0.05f, 0.8f * g, HD::Both); }
                    else HD::Play(150, 0.025f, 0.6f * g, HD::Both, 1);
                } else {
                    // Xbox motors need ~40 ms to spin up: longer, stronger ticks than on DualSense
                    float r = C.rumble / 100.0f, it = C.impulse / 100.0f;
                    switch (e.i) {
                    case UiSelect:  AddPulse(0.045, 0, 0.45f * r); break;
                    case UiSlider:  AddPulse(0.035, 0, 0.35f * r); break;
                    case UiTab:     AddPulse(0.07, 0.25f * r, 0.6f * r); break;
                    case UiToggle:  AddPulse(0.06, 0.15f * r, 0.5f * r); break;
                    default:        AddPulse(0.10, 0.6f * r, 0.6f * r); AddPulseAt(0.11, 0.05, 0.3f * r, 0.4f * r); break;  // confirm / click
                    }
                    (void)it;
                    if (false) {
                    }
                }
                break; }
            case EvTargetStart: if (hdReady) HD::Play(180, 0.03f, 0.4f * C.haptics / 100.0f, HD::Left, 1); break;
            }
        }
        // low health heartbeat: speaker thump + actuator pulse
        static double nextBeat = 0;
        if (hdReady && s.inGame && g_inMission && !s.dead && s.hpMax > 0 && s.hp / s.hpMax < 0.25f && now > nextBeat) {
            float f = s.hp / s.hpMax; double period = 0.65 + f * 2.0;
            HD::Play(45, 0.09f, 0.8f * C.haptics / 100.0f, HD::Both, 2); HD::PlayAt(0.18f, 40, 0.08f, 0.6f * C.haptics / 100.0f, HD::Both);
            if (C.speaker) { HD::Tone(0, 160, 90, 0.1f, 0.6f); HD::Tone(0.18f, 150, 80, 0.09f, 0.45f); }
            nextBeat = now + period;
        }
        // motors: game rumble (decays if the game stops updating) + our pulses
        float glo = g_gameLo, ghi = g_gameHi;
        if (now - g_gameRumbleTime > 1.5) glo = ghi = 0;
        float lo = glo * C.rumble / 100.0f, hi = ghi * C.rumble / 100.0f, lt = 0, rt = 0;
        g_pulses.erase(std::remove_if(g_pulses.begin(), g_pulses.end(), [&](const Pulse& p) { return now - p.t0 > p.dur; }), g_pulses.end());
        for (auto& p : g_pulses) { if (now < p.t0) continue; float env = 1.0f - (float)((now - p.t0) / p.dur); lo = std::max(lo, p.lo * env); hi = std::max(hi, p.hi * env); lt = std::max(lt, p.lt * env); rt = std::max(rt, p.rt * env); }
        if (!ds) {
            // Xbox: overheating weapon buzzes the right trigger
            float it = C.impulse / 100.0f;
            if (s.inGame && s.wstate == WOverheated) rt = std::max(rt, 0.25f * it);
            // charging weapons: right trigger tension grows with the charge
            if (s.inGame && s.w.chargeMode && s.charge > 0.02f) rt = std::max(rt, (0.1f + 0.5f * Clamp01(s.charge)) * it);
            // low health heartbeat on the strong motor
            static double nextBeatX = 0;
            if (s.inGame && g_inMission && !s.dead && s.hpMax > 0 && s.hp / s.hpMax < 0.25f && now > nextBeatX) {
                float f = s.hp / s.hpMax; AddPulse(0.09, 0.55f * C.rumble / 100.0f, 0); AddPulseAt(0.2, 0.08, 0.4f * C.rumble / 100.0f, 0);
                nextBeatX = now + 0.65 + f * 2.0;
            }
            if (!g_inMission) lt = rt = 0;   // no trigger rumble outside missions
            GameInputRumbleParams rp{Clamp01(lo), Clamp01(hi), Clamp01(lt), Clamp01(rt)};
            if (memcmp(&rp, &lastRp, sizeof rp) != 0 || now - lastSend > 0.5) { dev->SetRumbleState(&rp); lastRp = rp; lastSend = now; }
            continue;
        }
        // DualSense input: gyro + touchpad
        DS5::InputState in;
        if (GDS::ReadDualSenseInput(g_gi, dev, &in) && in.valid && !in.simpleMode) {
            { float rx = (in.rx - 128) / 127.f, ry = (in.ry - 128) / 127.f; g_rightStick = rx * rx + ry * ry > 0.35f * 0.35f; }
            if (lastSensorTs && in.sensorTimestamp != lastSensorTs) {
                double dt = (double)(uint32_t)(in.sensorTimestamp - lastSensorTs) * 0.33e-6;   // ticks of 0.33 us
                if (dt > 0 && dt < 0.05) {
                    bool use = g_inMission && (C.gyro == 2 || (C.gyro == 1 && g_aiming));
                    float yawRate = in.gyro[1] * (2000.0f / 32768.0f) * 0.0174533f * (C.gyroInvert ? -1.f : 1.f);   // rad/s, +-2000 dps range
                    float y = g_gyroYaw;
                    static float rateS = 0; rateS = rateS * 0.7f + yawRate * 0.3f;          // smooth sensor noise
                    float r = fabsf(rateS) < 0.06f ? 0.f : rateS;                            // ~3.5 deg/s deadzone
                    if (use) { y += (float)(r * dt) * C.gyroSens; y = std::max(-0.7f, std::min(0.7f, y)); }
                    else y *= 0.8f;
                    if (!g_inMission) y = 0;
                    g_gyroYaw = y;
                }
            }
            lastSensorTs = in.sensorTimestamp;
            g_tpX = in.touch[0].active ? (int)in.touch[0].x : -1; g_tpY = in.touch[0].active ? (int)in.touch[0].y : -1;
            if (C.touchAim && now - g_tgtTime < 0.3) touchDown = false;   // touchpad is aiming: no swipes / taps
            else if (C.touchpad) {
                int fingers = (in.touch[0].active ? 1 : 0) + (in.touch[1].active ? 1 : 0);
                if (fingers && !touchDown) { touchDown = true; touchStartX = touchLastX = in.touch[0].x; touchStart = now; maxFingers = fingers; }
                else if (fingers) { touchLastX = in.touch[0].active ? in.touch[0].x : touchLastX; maxFingers = std::max(maxFingers, fingers); }
                else if (touchDown) {
                    touchDown = false; int dx = touchLastX - touchStartX; double held = now - touchStart;
                    if (!in.touchpadClick && s.inGame) {
                        if (maxFingers >= 2 && held < 0.35 && abs(dx) < 200) { g_pendingReload = true; if (hdReady) HD::Play(240, 0.02f, 0.4f, HD::Both, 1); }
                        else if (abs(dx) > 450 && held < 0.6) { g_pendingSwap = dx > 0 ? 1 : -1; if (hdReady) HD::Play(dx > 0 ? 260.f : 200.f, 0.025f, 0.4f, dx > 0 ? HD::Right : HD::Left, 1); }
                    }
                }
            }
        }
        // build report
        DS5::OutputReport rep;
        DS5::TriggerEffect re, le;
        if (s.inGame && g_inMission && C.triggers > 0) { RightTrigger(s, re, now, lastFire); LeftTrigger(s, le, g_aiming); }
        else { DS5::EncodeTriggerOff(re); DS5::EncodeTriggerOff(le); }
        rep.TriggerEffectFor(DS5::Trigger::Right, re).TriggerEffectFor(DS5::Trigger::Left, le);
        if (hdReady) {
            HD::SetRumble(Clamp01(lo), Clamp01(hi));           // motors are emulated on the actuators
            rep.common[DS5::Common::ValidFlag0] |= DS5::Flag0::CompatibleVibration;   // bit0 without "haptics select" = audio haptics mode
            rep.common[DS5::Common::MotorLeft] = rep.common[DS5::Common::MotorRight] = 0;
        }
        else rep.Rumble((uint8_t)(Clamp01(lo) * 255), (uint8_t)(Clamp01(hi) * 255), true);
        if (hdReady && C.speaker) rep.SpeakerVolume((uint8_t)(0x3D + (0x64 - 0x3D) * std::min(100, C.speakerVol * 100 / 80) / 100));
        if (hdReady && C.speaker) {   // route audio to the built-in speaker: path 3 = X_X_R (speaker plays channel 2), no extra preamp (it hisses)
            rep.common[DS5::Common::ValidFlag0] |= DS5::Flag0::AudioControl;
            rep.common[DS5::Common::AudioFlags] = (uint8_t)((rep.common[DS5::Common::AudioFlags] & ~0x30) | 0x30);
            rep.common[DS5::Common::ValidFlag1] |= DS5::Flag1::AudioControl2;
            rep.common[DS5::Common::AudioFlags2] = (uint8_t)(rep.common[DS5::Common::AudioFlags2] & ~0x07);
        }
        bool mission = g_inMission;
        if (s.inGame && !mission) {                    // hub, quarters, lobby: calm blue, no indicators
            if (C.lightbar) rep.Lightbar(0, 70, 255);
            rep.MuteLight(DS5::MuteLed::Off);
            if (C.playerLeds) rep.PlayerLeds(0, true);
        }
        else if (s.inGame && C.lightbar) {
            float f = s.hpMax > 0 ? s.hp / s.hpMax : 1; uint8_t r, g, b; HealthColor(f, r, g, b);
            if (s.downed || s.dead) { float bl = (float)(0.5 + 0.5 * sin(anim * 10)); r = (uint8_t)(255 * bl); g = 0; b = 0; }
            else if (f < 0.25f) { float bl = (float)(0.55 + 0.45 * sin(anim * 7)); r = (uint8_t)(r * bl); g = (uint8_t)(g * bl); }
            if (s.shMax > 0 && s.sh > 0) { b = std::max<uint8_t>(b, (uint8_t)(160 * Clamp01(s.sh / s.shMax))); }
            if (s.wstate == WReloading) { r = (uint8_t)std::min(255, r / 2 + 128); g = (uint8_t)(g * 0.6f + 40); b = 0; }
            if (now - hitFlash < 0.12) { r = g = b = 255; }
            rep.Lightbar(r, g, b);
            rep.MuteLight(f < 0.25f && !s.dead ? DS5::MuteLed::Pulse : DS5::MuteLed::Off);
        }
        if (s.inGame && mission && C.playerLeds) {
            uint8_t mask = 0;
            const uint8_t m[6] = {0x00, 0x04, 0x0A, 0x15, 0x1B, 0x1F};
            if (C.playerLeds == 2 && s.w.mag > 0) {                       // ammo in magazine
                int n = (int)ceilf(5.0f * s.magAmmo / std::max(1, s.w.mag));
                mask = m[std::max(0, std::min(5, n))];
            } else {                                                       // health: 5 segments, 20% each
                float f = s.hpMax > 0 ? Clamp01(s.hp / s.hpMax) : 0;
                int n = s.dead ? 0 : (int)ceilf(5.0f * f - 0.001f);
                mask = m[std::max(0, std::min(5, n))];
                if (n <= 1 && !s.dead && fmod(now, 0.8) < 0.4) mask = 0;  // last segment blinks
            }
            rep.PlayerLeds(mask, true);
        }
        static double lastDiag = 0;
        if (now - lastDiag > 10) {
            lastDiag = now;
            Log("diag: mission=%d hitches=%d inGame=%d fire=%d hit=%d step=%d ability=%d reload=%d speed=%.2f surface=%d hp=%.0f/%.0f rumble=%.2f/%.2f game=%.2f/%.2f hd=%s",
                (int)g_inMission.load(), g_diag.hitch.exchange(0), (int)s.inGame, g_diag.fire.load(), g_diag.hit.load(), g_diag.step.load(), g_diag.ability.load(), g_diag.reload.load(), g_diag.speed.load(), s.surface,
                s.hp, s.hpMax, lo, hi, glo, ghi, HD::Status());
        }
        bool changed = memcmp(rep.common, lastCommon, sizeof lastCommon) != 0;
        if ((changed && now - lastSend > 0.012) || now - lastSend > 0.25) {
            if (SUCCEEDED(GDS::SendDualSenseReport(dev, rep, tr))) { memcpy(lastCommon, rep.common, sizeof lastCommon); lastSend = now; }
        }
    }
}

// ------------------------------------------------------------------------------------------------
// bootstrap
// ------------------------------------------------------------------------------------------------

// [Debug] DumpUrp=1: writes the render pipeline classes the DLAA code needs to dump_urp.txt
static void DumpUrp(Il2CppDomain* dom) {
    FILE* f = _wfopen((g_dir + L"\\dump_urp.txt").c_str(), L"w"); if (!f) return;
    static const char* want[] = {"TemporalAA", "TaaPassData", "PostProcessPass", "UpscalerPostProcessPass", "RTHandle", "TextureHandle", "RenderTexture", "Texture",
        "CommandBuffer", "RasterCommandBuffer", "BaseCommandBuffer", "UnsafeCommandBuffer", "UniversalAdditionalCameraData", "UniversalCameraData", "RasterGraphContext", "UnsafeGraphContext",
        "UniversalRenderPipelineAsset", "Camera", "TaaHistory", "UniversalRenderPipeline", "RenderGraph", "ScriptableRenderer", "UniversalRenderer", "AntialiasingMode", "TemporalAAQuality",
        "Settings", "MotionVectorRenderPass", "CameraData", "UniversalResourceData", "ContextContainer", "RenderTextureDescriptor", "GraphicsFormat", "SystemInfo", "Graphics", "Display", "Screen",
        "QualitySettings", "UniversalRenderPipelineGlobalSettings", "PostProcessUtils", "RenderGraphResourceRegistry", "InternalRenderGraphContext", "GL", "GraphicsSettings", "PostProcessData", "StpUtils"};
    size_t na = 0; auto as = il2cpp_domain_get_assemblies(dom, &na); char tn[512];
    auto tname = [&](const Il2CppType* t) { char* s = t ? il2cpp_type_get_name(t) : nullptr; snprintf(tn, sizeof tn, "%s", s ? s : "?"); if (s) il2cpp_free(s); return tn; };
    for (size_t a = 0; a < na; ++a) {
        const Il2CppImage* img = il2cpp_assembly_get_image(as[a]); const char* in = il2cpp_image_get_name(img);
        if (!strstr(in, "RenderPipeline") && !strstr(in, "CoreModule")) continue;
        fprintf(f, "# IMAGE %s\n", in);
        size_t nc = il2cpp_image_get_class_count(img);
        for (size_t c = 0; c < nc; ++c) {
            Il2CppClass* k = il2cpp_image_get_class(img, c); const char* cn = il2cpp_class_get_name(k);
            bool ok = false; for (auto w : want) if (!strcmp(cn, w)) ok = true;
            if (!ok) continue;
            Il2CppClass* par = il2cpp_class_get_parent(k); Il2CppClass* dc = il2cpp_class_get_declaring_type ? il2cpp_class_get_declaring_type(k) : nullptr;
            fprintf(f, "CLASS %s.%s%s%s : %s\n", il2cpp_class_get_namespace(k), dc ? il2cpp_class_get_name(dc) : "", dc ? "/" : "", cn, par ? il2cpp_class_get_name(par) : "-");
            void* it = nullptr; FieldInfo* fi;
            while ((fi = il2cpp_class_get_fields(k, &it))) fprintf(f, "  F %s %s @0x%zx%s\n", tname(il2cpp_field_get_type(fi)), il2cpp_field_get_name(fi), il2cpp_field_get_offset(fi), (il2cpp_field_get_flags(fi) & 0x10) ? " static" : "");
            it = nullptr; const MethodInfo* m;
            while ((m = il2cpp_class_get_methods(k, &it))) {
                uint32_t ifl = 0; uint32_t fl = il2cpp_method_get_flags(m, &ifl);
                fprintf(f, "  M %s%s %s(", (fl & 0x10) ? "static " : "", tname(il2cpp_method_get_return_type(m)), il2cpp_method_get_name(m));
                uint32_t pc = il2cpp_method_get_param_count(m);
                for (uint32_t p = 0; p < pc; ++p) fprintf(f, "%s%s %s", p ? ", " : "", tname(il2cpp_method_get_param(m, p)), il2cpp_method_get_param_name(m, p));
                void* mp = MethodPtr(m); fprintf(f, ") rva=0x%llx\n", mp ? (unsigned long long)((uintptr_t)mp - g_ga) : 0ull);
            }
            // nested classes (render pass data, lambdas)
            void* nit = nullptr; Il2CppClass* nk;
            while (il2cpp_class_get_nested_types && (nk = il2cpp_class_get_nested_types(k, &nit))) {
                fprintf(f, " NESTED %s\n", il2cpp_class_get_name(nk));
                void* it2 = nullptr; FieldInfo* f2; while ((f2 = il2cpp_class_get_fields(nk, &it2))) fprintf(f, "    F %s %s @0x%zx\n", tname(il2cpp_field_get_type(f2)), il2cpp_field_get_name(f2), il2cpp_field_get_offset(f2));
                it2 = nullptr; const MethodInfo* m2;
                while ((m2 = il2cpp_class_get_methods(nk, &it2))) {
                    fprintf(f, "    M %s %s(", tname(il2cpp_method_get_return_type(m2)), il2cpp_method_get_name(m2));
                    uint32_t pc = il2cpp_method_get_param_count(m2);
                    for (uint32_t p = 0; p < pc; ++p) fprintf(f, "%s%s", p ? ", " : "", tname(il2cpp_method_get_param(m2, p)));
                    void* mp = MethodPtr(m2); fprintf(f, ") rva=0x%llx\n", mp ? (unsigned long long)((uintptr_t)mp - g_ga) : 0ull);
                }
            }
        }
        fflush(f);
    }
    // icalls the DLAA code may need
    for (const char* ic : {"UnityEngine.Texture::GetNativeTexturePtr", "UnityEngine.Texture::GetNativeTexturePtr_Injected", "UnityEngine.Rendering.CommandBuffer::IssuePluginEventAndDataInternal",
                           "UnityEngine.Rendering.CommandBuffer::IssuePluginEventAndDataInternal_Injected", "UnityEngine.Rendering.CommandBuffer::IssuePluginEventInternal", "UnityEngine.Rendering.CommandBuffer::IssuePluginEventInternal_Injected"})
        fprintf(f, "ICALL %s = %p\n", ic, il2cpp_resolve_icall ? il2cpp_resolve_icall(ic) : nullptr);
    fprintf(f, "# DONE\n"); fclose(f);
    Log("dump_urp.txt written");
}

static DWORD WINAPI Boot(LPVOID) {
    KB::Start(C.kbMode, C.kbBright, Log, g_dir.c_str());
    HMODULE ga = nullptr;
    for (int i = 0; i < 900 && !(ga = GetModuleHandleW(L"GameAssembly.dll")); ++i) Sleep(100);
    if (!ga || !LoadIl2cpp(ga)) { Log("GameAssembly.dll not found"); return 0; }
    g_ga = (uintptr_t)ga;
    // touching il2cpp before the player has initialised it crashes the game: wait for the game window first
    for (int i = 0; i < 1200; ++i) {
        struct W { static BOOL CALLBACK F(HWND h, LPARAM p) { DWORD pid = 0; GetWindowThreadProcessId(h, &pid); if (pid == GetCurrentProcessId() && IsWindowVisible(h)) { *(bool*)p = true; g_gameWnd = h; return FALSE; } return TRUE; } };
        bool win = false; EnumWindows(W::F, (LPARAM)&win);
        if (win) break;
        Sleep(100);
    }
    Sleep(3000);
    Il2CppDomain* dom = nullptr;
    for (int i = 0; i < 900 && !(dom = il2cpp_domain_get()); ++i) Sleep(100);
    Sleep(6000);     // let the runtime finish booting before this thread touches it
    il2cpp_thread_attach(dom);
    if (MH_Initialize() != MH_OK) { Log("MinHook init failed"); return 0; }
    if (IniInt(L"Debug", L"DumpUrp", 0)) DumpUrp(dom);
    bool ok = InstallHooks(dom);
    HookWwise();
    if (C.dlaa) DLAA::Install(dom, g_ga, Hook, Log, g_dir, C.dl);
    Log(ok ? "hooks installed" : "some hooks are missing: the game was probably updated; the mod keeps what still matches");
    if (C.mode != 3) CloseHandle(CreateThread(nullptr, 0, OutputThread, nullptr, 0, nullptr));   // 3 = keyboard lighting only
    return 0;
}

BOOL WINAPI DllMain(HINSTANCE h, DWORD r, LPVOID) {
    if (r == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(h);
        wchar_t p[MAX_PATH]; GetModuleFileNameW(nullptr, p, MAX_PATH);
        std::wstring exe(p); for (auto& c : exe) c = towlower(c);
        if (exe.find(L"zombieassault.exe") == std::wstring::npos) return TRUE;
        g_dir = exe.substr(0, exe.find_last_of(L"\\/"));
        GetModuleFileNameW(nullptr, p, MAX_PATH); g_dir = std::wstring(p); g_dir = g_dir.substr(0, g_dir.find_last_of(L"\\/")) + L"\\ZA_Rusifikator\\pad";
        CreateDirectoryW(g_dir.substr(0, g_dir.size() - 4).c_str(), nullptr); CreateDirectoryW(g_dir.c_str(), nullptr);
        g_log = _wfopen((g_dir + L"\\ZAPad.log").c_str(), L"w");
        LoadConfig();
        if (C.speaker && SPK::g_voice.Load(g_dir + L"\\ZASpk.dat")) HD::g_radioGain = 1.8f * C.speakerVol / 80.0f;
        if (C.speaker) SPK::g_sfx.Load(g_dir + L"\\ZASfx.dat");
        Log("ZAPad 1.0 by MeT1oR & Tianku, mode=%s, radio lines %u", C.mode == 3 ? "no gamepad" : C.mode == 2 ? "Xbox" : C.mode == 1 ? "DualSense" : "auto", SPK::g_voice.g_nClips);
        CloseHandle(CreateThread(nullptr, 0, Boot, nullptr, 0, nullptr));
    }
    return TRUE;
}
