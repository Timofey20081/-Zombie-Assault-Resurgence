// ZAPad DLAA: replaces URP's temporal anti-aliasing resolve with NVIDIA DLSS in DLAA mode (D3D12).
#pragma once
#include "il2cpp_api.h"
#include <string>

namespace DLAA {
struct Cfg {
    int preset = 12;           // NVSDK_NGX_DLSS_Hint_Render_Preset: 11 = K (DLSS 4), 12 = L, 13 = M (DLSS 4.5)
    float mipBias = 0.f;
    float jitterX = -1.f, jitterY = -1.f;   // jitter sign (URP jitter -> DLSS pixel space)
    float mvX = -1.f, mvY = -1.f;           // motion vector scale sign (URP UV delta -> DLSS pixels)
    int autoExposure = 1;
    int split = 0;             // debug: DLAA on the left half of the screen only
};
using HookFn = bool (*)(const MethodInfo*, void*, void**, const char*);
using LogFn = void (*)(const char*, ...);
// main thread, after il2cpp is attached; dir = folder with nvngx_dlss.dll
bool Install(Il2CppDomain* dom, uintptr_t gameAssembly, HookFn hook, LogFn log, const std::wstring& dir, const Cfg& cfg);
void ResetHistory();       // scene change / camera cut
}
