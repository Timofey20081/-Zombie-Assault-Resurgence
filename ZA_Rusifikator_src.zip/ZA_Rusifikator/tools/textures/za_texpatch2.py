"""Replace RGBA32 textures inside a UnityFS (LZ4HC) bundle *in place* in the .resS stream,
re-compressing only the touched blocks, and emit a small binary patch (orig -> new).

usage: za_texpatch.py <orig.bundle> <png_dir> <out.bundle> <out.patch>

Patch format (little endian):
  b"ZAP1", int64 new_size, int32 n_ops, then ops:
    u8 0, int64 orig_offset, int32 length          -> copy from original
    u8 1, int32 length, <length bytes>              -> literal
"""
import sys, os, struct, hashlib
import lz4.block
import UnityPy
from PIL import Image

orig_p, png_dir, out_p, patch_p = sys.argv[1:5]
raw = open(orig_p, "rb").read()

# ---- parse UnityFS header -------------------------------------------------
i = 0
def cstr():
    global i
    j = raw.index(b"\0", i); s = raw[i:j]; i = j + 1; return s
sig = cstr(); ver = struct.unpack(">I", raw[i:i + 4])[0]; i += 4; cstr(); cstr()
size_pos = i
size, csz, usz, flags = struct.unpack(">qIII", raw[i:i + 20]); i += 20
hdr_end = i
assert sig == b"UnityFS" and not flags & 0x80 and (flags & 0x3F) in (2, 3)
bi_off = (i + 15) // 16 * 16 if ver >= 7 else i
bi = lz4.block.decompress(raw[bi_off:bi_off + csz], uncompressed_size=usz)
j = 16; n = struct.unpack(">i", bi[j:j + 4])[0]; j += 4
blocks = []
for _ in range(n):
    u, c, fl = struct.unpack(">IIH", bi[j:j + 10]); j += 10; blocks.append([u, c, fl])
tail = bi[j:]  # node table, kept verbatim
nn = struct.unpack(">i", tail[:4])[0]; k = 4; nodes = {}
for _ in range(nn):
    off, sz, fl = struct.unpack(">qqI", tail[k:k + 20]); k += 20
    e = tail.index(b"\0", k); nodes[tail[k:e].decode()] = (off, sz); k = e + 1
data_off = bi_off + csz
if flags & 0x200:
    data_off = (data_off + 15) // 16 * 16

# block offsets (compressed / uncompressed)
coffs, uoffs = [], []
co, uo = data_off, 0
for u, c, fl in blocks:
    coffs.append(co); uoffs.append(uo); co += c; uo += u
assert co == len(raw), (co, len(raw))

def block_data(k):
    u, c, fl = blocks[k]
    d = raw[coffs[k]:coffs[k] + c]
    return lz4.block.decompress(d, uncompressed_size=u) if fl & 0x3F else d

# ---- locate textures --------------------------------------------------------
import etcpak, numpy as np
env = UnityPy.load(orig_p)
writes = []  # (stream_offset, bytes)
res_name = [nm for nm in nodes if nm.endswith(".resS")][0]
res_base = nodes[res_name][0]

import texture2ddecoder as t2d
def read_stream(sd):
    start = res_base + sd.offset; end = start + sd.size; out = bytearray()
    for k, (u, c, fl) in enumerate(blocks):
        b0, b1 = uoffs[k], uoffs[k] + u
        if b1 <= start or b0 >= end: continue
        d = block_data(k); out += d[max(0, start - b0):min(u, end - b0)]
    return bytes(out)
def decode_level(buf, fmt, w, h):
    """raw (bottom-up) block data -> RGBA float array in PIL orientation (top-down)"""
    if fmt == 12: a = np.frombuffer(t2d.decode_bc3(buf, w, h), np.uint8).reshape(h, w, 4)
    elif fmt == 10: a = np.frombuffer(t2d.decode_bc1(buf, w, h), np.uint8).reshape(h, w, 4)
    elif fmt == 4: return np.frombuffer(buf, np.uint8).reshape(h, w, 4)[::-1].astype(np.float32)
    else: raise SystemExit(f"format {fmt}")
    return a[::-1][..., [2, 1, 0, 3]].astype(np.float32)   # BGRA -> RGBA, flip to top-down

def level_size(fmt, w, h):
    if fmt == 4: return w * h * 4
    return ((w + 3) // 4) * ((h + 3) // 4) * (16 if fmt == 12 else 8)

def encode(im, fmt, mips, w, h, orig=None):
    """Mip 0 is the edited image. Lower mips keep the game's own mips and only add the
    downscaled difference, so nothing outside the edited labels changes (and colour is never
    premultiplied by alpha, which blackened textures with alpha 0)."""
    out = b""; off = 0
    new0 = np.asarray(im.convert("RGBA"), np.float32)
    base0 = None
    for m in range(mips):
        mw, mh = max(1, w >> m), max(1, h >> m)
        pw, ph = (mw + 3) // 4 * 4, (mh + 3) // 4 * 4
        sz = level_size(fmt, mw, mh) if fmt == 4 else level_size(fmt, pw, ph)
        if m == 0:
            lvl = new0
            if orig is not None and mw >= 4 and mh >= 4: base0 = decode_level(orig[0:sz], fmt, pw, ph)[:mh, :mw]
        elif orig is not None and base0 is not None and mw >= 4 and mh >= 4:
            om = decode_level(orig[off:off + sz], fmt, pw, ph)[:mh, :mw]
            d = new0 - base0
            ds = np.stack([np.asarray(Image.fromarray(d[..., c]).resize((mw, mh), Image.BOX), np.float32) for c in range(4)], -1)
            lvl = np.clip(om + ds, 0, 255)
        else:
            rgb = im.convert("RGB").resize((mw, mh), Image.BOX); a = im.getchannel("A").resize((mw, mh), Image.BOX)
            lvl = np.asarray(Image.merge("RGBA", (*rgb.split(), a)), np.float32)
        L = Image.fromarray(np.round(lvl).astype(np.uint8), "RGBA")
        if (pw, ph) != (mw, mh):
            c = Image.new("RGBA", (pw, ph)); c.paste(L, (0, 0)); L = c
        raw = L.transpose(Image.FLIP_TOP_BOTTOM).tobytes()
        if fmt == 10: out += etcpak.compress_bc1(raw, pw, ph)
        elif fmt == 12: out += etcpak.compress_bc3(raw, pw, ph)
        elif fmt == 4: out += raw
        else: raise SystemExit(f"format {fmt}")
        off += sz
    return out

for o in env.objects:
    if o.type.name != "Texture2D":
        continue
    nm = o.peek_name()
    p = os.path.join(png_dir, nm + ".png")
    if not os.path.exists(p):
        continue
    t = o.read()
    fmt = int(t.m_TextureFormat)
    sd = t.m_StreamData
    assert sd.path.endswith(res_name), sd.path
    im = Image.open(p).convert("RGBA")
    assert im.size == (t.m_Width, t.m_Height), nm
    orig_bytes = read_stream(sd)
    newb = encode(im, fmt, t.m_MipCount, t.m_Width, t.m_Height, orig_bytes)
    assert len(newb) == sd.size, (nm, len(newb), sd.size, fmt, t.m_MipCount)
    writes.append((res_base + sd.offset, newb, None, nm))
    print("  ", nm, fmt, t.m_MipCount, len(newb))
print("textures", len(writes))

# ---- apply writes per block --------------------------------------------------
import bisect
changed = {}
for so, newb, oldb, nm in writes:
    end = so + len(newb)
    k = bisect.bisect_right(uoffs, so) - 1
    while k < len(blocks) and uoffs[k] < end:
        if k not in changed:
            changed[k] = bytearray(block_data(k))
        b0 = uoffs[k]
        lo, hi = max(so, b0), min(end, b0 + blocks[k][0])
        changed[k][lo - b0:hi - b0] = newb[lo - so:hi - so]
        k += 1
print("blocks changed", len(changed), "of", len(blocks))

newc = {}
for k, d in changed.items():
    c = lz4.block.compress(bytes(d), mode="high_compression", compression=9, store_size=False)
    if len(c) >= len(d):
        newc[k] = (bytes(d), blocks[k][2] & ~0x3F)
    else:
        newc[k] = (c, (blocks[k][2] & ~0x3F) | 3)
    blocks[k][1] = len(newc[k][0]); blocks[k][2] = newc[k][1]

# ---- rebuild block info + header ---------------------------------------------
nbi = bi[:16] + struct.pack(">i", len(blocks)) + b"".join(struct.pack(">IIH", *b) for b in blocks) + tail
nbic = lz4.block.compress(nbi, mode="high_compression", compression=9, store_size=False)
nflags = (flags & ~0x3F) | 3
head = bytearray(raw[:size_pos]) + struct.pack(">qIII", 0, len(nbic), len(nbi), nflags)
head += b"\0" * ((-len(head)) % 16 if ver >= 7 else 0)
head += nbic
if flags & 0x200:
    head += b"\0" * ((-len(head)) % 16)
total = len(head) + sum(b[1] for b in blocks)
head[size_pos:size_pos + 8] = struct.pack(">q", total)

ops = [(1, bytes(head))]
for k in range(len(blocks)):
    if k in newc:
        ops.append((1, newc[k][0]))
    else:
        off, ln = coffs[k], blocks[k][1]
        if ops and ops[-1][0] == 0 and ops[-1][1] + ops[-1][2] == off:
            ops[-1] = (0, ops[-1][1], ops[-1][2] + ln)
        else:
            ops.append((0, off, ln))
# split copies > 2GB not needed; literal merge
with open(out_p, "wb") as fo:
    for op in ops:
        if op[0] == 0:
            fo.write(raw[op[1]:op[1] + op[2]])
        else:
            fo.write(op[1])
assert os.path.getsize(out_p) == total
with open(patch_p, "wb") as fp:
    fp.write(b"ZAP1" + struct.pack("<qi", total, len(ops)))
    for op in ops:
        if op[0] == 0:
            fp.write(struct.pack("<Bqi", 0, op[1], op[2]))
        else:
            fp.write(struct.pack("<Bi", 1, len(op[1])) + op[1])
sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest().upper()
print("new size", total, "patch", os.path.getsize(patch_p))
print("ORIG_SHA", sha(orig_p))
print("NEW_SHA", sha(out_p))
