// ZAPad keyboard lighting.
//   Aura:    ASUS Aura SDK (COM server of Armoury Crate / LightingService), keys addressed by scan code.
//   Windows: Dynamic Lighting (Windows.Devices.Lights.LampArray), keys addressed by virtual key.
// Both share one renderer: a colour per lamp, recomputed 30 times a second.
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include "kbd.h"

#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Foundation.Collections.h>
#include <winrt/Windows.Foundation.Numerics.h>
#include <winrt/Windows.Devices.Enumeration.h>
#include <winrt/Windows.Devices.Lights.h>
#include <winrt/Windows.System.h>
#include <winrt/Windows.UI.h>

#include "kbshm.h"
#include <cwchar>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

namespace KB {
static LogFn L = [](const char*, ...) {};
static std::wstring g_dir;
static std::mutex g_mx;
static State g_s;
struct EvRec { Ev e; float a; int i; };
static std::vector<EvRec> g_ev;
static std::atomic<bool> g_on{false};
static double g_lastUpd = 0;
static double Now();

void Update(const State& s) { if (!g_on) return; std::lock_guard<std::mutex> lk(g_mx); g_s = s; g_lastUpd = Now(); }
void Event(Ev e, float a, int i) { if (!g_on) return; std::lock_guard<std::mutex> lk(g_mx); if (g_ev.size() < 128) g_ev.push_back({e, a, i}); }

static double Now() {
    static LARGE_INTEGER f = [] { LARGE_INTEGER x; QueryPerformanceFrequency(&x); return x; }();
    LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart / f.QuadPart;
}

struct C3 { float r = 0, g = 0, b = 0; };
static C3 rgb(float r, float g, float b) { return {r / 255.f, g / 255.f, b / 255.f}; }
static C3 operator*(C3 a, float k) { return {a.r * k, a.g * k, a.b * k}; }
static C3 operator+(C3 a, C3 b) { return {a.r + b.r, a.g + b.g, a.b + b.b}; }
static C3 mix(C3 a, C3 b, float t) { t = std::clamp(t, 0.f, 1.f); return a * (1 - t) + b * t; }
static C3 maxc(C3 a, C3 b) { return {std::max(a.r, b.r), std::max(a.g, b.g), std::max(a.b, b.b)}; }

// ------------------------------------------------------------------------------------------------
// devices
// ------------------------------------------------------------------------------------------------
struct Device {
    std::vector<float> x, y;           // lamp positions, 0..1
    virtual ~Device() {}
    virtual std::vector<int> Find(uint16_t scan, uint16_t vk) = 0;
    virtual bool Send(const std::vector<C3>& c) = 0;
    virtual void Close() {}
    virtual const char* Name() = 0;
};

struct AuraDev : Device {      // talks to ZAKbd.exe (Aura SDK must not be loaded into the game)
    HANDLE map = nullptr, proc = nullptr; KBShm::Block* b = nullptr;
    bool Open() {
        unsigned pid = GetCurrentProcessId(); wchar_t nm[64]; KBShm::Name(nm, 64, pid);
        map = CreateFileMappingW(INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE, 0, sizeof(KBShm::Block), nm);
        if (!map) return false;
        b = (KBShm::Block*)MapViewOfFile(map, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(KBShm::Block));
        if (!b) return false;
        t0 = GetTickCount64();
        return Spawn();
    }
    bool Spawn() {
        memset(b, 0, sizeof *b);
        unsigned pid = GetCurrentProcessId();
        std::wstring exe = g_dir + L"\\ZAAura.exe", cl = L"\"" + exe + L"\" " + std::to_wstring(pid);
        STARTUPINFOW si{sizeof si}; PROCESS_INFORMATION pi{};
        if (!CreateProcessW(exe.c_str(), cl.data(), nullptr, nullptr, FALSE, CREATE_NO_WINDOW | BELOW_NORMAL_PRIORITY_CLASS, nullptr, nullptr, &si, &pi)) { L("keyboard: cannot start ZAAura.exe (%u)", GetLastError()); return false; }
        CloseHandle(pi.hThread); proc = pi.hProcess; ++spawns;
        return true;
    }
    int spawns = 0; ULONGLONG respawnAt = 0;
    ULONGLONG t0 = 0;
    int Poll() {   // 1 ready, 0 still enumerating (the ASUS SDK needs up to a minute), -1 failed
        if (b->ready == 1) {
            if (x.empty()) { for (int i = 0; i < b->count; ++i) { x.push_back(b->x[i]); y.push_back(b->y[i]); } L("keyboard: Aura '%s', %d keys (%.0f s)", b->name, b->count, (GetTickCount64() - t0) / 1000.0); }
            return 1;
        }
        ULONGLONG nowt = GetTickCount64();
        if (respawnAt) { if (nowt < respawnAt) return 0; respawnAt = 0; if (!Spawn()) { Close(); return -1; } return 0; }
        if (b->ready != -1 && proc && WaitForSingleObject(proc, 0) == WAIT_OBJECT_0 && spawns < 5 && nowt - t0 < 150000) {   // helper quit early (the SDK may still be busy with the last session): try again
            DWORD code = 0; GetExitCodeProcess(proc, &code); CloseHandle(proc); proc = nullptr;
            L("keyboard: ZAAura.exe exited early (code %u), retry %d", code, spawns); respawnAt = nowt + 4000; return 0;
        }
        if (b->ready == -1 || !proc || WaitForSingleObject(proc, 0) == WAIT_OBJECT_0 || nowt - t0 > 150000) { L("keyboard: ASUS Aura keyboard not found (Armoury Crate installed?)"); Close(); return -1; }
        return 0;
    }
    std::vector<int> Find(uint16_t scan, uint16_t) override {
        std::vector<int> r; for (int i = 0; i < b->count; ++i) if (b->code[i] == scan) r.push_back(i); return r;
    }
    bool Send(const std::vector<C3>& c) override {
        if (WaitForSingleObject(proc, 0) == WAIT_OBJECT_0) { L("keyboard: ZAAura.exe stopped"); return false; }
        for (int i = 0; i < b->count; ++i)
            b->color[i] = (uint32_t)(std::clamp(c[i].b, 0.f, 1.f) * 255) << 16 | (uint32_t)(std::clamp(c[i].g, 0.f, 1.f) * 255) << 8 | (uint32_t)(std::clamp(c[i].r, 0.f, 1.f) * 255);
        InterlockedIncrement(&b->seq);
        return true;
    }
    void Close() override {
        if (b) InterlockedExchange(&b->quit, 1);
        if (proc) { WaitForSingleObject(proc, 2000); CloseHandle(proc); proc = nullptr; }
    }
    const char* Name() override { return "Aura"; }
};

using namespace winrt::Windows::Devices::Lights;
using namespace winrt::Windows::Devices::Enumeration;
struct WinDev : Device {
    LampArray la{nullptr};
    std::vector<int32_t> idx;
    std::vector<winrt::Windows::UI::Color> buf, last;
    bool Open() {
        try {
            auto list = DeviceInformation::FindAllAsync(LampArray::GetDeviceSelector()).get();
            LampArray pick{nullptr};
            for (auto const& d : list) {
                auto a = LampArray::FromIdAsync(d.Id()).get();
                if (!a) continue;
                L("keyboard: Dynamic Lighting '%ls' kind=%d lamps=%d", d.Name().c_str(), (int)a.LampArrayKind(), a.LampCount());
                if (a.LampArrayKind() == LampArrayKind::Keyboard && (!pick || a.LampCount() > pick.LampCount())) pick = a;
            }
            if (!pick) { L("keyboard: no Dynamic Lighting keyboard"); return false; }
            la = pick;
            auto bb = la.BoundingBox(); float W = std::max(0.001f, bb.x), H = std::max(0.001f, bb.y);
            int n = la.LampCount();
            for (int i = 0; i < n; ++i) { auto p = la.GetLampInfo(i).Position(); x.push_back(std::clamp(p.x / W, 0.f, 1.f)); y.push_back(std::clamp(p.y / H, 0.f, 1.f)); idx.push_back(i); }
            buf.resize(n); last.assign(n, winrt::Windows::UI::Color{1, 1, 2, 3});
            L("keyboard: Dynamic Lighting, %d lamps, available=%d", n, (int)la.IsAvailable());
            return n > 0;
        } catch (winrt::hresult_error const& e) { L("keyboard: Dynamic Lighting error 0x%08X", (unsigned)e.code()); return false; }
    }
    std::vector<int> Find(uint16_t, uint16_t vk) override {
        std::vector<int> r;
        try { auto v = la.GetIndicesForKey((winrt::Windows::System::VirtualKey)vk); for (auto i : v) r.push_back(i); } catch (...) {}
        return r;
    }
    bool Send(const std::vector<C3>& c) override {
        try {
            bool any = false;
            for (size_t i = 0; i < buf.size(); ++i) {
                buf[i] = {255, (uint8_t)(std::clamp(c[i].r, 0.f, 1.f) * 255), (uint8_t)(std::clamp(c[i].g, 0.f, 1.f) * 255), (uint8_t)(std::clamp(c[i].b, 0.f, 1.f) * 255)};
                if (buf[i].R != last[i].R || buf[i].G != last[i].G || buf[i].B != last[i].B) any = true;
            }
            if (any) { la.SetColorsForIndices(buf, idx); last = buf; }
            return true;
        } catch (winrt::hresult_error const& e) { L("keyboard: Dynamic Lighting lost (0x%08X)", (unsigned)e.code()); return false; }
    }
    const char* Name() override { return "Dynamic Lighting"; }
};

// ------------------------------------------------------------------------------------------------
// key roles
// ------------------------------------------------------------------------------------------------
struct KeyDef { uint16_t scan, vk; };
enum Role { RW, RA, RS, RD, RReload, RNext, RInteract, RDep1, RDep2, RCancel, RTab, REsc,
            RAb1, RAb2, RAb3, RAb1m, RAb2m, RAb3m,
            RF1, RF12 = RF1 + 11, RSh1, RSh6 = RSh1 + 5, RCount };
static KeyDef Def(int r) {
    static const KeyDef base[] = {
        {0x11, 'W'}, {0x1E, 'A'}, {0x1F, 'S'}, {0x20, 'D'}, {0x13, 'R'}, {0x12, 'E'}, {0x21, 'F'}, {0x14, 'T'}, {0x22, 'G'}, {0x2E, 'C'},
        {0x0F, VK_TAB}, {0x01, VK_ESCAPE},
        {0x02, '1'}, {0x03, '2'}, {0x04, '3'}, {0x1D, VK_LCONTROL}, {0x2A, VK_LSHIFT}, {0x39, VK_SPACE}};
    if (r < RF1) return base[r];
    if (r <= RF12) { int i = r - RF1; static const uint16_t sc[12] = {0x3B, 0x3C, 0x3D, 0x3E, 0x3F, 0x40, 0x41, 0x42, 0x43, 0x44, 0x57, 0x58}; return {sc[i], (uint16_t)(VK_F1 + i)}; }
    static const KeyDef sh[6] = {{0xD2, VK_INSERT}, {0xC7, VK_HOME}, {0xC9, VK_PRIOR}, {0xD3, VK_DELETE}, {0xCF, VK_END}, {0xD1, VK_NEXT}};
    return sh[r - RSh1];
}

static C3 HealthCol(float f) {
    if (f > 0.6f) return mix(rgb(255, 200, 0), rgb(0, 255, 60), (f - 0.6f) / 0.4f);
    if (f > 0.25f) return mix(rgb(255, 40, 0), rgb(255, 200, 0), (f - 0.25f) / 0.35f);
    return rgb(255, 0, 0);
}

// ------------------------------------------------------------------------------------------------
// renderer
// ------------------------------------------------------------------------------------------------
struct Ripple { double t0; float x, y; C3 c; float speed, width; };
struct FxRun { int fx; double t0; float x, y; };

static DWORD WINAPI Thread(LPVOID p) {
    int backend = (int)(intptr_t)p & 0xff, bright = (int)(intptr_t)p >> 8;
    winrt::init_apartment(winrt::apartment_type::multi_threaded);
    std::unique_ptr<Device> dev;
    double nextTry = 0; int tries = 0; bool auraTried = false, auraLive = false; std::unique_ptr<AuraDev> aura;
    std::vector<std::vector<int>> keys(RCount);
    std::vector<C3> col;
    std::vector<Ripple> ripples;
    double hitT = -10, deathT = -10, reviveT = -10, swapT = -10, reloadT = -10, uiT = -10, fireT = -10;
    float hitA = 0, reloadDur = 1.5f;
    double abUse[3] = {-10, -10, -10}; float abCool[3] = {10, 10, 10};
    double abBlink[3] = {-10, -10, -10}, abHeldT[3] = {-10, -10, -10}; bool abHeld[3] = {}; double abSeen[3] = {-10, -10, -10};
    auto KeyDown = [&](int r) { return (GetAsyncKeyState(Def(r).vk) & 0x8000) != 0; };
    std::vector<FxRun> fxPend, fxRun; double lastAbEv = -10, lastSwapEv = -10, lastTarget = -10; int lastAbSlot = 0;
    bool gHeld = false, tHeld = false, loggedKey = false;
    int lastDowned = 0; bool wasDead = false;
    const float B = std::clamp(bright, 10, 100) / 100.f;
    for (;;) {
        Sleep(33);
        double now = Now();
        auto attach = [&](std::unique_ptr<Device> d) {
            if (dev) dev->Close();
            dev = std::move(d);
            for (int r = 0; r < RCount; ++r) { KeyDef k = Def(r); keys[r] = dev->Find(k.scan, k.vk); }
            col.assign(dev->x.size(), C3{});
            ripples.push_back({now, 0.5f, 0.5f, rgb(0, 120, 255), 1.6f, 0.18f});   // hello
        };
        if (backend == Aura && !auraTried) {     // start the ASUS helper; Windows lighting covers the slow SDK start-up
            auraTried = true; aura = std::make_unique<AuraDev>(); if (!aura->Open()) aura.reset();
        }
        if (aura && dev.get() != aura.get()) {
            int r = aura->Poll();
            if (r == 1) { auto* a = aura.release(); attach(std::unique_ptr<Device>(a)); auraLive = true; }
            else if (r < 0) aura.reset();
        }
        if (!dev) {
            if (now < nextTry) continue;
            nextTry = now + 30;
            if (backend == Aura && auraLive) { auraTried = false; auraLive = false; continue; }   // Aura helper died: restart it
            auto w = std::make_unique<WinDev>();
            if (w->Open()) attach(std::move(w)); else if (!aura) { if (++tries == 3) L("keyboard: giving up"); if (tries >= 3) nextTry = now + 1e9; continue; }
            if (!dev) continue;
        }
        State s; std::vector<EvRec> ev;
        { std::lock_guard<std::mutex> lk(g_mx); s = g_s; ev.swap(g_ev); if (now - g_lastUpd > 0.5) s.inGame = false; }
        auto keyPos = [&](int r, float& x, float& y) { if (keys[r].empty()) { x = y = 0.5f; return; } x = dev->x[keys[r][0]]; y = dev->y[keys[r][0]]; };
        for (auto& e : ev) {
            switch (e.e) {
            case Hit: hitT = now; hitA = std::clamp(e.a * 1.6f + 0.25f, 0.f, 1.f); break;
            case Death: deathT = now; break;
            case Revive: reviveT = now; break;
            case Swap: swapT = now; lastSwapEv = now; break;
            case Reload: reloadT = now; reloadDur = std::max(0.3f, e.a); break;
            case Fire: fireT = now; break;
            case Ability: lastAbEv = now; lastAbSlot = e.i; if (e.i >= 0 && e.i < 3) {
                    abUse[e.i] = now; abCool[e.i] = std::max(1.f, e.a);
                    float x, y; keyPos(RAb1 + e.i, x, y); ripples.push_back({now, x, y, rgb(190, 40, 255), 1.4f, 0.14f});
                } break;
            case UiConfirm: uiT = now; break;
            case UiTab: { float x, y; keyPos(RTab, x, y); ripples.push_back({now, x, y, rgb(0, 140, 255), 2.2f, 0.1f}); } break;
            case FxRaw: fxPend.push_back({e.i, now, 0, 0}); break;
            case TargetStart: lastTarget = now; break;
            default: break;
            }
        }
        const size_t N = col.size();
        float hpF = s.hpMax > 0 ? std::clamp(s.hp / s.hpMax, 0.f, 1.f) : 1;
        // ---- base layer
        for (size_t i = 0; i < N; ++i) {
            float x = dev->x[i];
            C3 c;
            if (!s.inGame) {                       // menus: slow blue wave
                float w = 0.55f + 0.45f * sinf((float)(now * 1.2) - x * 4.f);
                c = rgb(0, 50, 190) * (0.25f + 0.35f * w);
            } else if (!s.mission) {               // hub / quarters: steady blue
                c = rgb(0, 70, 255) * 0.35f;
            } else {
                c = HealthCol(hpF) * 0.16f;
                if (hpF < 0.3f && !s.dead) {      // heartbeat
                    double period = 0.55 + hpF * 1.5; double ph = fmod(now, period) / period;
                    float beat = (float)(exp(-pow((ph - 0.08) / 0.04, 2)) + 0.6 * exp(-pow((ph - 0.24) / 0.05, 2)));
                    c = c + rgb(255, 0, 0) * (0.55f * beat);
                }
            }
            col[i] = c;
        }
        auto set = [&](int r, C3 c) { for (int i : keys[r]) col[i] = c; };
        // ---- key layer
        bool moving = s.moving;
        if (s.inGame) {
            C3 mv = rgb(0, 220, 255) * (moving ? 1.f : 0.75f);
            for (int r = RW; r <= RD; ++r) set(r, mv);
            set(RInteract, rgb(255, 190, 0) * 0.85f);
            set(REsc, rgb(255, 255, 255) * 0.3f);
        }
        if (s.inGame && s.mission) {
            // reload: R pulses while reloading, blinks when the magazine is nearly empty
            C3 r = rgb(255, 110, 0);
            float magF = s.magMax > 0 ? (float)s.mag / s.magMax : 1;
            if (s.reloading || now - reloadT < reloadDur) { float t = (float)((now - reloadT) / reloadDur); r = mix(rgb(255, 40, 0) * 0.3f, rgb(255, 160, 0), t) * (0.6f + 0.4f * (float)(sin(now * 18) > 0)); }
            else if (s.magMax > 0 && magF <= 0.25f) r = r * (sin(now * 14) > 0 ? 1.f : 0.15f);
            set(RReload, r);
            set(RNext, now - swapT < 0.25 ? rgb(255, 255, 255) : rgb(0, 255, 170) * 0.8f);
            set(RDep1, rgb(60, 255, 60) * 0.7f); set(RDep2, rgb(60, 255, 60) * 0.7f);
            set(RTab, rgb(255, 255, 255) * 0.35f);
            set(RCancel, s.targeting ? rgb(255, 30, 30) * (0.6f + 0.4f * (float)(sin(now * 10) > 0)) : rgb(255, 30, 30) * 0.15f);
            // abilities: the key goes dark while it is held, then blinks after release
            for (int a = 0; a < 3; ++a) {
                C3 c;
                int st = a < s.abCount ? s.ab[a] : AbNone;
                bool held = KeyDown(RAb1 + a) || KeyDown(RAb1m + a);
                if (held) { if (!abHeld[a]) abHeld[a] = true; abHeldT[a] = now; }
                else if (abHeld[a]) { abHeld[a] = false; abBlink[a] = now; }
                if (abUse[a] != abSeen[a]) { abSeen[a] = abUse[a]; if (now - abHeldT[a] > 0.6) abBlink[a] = now; }   // used from a gamepad
                double since = now - abUse[a], bl = now - abBlink[a];
                const double BL = 1.4, PER = 0.28;                       // 5 slow, bright blinks
                if (st == AbNone) c = {};
                else if (held) c = {};
                else if (bl < BL) c = fmod(bl, PER) < PER * 0.6 ? rgb(255, 170, 255) * 1.6f : C3{};
                else if (st == AbActive) c = rgb(255, 0, 200) * (0.7f + 0.3f * sinf((float)now * 12));
                else if (st == AbCharging) c = rgb(190, 40, 255) * (0.4f + 0.6f * (float)fmod(now * 2, 1.0));
                else if (st == AbCooldown || st == AbOut) {
                    float t = std::clamp((float)(since / abCool[a]), 0.f, 1.f);
                    c = mix(rgb(120, 0, 0) * 0.5f, rgb(190, 40, 255) * 0.5f, t);
                } else c = rgb(190, 40, 255);
                set(RAb1 + a, c); set(RAb1m + a, c * 0.9f);
            }
            // action keys go dark while held
            for (int r : {RReload, RNext, RInteract, RDep1, RDep2, RCancel, RTab})
                if (KeyDown(r)) { set(r, C3{}); if (!loggedKey) { loggedKey = true; L("keyboard: key press seen (role %d)", r); } }
            // health bar F1..F12, shield on the six navigation keys
            float segs = hpF * 12.f;
            for (int i = 0; i < 12; ++i) {
                float f = std::clamp(segs - i, 0.f, 1.f);
                C3 c = f > 0 ? HealthCol(hpF) * (0.25f + 0.75f * f) : rgb(255, 0, 0) * 0.05f;
                if (hpF < 0.25f && f > 0 && i == (int)ceilf(segs) - 1 && sin(now * 12) < 0) c = c * 0.15f;
                set(RF1 + i, c);
            }
            float shF = s.shMax > 0 ? std::clamp(s.sh / s.shMax, 0.f, 1.f) : 0;
            for (int i = 0; i < 6; ++i) { float f = std::clamp(shF * 6 - i, 0.f, 1.f); set(RSh1 + i, f > 0 ? rgb(0, 140, 255) * (0.25f + 0.75f * f) : C3{}); }
            if (s.downed) set(RAb3m, sin(now * 8) > 0 ? rgb(255, 255, 255) : rgb(255, 0, 0) * 0.3f);   // Space = self revive
        }
        // ---- whole-keyboard effects
        for (auto it = ripples.begin(); it != ripples.end();) {
            float r = (float)(now - it->t0) * it->speed;
            if (r > 1.8f) { it = ripples.erase(it); continue; }
            float fade = 1 - r / 1.8f;
            for (size_t i = 0; i < N; ++i) {
                float dx = dev->x[i] - it->x, dy = (dev->y[i] - it->y) * 0.35f, d = sqrtf(dx * dx + dy * dy);
                float k = std::max(0.f, 1 - fabsf(d - r) / it->width) * fade;
                if (k > 0) col[i] = maxc(col[i], it->c * k);
            }
            ++it;
        }
        // ---- per-ability / item effects (from the game's own sound events, local player only)
        for (auto it = fxPend.begin(); it != fxPend.end();) {
            int f = it->fx;
            bool ability = f >= FxAdrenaline && f <= FxOrbitalFire && f != FxOrbitalAim;
            bool ok = ability ? fabs(it->t0 - lastAbEv) < 0.6 : f == FxEquip ? fabs(it->t0 - lastSwapEv) < 0.6 : f == FxOrbitalAim ? it->t0 - lastTarget < 2.0 : true;
            if (ok) { float x, y; keyPos(ability ? RAb1 + std::clamp(lastAbSlot, 0, 2) : f == FxEquip ? RNext : RDep1, x, y); fxRun.push_back({f, now, x, y}); }
            if (ok || now - it->t0 > 0.7) it = fxPend.erase(it); else ++it;
        }
        if (s.inGame) {   // grenade / turret keys (keyboard players)
            bool g = KeyDown(RDep2), t = KeyDown(RDep1);
            if (gHeld && !g) { float x, y; keyPos(RDep2, x, y); fxRun.push_back({FxGrenade, now, x, y}); }
            gHeld = g; tHeld = t;
        }
        for (auto it = fxRun.begin(); it != fxRun.end();) {
            float t = (float)(now - it->t0); bool done = false;
            auto ring = [&](float r, float w, C3 c, float k) { for (size_t i = 0; i < N; ++i) { float dx = dev->x[i] - it->x, dy = (dev->y[i] - it->y) * 0.35f, d = sqrtf(dx * dx + dy * dy); float a = std::max(0.f, 1 - fabsf(d - r) / w) * k; if (a > 0) col[i] = maxc(col[i], c * a); } };
            auto all = [&](C3 c, float k) { if (k > 0) for (auto& q : col) q = mix(q, c, std::min(1.f, k)); };
            auto sweepX = [&](float p, float w, C3 c, float k) { for (size_t i = 0; i < N; ++i) { float a = std::max(0.f, 1 - fabsf(dev->x[i] - p) / w) * k; if (a > 0) col[i] = maxc(col[i], c * a); } };
            auto sweepY = [&](float p, float w, C3 c, float k) { for (size_t i = 0; i < N; ++i) { float a = std::max(0.f, 1 - fabsf(dev->y[i] - p) / w) * k; if (a > 0) col[i] = maxc(col[i], c * a); } };
            switch (it->fx) {
            case FxAdrenaline: { float beat = 0; for (int b = 0; b < 4; ++b) beat = std::max(beat, expf(-powf((t - b * 0.38f) / 0.06f, 2))); all(rgb(255, 40, 0), 0.85f * beat); ring(t * 1.2f, 0.15f, rgb(255, 80, 0), 1 - t / 1.6f); done = t > 1.6f; } break;
            case FxBiocleanse: sweepX(fmodf(t, 0.7f) / 0.7f * 1.3f - 0.15f, 0.12f, rgb(60, 255, 120), 1); all(rgb(0, 255, 80), 0.2f * (1 - t / 1.4f)); done = t > 1.4f; break;
            case FxDash: sweepX(t / 0.35f * 1.3f - 0.15f, 0.2f, rgb(200, 240, 255), 1); done = t > 0.4f; break;
            case FxDieAnotherDay: all(rgb(255, 200, 40), t < 0.15f ? 1.f : 0.7f * (1 - (t - 0.15f) / 1.85f)); done = t > 2.0f; break;
            case FxHaven: ring(t * 0.7f, 0.25f, rgb(40, 140, 255), 1 - t / 2.5f); all(rgb(0, 90, 255), 0.35f * (1 - t / 2.5f)); done = t > 2.5f; break;
            case FxHoldTheLine: sweepY(1.1f - t / 0.8f * 1.2f, 0.22f, rgb(255, 140, 0), t < 0.8f ? 1.f : 0.f); all(rgb(255, 110, 0), t > 0.8f ? 0.4f * (1 - (t - 0.8f) / 1.0f) : 0.f); done = t > 1.8f; break;
            case FxKinetic: ring(t * 2.6f, 0.12f, rgb(200, 230, 255), 1 - t / 0.8f); ring(std::max(0.f, t - 0.12f) * 2.6f, 0.1f, rgb(80, 160, 255), 1 - t / 0.8f); done = t > 0.8f; break;
            case FxMedkit: all(rgb(0, 255, 90), 0.75f * std::max(expf(-powf((t - 0.15f) / 0.12f, 2)), expf(-powf((t - 0.6f) / 0.12f, 2)))); done = t > 0.9f; break;
            case FxOrbitalAim: { float k = sinf(t * 25) > 0 ? 1.f : 0.f; ring(0.06f, 0.08f, rgb(255, 0, 0), k * (1 - t / 1.5f)); ring(0.2f, 0.05f, rgb(255, 0, 0), k * (1 - t / 1.5f)); done = t > 1.5f; } break;
            case FxOrbitalFire: { all(rgb(255, 255, 255), t < 0.1f ? 1.f : 0.f); ring(std::max(0.f, t - 0.1f) * 1.5f, 0.25f, rgb(255, 90, 0), 1 - t / 1.4f);
                float fl = 0.5f + 0.5f * sinf(t * 40) * sinf(t * 23); all(rgb(255, 60, 0), t > 0.1f ? 0.35f * fl * (1 - t / 1.4f) : 0.f); done = t > 1.4f; } break;
            case FxEquip: sweepX(t / 0.3f * 1.3f - 0.15f, 0.12f, rgb(0, 255, 200), 1); done = t > 0.32f; break;
            case FxCooldown: for (int r = RAb1; r <= RAb3m; ++r) for (int i : keys[r]) col[i] = maxc(col[i], rgb(255, 255, 255) * std::max(0.f, 1 - t / 0.35f)); done = t > 0.35f; break;
            case FxTurret: sweepY(1.1f - t / 0.6f * 1.2f, 0.15f, rgb(60, 255, 60), 1); done = t > 0.65f; break;
            case FxGrenade: { if (t > 0.55f) { float u = t - 0.55f; ring(u * 1.7f, 0.2f, rgb(255, 120, 0), 1 - u / 0.9f); all(rgb(255, 90, 0), u < 0.12f ? 0.7f : 0.f); }
                else for (int i : keys[RDep2]) col[i] = sinf(t * 30) > 0 ? rgb(255, 160, 0) : C3{};
                done = t > 1.45f; } break;
            default: done = true;
            }
            if (done) it = fxRun.erase(it); else ++it;
        }
        if (now - hitT < 0.4) { float k = hitA * (float)(1 - (now - hitT) / 0.4); for (auto& c : col) c = mix(c, rgb(255, 0, 0), k); }
        if (now - uiT < 0.2) { float k = 0.35f * (float)(1 - (now - uiT) / 0.2); for (auto& c : col) c = c + rgb(255, 255, 255) * k; }
        if (s.inGame && s.dead) {
            float t = (float)(now - deathT);
            float k = t < 2 ? 1 - t / 2 : 0.f;
            float br = 0.12f + 0.1f * sinf((float)now * 2);
            for (auto& c : col) c = rgb(255, 0, 0) * std::max(k, br);
            wasDead = true;
        } else if (wasDead && !s.dead) { wasDead = false; reviveT = now; }
        if (now - reviveT < 0.9) { float p = (float)(now - reviveT) / 0.9f * 1.3f; for (size_t i = 0; i < N; ++i) { float k = std::max(0.f, 1 - fabsf(dev->x[i] - p) / 0.15f); col[i] = maxc(col[i], rgb(0, 255, 80) * k); } }
        if (s.downed != lastDowned) { lastDowned = s.downed; if (s.downed) hitT = now, hitA = 1; }
        (void)fireT;
        for (auto& c : col) c = c * B;
        if (!dev->Send(col)) { dev->Close(); dev.reset(); nextTry = now + 5; }
    }
}

void Start(int backend, int brightness, LogFn log, const wchar_t* dir) {
    if (log) L = log; if (dir) g_dir = dir;
    if (backend != Aura && backend != Windows) return;
    g_on = true;
    CloseHandle(CreateThread(nullptr, 0, Thread, (LPVOID)(intptr_t)(backend | (brightness << 8)), 0, nullptr));
    L("keyboard lighting: %s", backend == Aura ? "ASUS Aura" : "Windows Dynamic Lighting");
}
}
