// ZAKbd: drives an ASUS Aura keyboard for ZAPad. The Aura SDK is an in-process COM server that
// must not live inside the Unity game, so ZAPad starts this helper and feeds it colours.
// usage: ZAKbd.exe <game pid>
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <comdef.h>
#include <cstdio>
#include <cwchar>
#include <vector>
#include <algorithm>
#include <cstdarg>
#include <string>
#include "kbshm.h"
#import "progid:aura.sdk.1" rename_namespace("AuraLib")

static FILE* g_log;
static void Lg(const char* f, ...) {
    if (!g_log) return; va_list a; va_start(a, f); vfprintf(g_log, f, a); va_end(a); fputc('\n', g_log); fflush(g_log);
}

int WINAPI wWinMain(HINSTANCE, HINSTANCE, LPWSTR cmd, int) {
    { wchar_t p[MAX_PATH]; GetModuleFileNameW(nullptr, p, MAX_PATH); std::wstring d(p); d = d.substr(0, d.find_last_of(L"\\")) + L"\\ZAKbd.log"; g_log = _wfopen(d.c_str(), L"w"); }
    unsigned pid = (unsigned)_wtoi(cmd);
    Lg("ZAKbd start, game pid %u", pid);
    HANDLE game = OpenProcess(SYNCHRONIZE, FALSE, pid);
    if (!game) return 1;
    wchar_t nm[64]; KBShm::Name(nm, 64, pid);
    HANDLE map = OpenFileMappingW(FILE_MAP_ALL_ACCESS, FALSE, nm);
    if (!map) return 2;
    auto* b = (KBShm::Block*)MapViewOfFile(map, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(KBShm::Block));
    if (!b) return 3;
    CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    AuraLib::IAuraSdk2Ptr sdk; AuraLib::IAuraSyncDevicePtr dev; std::vector<AuraLib::IAuraRgbLightPtr> lamps;
    try {
        HRESULT hr = sdk.CreateInstance(L"aura.sdk.1"); Lg("CreateInstance 0x%08X", (unsigned)hr);
        if (FAILED(hr)) throw 1;
        // the SDK discovers devices asynchronously and needs a message pump on this STA thread
        AuraLib::IAuraSyncDeviceCollectionPtr col;
        for (int t = 0; t < 90; ++t) {
            DWORD until = GetTickCount() + (t ? 1000 : 300);
            while (GetTickCount() < until) { MSG msg; while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&msg); DispatchMessageW(&msg); } Sleep(10); }
            if (WaitForSingleObject(game, 0) == WAIT_OBJECT_0 || b->quit) TerminateProcess(GetCurrentProcess(), 0);
            col = sdk->Enumerate(0);
            int kb = 0;
            for (int i = 0; i < col->Count; ++i) { AuraLib::IAuraSyncKeyboardPtr k; AuraLib::IAuraSyncDevicePtr d = col->Item[i]; d->QueryInterface(__uuidof(AuraLib::IAuraSyncKeyboard), (void**)&k); if (k) ++kb; }
            Lg("Enumerate try %d: %d devices, %d keyboards", t, (int)col->Count, kb);
            if (kb) break;
        }
        sdk->SwitchMode(); Lg("SwitchMode ok");
        int best = -1; long bestKeys = 0;
        for (int i = 0; i < col->Count; ++i) {
            AuraLib::IAuraSyncDevicePtr d = col->Item[i];
            AuraLib::IAuraSyncKeyboardPtr k; d->QueryInterface(__uuidof(AuraLib::IAuraSyncKeyboard), (void**)&k);
            long n = 0; if (k) { try { n = k->Keys->Count; } catch (...) {} }
            Lg("  device %d %s type 0x%X keys %ld", i, (const char*)d->Name, (unsigned)d->Type, n);
            if (n > bestKeys) { bestKeys = n; best = i; }
        }
        if (best < 0) throw 2;
        dev = col->Item[best];
        strncpy_s(b->name, (const char*)dev->Name, _TRUNCATE);
        AuraLib::IAuraSyncKeyboardPtr k; dev->QueryInterface(__uuidof(AuraLib::IAuraSyncKeyboard), (void**)&k);
        float W = (float)std::max<long>(1, dev->Width - 1), H = (float)std::max<long>(1, dev->Height - 1);
        AuraLib::IAuraRgbKeyCollectionPtr keys = k->Keys;
        int n = 0;
        for (int i = 0; i < keys->Count && n < KBShm::Max; ++i) {
            AuraLib::IAuraRgbKeyPtr key = keys->Item[i];
            uint16_t code = (uint16_t)key->Code; if (!code) continue;
            lamps.push_back(AuraLib::IAuraRgbLightPtr(key));
            b->code[n] = code; b->x[n] = key->X / W; b->y[n] = key->Y / H; ++n;
        }
        b->count = n;
        InterlockedExchange(&b->ready, n > 0 ? 1 : -1);
    } catch (_com_error& e) { Lg("COM error 0x%08X", (unsigned)e.Error()); InterlockedExchange(&b->ready, -1); TerminateProcess(GetCurrentProcess(), 4); return 4; }
    catch (int c) { Lg("fail %d", c); InterlockedExchange(&b->ready, -1); TerminateProcess(GetCurrentProcess(), 4); return 4; }
    catch (...) { Lg("fail"); InterlockedExchange(&b->ready, -1); TerminateProcess(GetCurrentProcess(), 4); return 4; }
    Lg("ready: %d keys", b->count);
    std::vector<uint32_t> last(lamps.size(), 0xffffffff);
    long seen = -1;
    while (!b->quit && MsgWaitForMultipleObjects(1, &game, FALSE, 15, QS_ALLINPUT) != WAIT_OBJECT_0) {
        { MSG msg; while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&msg); DispatchMessageW(&msg); } }
        long s = b->seq; if (s == seen) continue; seen = s;
        try {
            bool any = false;
            for (size_t i = 0; i < lamps.size(); ++i) if (b->color[i] != last[i]) { last[i] = b->color[i]; lamps[i]->Color = last[i]; any = true; }
            if (any) dev->Apply();
        } catch (...) { break; }
    }
    try { sdk->ReleaseControl(0); } catch (...) {}
    Lg("exit");
    TerminateProcess(GetCurrentProcess(), 0);
    return 0;
}
