// ZaVoice: replaces voice lines inside Wwise 2025 sound banks (bank version 0xAC)
// with PCM media built from user WAV recordings. C# 5 (Windows PowerShell Add-Type).
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ZaVoice
{
    public static class Wav
    {
        // Reads any PCM/float WAV, returns mono float samples.
        public static float[] ReadMono(string path, out int rate)
        {
            byte[] b = File.ReadAllBytes(path);
            if (b.Length < 12 || Encoding.ASCII.GetString(b, 0, 4) != "RIFF" || Encoding.ASCII.GetString(b, 8, 4) != "WAVE")
                throw new Exception("не WAV-файл");
            int p = 12, fmt = 0, ch = 0, bits = 0, dataOff = -1, dataLen = 0;
            rate = 0;
            while (p + 8 <= b.Length)
            {
                string id = Encoding.ASCII.GetString(b, p, 4);
                int len = BitConverter.ToInt32(b, p + 4);
                int body = p + 8;
                if (id == "fmt ")
                {
                    fmt = BitConverter.ToUInt16(b, body);
                    ch = BitConverter.ToUInt16(b, body + 2);
                    rate = BitConverter.ToInt32(b, body + 4);
                    bits = BitConverter.ToUInt16(b, body + 14);
                    if (fmt == 0xFFFE && len >= 40) fmt = BitConverter.ToUInt16(b, body + 24);
                }
                else if (id == "data")
                {
                    dataOff = body;
                    dataLen = Math.Min(len < 0 ? int.MaxValue : len, b.Length - body);
                    break;
                }
                p = body + len + (len & 1);
            }
            if (dataOff < 0 || ch < 1 || rate < 8000) throw new Exception("повреждённый WAV");
            if (fmt != 1 && fmt != 3) throw new Exception("WAV должен быть PCM или float (формат " + fmt + ")");
            int bps = bits / 8;
            int frames = dataLen / (bps * ch);
            float[] o = new float[frames];
            for (int i = 0; i < frames; i++)
            {
                double s = 0;
                for (int c = 0; c < ch; c++)
                {
                    int q = dataOff + (i * ch + c) * bps;
                    double v;
                    if (fmt == 3 && bits == 32) v = BitConverter.ToSingle(b, q);
                    else if (fmt == 3 && bits == 64) v = BitConverter.ToDouble(b, q);
                    else if (bits == 8) v = (b[q] - 128) / 128.0;
                    else if (bits == 16) v = BitConverter.ToInt16(b, q) / 32768.0;
                    else if (bits == 24) v = ((b[q] | (b[q + 1] << 8) | (b[q + 2] << 16)) << 8 >> 8) / 8388608.0;
                    else if (bits == 32) v = BitConverter.ToInt32(b, q) / 2147483648.0;
                    else throw new Exception("неподдерживаемая разрядность " + bits);
                    s += v;
                }
                o[i] = (float)(s / ch);
            }
            return o;
        }
    }

    public static class Dsp
    {
        public static float[] Resample(float[] x, int from, int to)
        {
            if (from == to) return x;
            double ratio = (double)to / from;
            int n = (int)Math.Floor(x.Length * ratio);
            float[] y = new float[n];
            double cutoff = Math.Min(1.0, ratio) * 0.95;
            const int half = 24, phases = 1024;
            float[] tab = new float[(phases + 1) * 2 * half];
            for (int ph = 0; ph <= phases; ph++)
            {
                double frac = (double)ph / phases;
                for (int j = 0; j < 2 * half; j++)
                {
                    double d = frac + (half - 1) - j;      // t - k, k = c - half + 1 + j
                    double arg = Math.PI * d * cutoff;
                    double sinc = Math.Abs(d) < 1e-9 ? 1.0 : Math.Sin(arg) / arg;
                    double w = Math.Abs(d) >= half ? 0 : 0.42 + 0.5 * Math.Cos(Math.PI * d / half) + 0.08 * Math.Cos(2 * Math.PI * d / half);
                    tab[ph * 2 * half + j] = (float)(sinc * w * cutoff);
                }
            }
            for (int i = 0; i < n; i++)
            {
                double t = i / ratio;
                int c = (int)Math.Floor(t);
                int ph = (int)Math.Round((t - c) * phases);
                int baseK = c - half + 1, row = ph * 2 * half;
                double acc = 0;
                for (int j = 0; j < 2 * half; j++)
                {
                    int k = baseK + j;
                    if (k < 0 || k >= x.Length) continue;
                    acc += x[k] * tab[row + j];
                }
                y[i] = (float)acc;
            }
            return y;
        }

        // remove DC, trim leading/trailing silence, bring voiced loudness to target, limit peaks
        public static float[] Master(float[] x, int rate, bool normalize, out string note)
        {
            note = "";
            if (x.Length == 0) return x;
            double mean = 0; foreach (float v in x) mean += v; mean /= x.Length;
            float[] y = new float[x.Length];
            for (int i = 0; i < x.Length; i++) y[i] = (float)(x[i] - mean);
            int frame = Math.Max(1, rate / 50);
            int nf = y.Length / frame;
            double[] e = new double[Math.Max(1, nf)];
            double emax = 0;
            for (int f = 0; f < nf; f++)
            {
                double s = 0; for (int i = f * frame; i < (f + 1) * frame; i++) s += y[i] * y[i];
                e[f] = Math.Sqrt(s / frame); if (e[f] > emax) emax = e[f];
            }
            if (emax <= 1e-6) { note = "тишина"; return y; }
            double thr = Math.Max(emax * 0.03, 0.0015);
            int first = 0, last = nf - 1;
            while (first < nf && e[first] < thr) first++;
            while (last > first && e[last] < thr) last--;
            int pad = rate * 60 / 1000;
            int a = Math.Max(0, first * frame - pad), z = Math.Min(y.Length, (last + 1) * frame + pad);
            float[] t = new float[Math.Max(0, z - a)];
            Array.Copy(y, a, t, 0, t.Length);
            if (!normalize) return t;
            double vs = 0; int vc = 0;
            for (int f = first; f <= last && f < nf; f++) if (e[f] > emax * 0.12) { vs += e[f] * e[f]; vc++; }
            double rms = vc > 0 ? Math.Sqrt(vs / vc) : emax;
            double peak = 0; foreach (float v in t) peak = Math.Max(peak, Math.Abs(v));
            double gain = 0.158 / rms;                  // -16 dBFS voiced RMS, like the original lines
            if (peak * gain > 0.89) gain = 0.89 / peak;  // keep peaks under -1 dBFS
            for (int i = 0; i < t.Length; i++) t[i] = (float)(t[i] * gain);
            note = string.Format("{0:+0.0;-0.0} дБ", 20 * Math.Log10(gain));
            return t;
        }

        public static float[] Beeps(int rate, double seconds)
        {
            int n = (int)(rate * Math.Max(0.6, Math.Min(seconds, 2.0)));
            float[] y = new float[n];
            for (int i = 0; i < n; i++)
            {
                double tt = (double)i / rate;
                double f = tt < 0.18 ? 660 : (tt > 0.25 && tt < 0.43 ? 990 : 0);
                double env = Math.Min(1, Math.Min(tt * 200, (n - i) / (double)rate * 200));
                y[i] = (float)(f > 0 ? 0.35 * Math.Sin(2 * Math.PI * f * tt) * env : 0);
            }
            return y;
        }
    }

    public class Section { public string Tag; public byte[] Data; }

    public static class Bank
    {
        public const uint PLUGIN_PCM = 0x00010001;
        public const uint PLUGIN_VORBIS = 0x00040001;

        static List<Section> Read(byte[] b)
        {
            List<Section> s = new List<Section>();
            int p = 0;
            while (p + 8 <= b.Length)
            {
                Section x = new Section();
                x.Tag = Encoding.ASCII.GetString(b, p, 4);
                int len = BitConverter.ToInt32(b, p + 4);
                x.Data = new byte[len];
                Buffer.BlockCopy(b, p + 8, x.Data, 0, len);
                s.Add(x);
                p += 8 + len;
            }
            return s;
        }

        static Section Get(List<Section> s, string tag)
        {
            foreach (Section x in s) if (x.Tag == tag) return x;
            return null;
        }

        static byte[] HashChunk(byte[] wem)
        {
            int p = 12;
            while (p + 8 <= wem.Length)
            {
                string id = Encoding.ASCII.GetString(wem, p, 4);
                int len = BitConverter.ToInt32(wem, p + 4);
                if (id == "hash" && len == 16) { byte[] h = new byte[16]; Buffer.BlockCopy(wem, p + 8, h, 0, 16); return h; }
                if (id == "data") break;
                p += 8 + len + (len & 1);
            }
            return null;
        }

        public static byte[] PcmWem(float[] x, int rate, byte[] hash)
        {
            MemoryStream ms = new MemoryStream();
            BinaryWriter w = new BinaryWriter(ms);
            int dataLen = x.Length * 2;
            w.Write(Encoding.ASCII.GetBytes("RIFF")); w.Write(0); w.Write(Encoding.ASCII.GetBytes("WAVE"));
            w.Write(Encoding.ASCII.GetBytes("fmt ")); w.Write(24);
            w.Write((ushort)0xFFFE); w.Write((ushort)1); w.Write(rate); w.Write(rate * 2);
            w.Write((ushort)2); w.Write((ushort)16); w.Write((ushort)6); w.Write((ushort)0);
            w.Write((uint)0x00004101);                 // AkChannelConfig: 1 channel, standard, FC
            if (hash != null) { w.Write(Encoding.ASCII.GetBytes("hash")); w.Write(16); w.Write(hash); }
            w.Write(Encoding.ASCII.GetBytes("data")); w.Write(dataLen);
            for (int i = 0; i < x.Length; i++)
            {
                double v = Math.Max(-1.0, Math.Min(1.0, x[i]));
                w.Write((short)Math.Round(v * 32767));
            }
            w.Flush();
            byte[] r = ms.ToArray();
            BitConverter.GetBytes(r.Length - 8).CopyTo(r, 4);
            return r;
        }

        // media: id -> new wem bytes. Returns new bank bytes.
        public static byte[] Rebuild(byte[] orig, Dictionary<uint, byte[]> media)
        {
            List<Section> s = Read(orig);
            Section didx = Get(s, "DIDX"), data = Get(s, "DATA"), hirc = Get(s, "HIRC");
            int n = didx.Data.Length / 12;
            MemoryStream nd = new MemoryStream();
            byte[] ndidx = new byte[didx.Data.Length];
            for (int k = 0; k < n; k++)
            {
                uint id = BitConverter.ToUInt32(didx.Data, k * 12);
                int off = BitConverter.ToInt32(didx.Data, k * 12 + 4);
                int sz = BitConverter.ToInt32(didx.Data, k * 12 + 8);
                byte[] payload;
                if (!media.TryGetValue(id, out payload))
                {
                    payload = new byte[sz];
                    Buffer.BlockCopy(data.Data, off, payload, 0, sz);
                }
                while (nd.Length % 16 != 0) nd.WriteByte(0);
                int noff = (int)nd.Length;
                nd.Write(payload, 0, payload.Length);
                BitConverter.GetBytes(id).CopyTo(ndidx, k * 12);
                BitConverter.GetBytes(noff).CopyTo(ndidx, k * 12 + 4);
                BitConverter.GetBytes(payload.Length).CopyTo(ndidx, k * 12 + 8);
            }
            didx.Data = ndidx;
            data.Data = nd.ToArray();
            // HIRC: CAkSound (type 2) -> AkBankSourceData {plugin, streamType, sourceID, cacheID, mediaSize}
            byte[] h = hirc.Data;
            int cnt = BitConverter.ToInt32(h, 0), p = 4;
            for (int i = 0; i < cnt; i++)
            {
                byte type = h[p];
                int size = BitConverter.ToInt32(h, p + 1);
                int body = p + 9;
                if (type == 2)
                {
                    uint sid = BitConverter.ToUInt32(h, body + 5);
                    byte[] payload;
                    if (media.TryGetValue(sid, out payload))
                    {
                        BitConverter.GetBytes(PLUGIN_PCM).CopyTo(h, body);
                        BitConverter.GetBytes(payload.Length).CopyTo(h, body + 13);
                    }
                }
                p += 5 + size;
            }
            MemoryStream o = new MemoryStream();
            foreach (Section x in s)
            {
                o.Write(Encoding.ASCII.GetBytes(x.Tag), 0, 4);
                o.Write(BitConverter.GetBytes(x.Data.Length), 0, 4);
                o.Write(x.Data, 0, x.Data.Length);
            }
            return o.ToArray();
        }

        // wavs: media id -> wav path (or "<test>" for a beep). Returns report lines.
        public static string[] Build(string origBank, string outBank, Dictionary<uint, string> wavs, int maxRate, bool normalize)
        {
            byte[] orig = File.ReadAllBytes(origBank);
            List<Section> s = Read(orig);
            Section didx = Get(s, "DIDX"), data = Get(s, "DATA");
            Dictionary<uint, byte[]> media = new Dictionary<uint, byte[]>();
            List<string> rep = new List<string>();
            for (int k = 0; k + 12 <= didx.Data.Length; k += 12)
            {
                uint id = BitConverter.ToUInt32(didx.Data, k);
                string wav;
                if (!wavs.TryGetValue(id, out wav)) continue;
                int off = BitConverter.ToInt32(didx.Data, k + 4), sz = BitConverter.ToInt32(didx.Data, k + 8);
                byte[] old = new byte[sz]; Buffer.BlockCopy(data.Data, off, old, 0, sz);
                try
                {
                    int rate; float[] x; string note = "";
                    if (wav == "<test>") { rate = 32000; x = Dsp.Beeps(rate, 1.0); }
                    else
                    {
                        x = Wav.ReadMono(wav, out rate);
                        x = Dsp.Master(x, rate, normalize, out note);
                        if (rate > maxRate) { x = Dsp.Resample(x, rate, maxRate); rate = maxRate; }
                    }
                    media[id] = PcmWem(x, rate, HashChunk(old));
                    rep.Add("OK|" + id + "|" + Path.GetFileName(wav) + "|" + string.Format("{0:0.0} с", (double)x.Length / rate) + " " + note);
                }
                catch (Exception e)
                {
                    rep.Add("ERR|" + id + "|" + Path.GetFileName(wav) + "|" + e.Message);
                }
            }
            File.WriteAllBytes(outBank, Rebuild(orig, media));
            return rep.ToArray();
        }
    }
}
