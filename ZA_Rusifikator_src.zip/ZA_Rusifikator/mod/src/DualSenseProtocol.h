// DualSenseProtocol.h — platform-independent DualSense (PS5) HID report layer.
//
// Builds output reports (USB 0x02 / Bluetooth 0x31 with CRC32), encodes every
// known adaptive-trigger effect and parses input reports. No OS or GameInput
// dependencies, so it can be unit-tested anywhere and reused in any mod.
//
// Byte layout follows the Linux hid-playstation driver's
// dualsense_output_report_common / dualsense_input_report structures.
// Trigger encodings follow the community-documented DualSense effect formats.
//
// MIT License. Based on Microsoft's DualSenseHelper.h (GameInput companion),
// extended by Tianku: GameInput v4, Bluetooth, all trigger modes, input parsing.

#pragma once

#include <stdint.h>
#include <stddef.h>
#include <string.h>

namespace DS5 {

enum class Transport : uint8_t { Usb = 0, Bluetooth = 1 };
enum class Trigger   : uint8_t { Right = 0, Left = 1 };

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

constexpr uint16_t SonyVendorId           = 0x054C;
constexpr uint16_t DualSenseProductId     = 0x0CE6;
constexpr uint16_t DualSenseEdgeProductId = 0x0DF2;

inline bool IsDualSense(uint16_t vid, uint16_t pid) noexcept
{
    return vid == SonyVendorId && (pid == DualSenseProductId || pid == DualSenseEdgeProductId);
}

constexpr size_t MaxReportSize = 128;

// USB output report 0x02: [0]=id, common block at [1..47].
constexpr uint8_t UsbOutputReportId   = 0x02;
constexpr size_t  UsbCommonOffset     = 1;
constexpr size_t  UsbMinReportSize    = 48;   // id + 47-byte common block
constexpr size_t  UsbDefaultReportSize = 64;  // size proven by Microsoft's helper

// Bluetooth output report 0x31: [0]=id, [1]=seq<<4, [2]=tag 0x10, common at [3..49],
// CRC32 (seed byte 0xA2 + bytes [0..73]) little-endian at [74..77].
constexpr uint8_t BtOutputReportId = 0x31;
constexpr size_t  BtCommonOffset   = 3;
constexpr size_t  BtReportSize     = 78;
constexpr size_t  BtCrcOffset      = 74;
constexpr uint8_t BtOutputTag      = 0x10;
constexpr uint8_t BtCrcSeedOutput  = 0xA2;
constexpr uint8_t BtCrcSeedInput   = 0xA1;
constexpr uint8_t BtCrcSeedFeature = 0xA3;

// Offsets inside the 47-byte common block.
namespace Common {
    constexpr size_t Size              = 47;
    constexpr size_t ValidFlag0        = 0;
    constexpr size_t ValidFlag1        = 1;
    constexpr size_t MotorRight        = 2;   // weak / high-frequency
    constexpr size_t MotorLeft         = 3;   // strong / low-frequency
    constexpr size_t HeadphoneVolume   = 4;
    constexpr size_t SpeakerVolume     = 5;
    constexpr size_t MicVolume         = 6;
    constexpr size_t AudioFlags        = 7;
    constexpr size_t MuteLed           = 8;
    constexpr size_t PowerSave         = 9;
    constexpr size_t RightTrigger      = 10;  // 11 bytes
    constexpr size_t LeftTrigger       = 21;  // 11 bytes
    constexpr size_t MotorPowerLevel   = 36;  // low nibble: trigger reduction, high: rumble reduction
    constexpr size_t AudioFlags2       = 37;
    constexpr size_t ValidFlag2        = 38;  // NB: original helper used 40 (USB abs) — correct is 39 (USB abs)
    constexpr size_t LightbarSetup     = 41;
    constexpr size_t LedBrightness     = 42;
    constexpr size_t PlayerLeds        = 43;
    constexpr size_t LightbarRed       = 44;
    constexpr size_t LightbarGreen     = 45;
    constexpr size_t LightbarBlue      = 46;
}

constexpr size_t TriggerEffectSize = 11;

namespace Flag0 {
    constexpr uint8_t CompatibleVibration = 0x01;
    constexpr uint8_t HapticsSelect       = 0x02;
    constexpr uint8_t RightTriggerEffect  = 0x04;
    constexpr uint8_t LeftTriggerEffect   = 0x08;
    constexpr uint8_t HeadphoneVolume     = 0x10;
    constexpr uint8_t SpeakerVolume       = 0x20;
    constexpr uint8_t MicVolume           = 0x40;
    constexpr uint8_t AudioControl        = 0x80;
}
namespace Flag1 {
    constexpr uint8_t MicMuteLed      = 0x01;
    constexpr uint8_t PowerSave       = 0x02;
    constexpr uint8_t Lightbar        = 0x04;
    constexpr uint8_t ReleaseLeds     = 0x08;
    constexpr uint8_t PlayerLeds      = 0x10;
    constexpr uint8_t MotorPowerLevel = 0x40;
    constexpr uint8_t AudioControl2   = 0x80;
}
namespace Flag2 {
    constexpr uint8_t LedBrightness        = 0x01;
    constexpr uint8_t LightbarSetup        = 0x02;
    constexpr uint8_t CompatibleVibration2 = 0x04;
}
namespace PowerSaveBits {
    constexpr uint8_t MicMute = 0x10;
}
namespace LightbarSetupBits {
    constexpr uint8_t LightOn  = 0x01;
    constexpr uint8_t LightOut = 0x02;   // fade out the firmware's blue start-up glow
}

enum class MuteLed : uint8_t { Off = 0, On = 1, Pulse = 2 };
enum class LedBrightness : uint8_t { High = 0, Medium = 1, Low = 2 };

// 5 LEDs under the touchpad, bit0 = leftmost. Same patterns as the PS5 / Linux driver.
constexpr uint8_t PlayerLedPatterns[6] = { 0x00, 0x04, 0x0A, 0x15, 0x1B, 0x1F };
constexpr uint8_t PlayerLedInstant     = 0x20;  // skip the fade-in animation

// ---------------------------------------------------------------------------
// CRC32 (zlib polynomial, reflected) used by Bluetooth reports
// ---------------------------------------------------------------------------

inline uint32_t Crc32Update(uint32_t crc, const uint8_t* data, size_t len) noexcept
{
    for (size_t i = 0; i < len; ++i)
    {
        crc ^= data[i];
        for (int b = 0; b < 8; ++b)
        {
            crc = (crc >> 1) ^ (0xEDB88320u & (0u - (crc & 1u)));
        }
    }
    return crc;
}

inline uint32_t BtCrc32(uint8_t seed, const uint8_t* data, size_t len) noexcept
{
    uint32_t crc = Crc32Update(0xFFFFFFFFu, &seed, 1);
    crc = Crc32Update(crc, data, len);
    return ~crc;
}

// ---------------------------------------------------------------------------
// Adaptive trigger effects
// ---------------------------------------------------------------------------

struct TriggerEffect
{
    uint8_t bytes[TriggerEffectSize] = {};
};

namespace TriggerMode {
    constexpr uint8_t Off              = 0x05;
    constexpr uint8_t SimpleFeedback   = 0x01;  // legacy "rigid"
    constexpr uint8_t SimpleWeapon     = 0x02;  // legacy "section"
    constexpr uint8_t SimpleVibration  = 0x06;  // legacy
    constexpr uint8_t Feedback         = 0x21;
    constexpr uint8_t Bow              = 0x22;
    constexpr uint8_t Galloping        = 0x23;
    constexpr uint8_t Weapon           = 0x25;
    constexpr uint8_t Vibration        = 0x26;
    constexpr uint8_t Machine          = 0x27;
}

// All encoders return nullptr on success or a static error string.

inline const char* EncodeTriggerOff(TriggerEffect& e) noexcept
{
    e = TriggerEffect{};
    e.bytes[0] = TriggerMode::Off;
    return nullptr;
}

// Legacy modes, identical to Microsoft's helper.
inline const char* EncodeSimpleFeedback(TriggerEffect& e, uint8_t startPosition, uint8_t force) noexcept
{
    e = TriggerEffect{};
    e.bytes[0] = TriggerMode::SimpleFeedback;
    e.bytes[1] = startPosition;
    e.bytes[2] = force;
    return nullptr;
}

inline const char* EncodeSimpleWeapon(TriggerEffect& e, uint8_t startPosition, uint8_t endPosition, uint8_t strength) noexcept
{
    e = TriggerEffect{};
    e.bytes[0] = TriggerMode::SimpleWeapon;
    e.bytes[1] = startPosition;
    e.bytes[2] = endPosition;
    e.bytes[3] = strength;
    return nullptr;
}

inline const char* EncodeSimpleVibration(TriggerEffect& e, uint8_t frequency, uint8_t resistance, uint8_t startPosition) noexcept
{
    e = TriggerEffect{};
    e.bytes[0] = TriggerMode::SimpleVibration;
    e.bytes[1] = frequency;
    e.bytes[2] = resistance;
    e.bytes[3] = startPosition;
    return nullptr;
}

namespace Detail {
    inline void PutZones(TriggerEffect& e, uint8_t mode, uint16_t activeZones, uint32_t packed) noexcept
    {
        e = TriggerEffect{};
        e.bytes[0] = mode;
        e.bytes[1] = static_cast<uint8_t>(activeZones & 0xFF);
        e.bytes[2] = static_cast<uint8_t>((activeZones >> 8) & 0xFF);
        e.bytes[3] = static_cast<uint8_t>(packed & 0xFF);
        e.bytes[4] = static_cast<uint8_t>((packed >> 8) & 0xFF);
        e.bytes[5] = static_cast<uint8_t>((packed >> 16) & 0xFF);
        e.bytes[6] = static_cast<uint8_t>((packed >> 24) & 0xFF);
    }
}

// Per-zone resistance. strengths[i] in 0..8 for each of the 10 zones (0 = none).
inline const char* EncodeMultiFeedback(TriggerEffect& e, const uint8_t strengths[10]) noexcept
{
    uint16_t active = 0;
    uint32_t packed = 0;
    for (int i = 0; i < 10; ++i)
    {
        if (strengths[i] > 8) return "strength values must be 0..8";
        if (strengths[i] > 0)
        {
            packed |= static_cast<uint32_t>((strengths[i] - 1) & 0x07) << (3 * i);
            active |= static_cast<uint16_t>(1u << i);
        }
    }
    if (active == 0) return EncodeTriggerOff(e);
    Detail::PutZones(e, TriggerMode::Feedback, active, packed);
    return nullptr;
}

// Constant resistance from position (0..9) to the end of travel. strength 0..8.
inline const char* EncodeFeedback(TriggerEffect& e, uint8_t position, uint8_t strength) noexcept
{
    if (position > 9) return "position must be 0..9";
    if (strength > 8) return "strength must be 0..8";
    uint8_t s[10] = {};
    for (int i = position; i < 10; ++i) s[i] = strength;
    return EncodeMultiFeedback(e, s);
}

// Linear ramp of resistance between two positions.
// start 0..8, end start+1..9, strengths 1..8.
inline const char* EncodeSlopeFeedback(TriggerEffect& e, uint8_t startPosition, uint8_t endPosition,
                                       uint8_t startStrength, uint8_t endStrength) noexcept
{
    if (startPosition > 8) return "start must be 0..8";
    if (endPosition <= startPosition || endPosition > 9) return "end must be start+1..9";
    if (startStrength < 1 || startStrength > 8 || endStrength < 1 || endStrength > 8) return "strengths must be 1..8";
    uint8_t s[10] = {};
    const float slope = (static_cast<float>(endStrength) - startStrength) / (endPosition - startPosition);
    for (int i = startPosition; i < 10; ++i)
    {
        if (i <= endPosition)
        {
            const float v = startStrength + slope * (i - startPosition);
            s[i] = static_cast<uint8_t>(v + 0.5f);
        }
        else
        {
            s[i] = endStrength;
        }
    }
    return EncodeMultiFeedback(e, s);
}

// Gun trigger: resistance between start and end, then it "breaks" and snaps.
// start 2..7, end start+1..8, strength 1..8.
inline const char* EncodeWeapon(TriggerEffect& e, uint8_t startPosition, uint8_t endPosition, uint8_t strength) noexcept
{
    if (startPosition < 2 || startPosition > 7) return "start must be 2..7";
    if (endPosition <= startPosition || endPosition > 8) return "end must be start+1..8";
    if (strength > 8) return "strength must be 0..8";
    if (strength == 0) return EncodeTriggerOff(e);
    const uint16_t zones = static_cast<uint16_t>((1u << startPosition) | (1u << endPosition));
    Detail::PutZones(e, TriggerMode::Weapon, zones, static_cast<uint32_t>(strength - 1));
    return nullptr;
}

// Bow string: resistance between start and end, snap-back force after release.
// start 0..8, end start+1..8, strength 1..8, snapForce 1..8.
inline const char* EncodeBow(TriggerEffect& e, uint8_t startPosition, uint8_t endPosition,
                             uint8_t strength, uint8_t snapForce) noexcept
{
    if (startPosition > 8) return "start must be 0..8";
    if (endPosition <= startPosition || endPosition > 8) return "end must be start+1..8";
    if (strength > 8 || snapForce > 8) return "strength and snap_force must be 0..8";
    if (strength == 0 || snapForce == 0) return EncodeTriggerOff(e);
    const uint16_t zones = static_cast<uint16_t>((1u << startPosition) | (1u << endPosition));
    const uint32_t pair = static_cast<uint32_t>(((strength - 1) & 0x07) | (((snapForce - 1) & 0x07) << 3));
    Detail::PutZones(e, TriggerMode::Bow, zones, pair);
    return nullptr;
}

// Horse gallop: two "feet" taps per cycle between start and end.
// start 0..8, end start+1..9, firstFoot 0..6, secondFoot firstFoot+1..7, frequency 1..255 Hz.
inline const char* EncodeGalloping(TriggerEffect& e, uint8_t startPosition, uint8_t endPosition,
                                   uint8_t firstFoot, uint8_t secondFoot, uint8_t frequency) noexcept
{
    if (startPosition > 8) return "start must be 0..8";
    if (endPosition <= startPosition || endPosition > 9) return "end must be start+1..9";
    if (firstFoot > 6) return "first_foot must be 0..6";
    if (secondFoot <= firstFoot || secondFoot > 7) return "second_foot must be first_foot+1..7";
    if (frequency == 0) return EncodeTriggerOff(e);
    const uint16_t zones = static_cast<uint16_t>((1u << startPosition) | (1u << endPosition));
    const uint8_t ratio = static_cast<uint8_t>((secondFoot & 0x07) | ((firstFoot & 0x07) << 3));
    e = TriggerEffect{};
    e.bytes[0] = TriggerMode::Galloping;
    e.bytes[1] = static_cast<uint8_t>(zones & 0xFF);
    e.bytes[2] = static_cast<uint8_t>((zones >> 8) & 0xFF);
    e.bytes[3] = ratio;
    e.bytes[4] = frequency;
    return nullptr;
}

// Per-zone vibration. amplitudes[i] 0..8, frequency 1..255 Hz.
inline const char* EncodeMultiVibration(TriggerEffect& e, uint8_t frequency, const uint8_t amplitudes[10]) noexcept
{
    if (frequency == 0) return EncodeTriggerOff(e);
    uint16_t active = 0;
    uint32_t packed = 0;
    for (int i = 0; i < 10; ++i)
    {
        if (amplitudes[i] > 8) return "amplitude values must be 0..8";
        if (amplitudes[i] > 0)
        {
            packed |= static_cast<uint32_t>((amplitudes[i] - 1) & 0x07) << (3 * i);
            active |= static_cast<uint16_t>(1u << i);
        }
    }
    if (active == 0) return EncodeTriggerOff(e);
    Detail::PutZones(e, TriggerMode::Vibration, active, packed);
    e.bytes[9] = frequency;
    return nullptr;
}

// Vibration from position (0..9) to end. amplitude 0..8, frequency 1..255 Hz.
inline const char* EncodeVibration(TriggerEffect& e, uint8_t position, uint8_t amplitude, uint8_t frequency) noexcept
{
    if (position > 9) return "position must be 0..9";
    if (amplitude > 8) return "amplitude must be 0..8";
    uint8_t a[10] = {};
    for (int i = position; i < 10; ++i) a[i] = amplitude;
    return EncodeMultiVibration(e, frequency, a);
}

// Machine gun / engine: alternates between two amplitudes.
// start 0..8, end start+1..9, amplitudeA/B 0..7, frequency 1..255 Hz, period in 1/10 s (0..255).
inline const char* EncodeMachine(TriggerEffect& e, uint8_t startPosition, uint8_t endPosition,
                                 uint8_t amplitudeA, uint8_t amplitudeB, uint8_t frequency, uint8_t period) noexcept
{
    if (startPosition > 8) return "start must be 0..8";
    if (endPosition <= startPosition || endPosition > 9) return "end must be start+1..9";
    if (amplitudeA > 7 || amplitudeB > 7) return "amplitude_a/amplitude_b must be 0..7";
    if (frequency == 0) return EncodeTriggerOff(e);
    const uint16_t zones = static_cast<uint16_t>((1u << startPosition) | (1u << endPosition));
    e = TriggerEffect{};
    e.bytes[0] = TriggerMode::Machine;
    e.bytes[1] = static_cast<uint8_t>(zones & 0xFF);
    e.bytes[2] = static_cast<uint8_t>((zones >> 8) & 0xFF);
    e.bytes[3] = static_cast<uint8_t>((amplitudeA & 0x07) | ((amplitudeB & 0x07) << 3));
    e.bytes[4] = frequency;
    e.bytes[5] = period;
    return nullptr;
}

// ---------------------------------------------------------------------------
// Output report builder
// ---------------------------------------------------------------------------

class OutputReport
{
public:
    uint8_t common[Common::Size] = {};

    OutputReport& Rumble(uint8_t leftStrong, uint8_t rightWeak, bool vibrationV2 = false) noexcept
    {
        common[Common::ValidFlag0] |= Flag0::HapticsSelect;
        if (vibrationV2) common[Common::ValidFlag2] |= Flag2::CompatibleVibration2;
        else             common[Common::ValidFlag0] |= Flag0::CompatibleVibration;
        common[Common::MotorLeft]  = leftStrong;
        common[Common::MotorRight] = rightWeak;
        return *this;
    }

    OutputReport& TriggerEffectFor(Trigger t, const TriggerEffect& e) noexcept
    {
        if (t == Trigger::Right)
        {
            common[Common::ValidFlag0] |= Flag0::RightTriggerEffect;
            memcpy(&common[Common::RightTrigger], e.bytes, TriggerEffectSize);
        }
        else
        {
            common[Common::ValidFlag0] |= Flag0::LeftTriggerEffect;
            memcpy(&common[Common::LeftTrigger], e.bytes, TriggerEffectSize);
        }
        return *this;
    }

    OutputReport& Lightbar(uint8_t r, uint8_t g, uint8_t b) noexcept
    {
        common[Common::ValidFlag1] |= Flag1::Lightbar;
        common[Common::LightbarRed]   = r;
        common[Common::LightbarGreen] = g;
        common[Common::LightbarBlue]  = b;
        return *this;
    }

    OutputReport& LightbarSetup(uint8_t setupBits) noexcept
    {
        common[Common::ValidFlag2] |= Flag2::LightbarSetup;
        common[Common::LightbarSetup] = setupBits;
        return *this;
    }

    OutputReport& PlayerLeds(uint8_t mask, bool instant = false) noexcept
    {
        common[Common::ValidFlag1] |= Flag1::PlayerLeds;
        common[Common::PlayerLeds] = static_cast<uint8_t>((mask & 0x1F) | (instant ? PlayerLedInstant : 0));
        return *this;
    }

    OutputReport& Brightness(LedBrightness level) noexcept
    {
        common[Common::ValidFlag2] |= Flag2::LedBrightness;
        common[Common::LedBrightness] = static_cast<uint8_t>(level);
        return *this;
    }

    OutputReport& MuteLight(MuteLed mode) noexcept
    {
        common[Common::ValidFlag1] |= Flag1::MicMuteLed;
        common[Common::MuteLed] = static_cast<uint8_t>(mode);
        return *this;
    }

    OutputReport& MicMute(bool muted) noexcept
    {
        common[Common::ValidFlag1] |= Flag1::PowerSave;
        if (muted) common[Common::PowerSave] |= PowerSaveBits::MicMute;
        else       common[Common::PowerSave] &= static_cast<uint8_t>(~PowerSaveBits::MicMute);
        return *this;
    }

    // Each reduction 0..7 (0 = 100%, each step ~ -12.5%).
    OutputReport& MotorPower(uint8_t triggerReduction, uint8_t rumbleReduction) noexcept
    {
        common[Common::ValidFlag1] |= Flag1::MotorPowerLevel;
        common[Common::MotorPowerLevel] = static_cast<uint8_t>((triggerReduction & 0x07) | ((rumbleReduction & 0x07) << 4));
        return *this;
    }

    OutputReport& HeadphoneVolume(uint8_t v) noexcept
    {
        common[Common::ValidFlag0] |= Flag0::HeadphoneVolume;
        common[Common::HeadphoneVolume] = v;
        return *this;
    }

    OutputReport& SpeakerVolume(uint8_t v) noexcept
    {
        common[Common::ValidFlag0] |= Flag0::SpeakerVolume;
        common[Common::SpeakerVolume] = v;
        return *this;
    }

    OutputReport& MicVolume(uint8_t v) noexcept
    {
        common[Common::ValidFlag0] |= Flag0::MicVolume;
        common[Common::MicVolume] = v;
        return *this;
    }

    OutputReport& ReleaseLeds() noexcept
    {
        common[Common::ValidFlag1] |= Flag1::ReleaseLeds;
        return *this;
    }

    // Serialize into `out` (zeroed to `size`). Returns bytes written or 0 on error.
    size_t Serialize(Transport transport, uint8_t sequence, uint8_t* out, size_t size) const noexcept
    {
        if (out == nullptr || size > MaxReportSize) return 0;
        memset(out, 0, size);
        if (transport == Transport::Usb)
        {
            if (size < UsbMinReportSize) return 0;
            out[0] = UsbOutputReportId;
            memcpy(&out[UsbCommonOffset], common, Common::Size);
            return size;
        }
        if (size < BtReportSize) return 0;
        out[0] = BtOutputReportId;
        out[1] = static_cast<uint8_t>((sequence & 0x0F) << 4);
        out[2] = BtOutputTag;
        memcpy(&out[BtCommonOffset], common, Common::Size);
        const uint32_t crc = BtCrc32(BtCrcSeedOutput, out, BtCrcOffset);
        out[BtCrcOffset + 0] = static_cast<uint8_t>(crc & 0xFF);
        out[BtCrcOffset + 1] = static_cast<uint8_t>((crc >> 8) & 0xFF);
        out[BtCrcOffset + 2] = static_cast<uint8_t>((crc >> 16) & 0xFF);
        out[BtCrcOffset + 3] = static_cast<uint8_t>((crc >> 24) & 0xFF);
        return size;
    }
};

// ---------------------------------------------------------------------------
// Input report parsing
// ---------------------------------------------------------------------------

struct TouchPoint
{
    bool     active = false;
    uint8_t  id = 0;
    uint16_t x = 0;   // 0..1919
    uint16_t y = 0;   // 0..1079
};

struct InputState
{
    bool      valid = false;
    bool      simpleMode = false;     // Bluetooth "basic" report without motion/touch/battery
    Transport transport = Transport::Usb;

    uint8_t lx = 128, ly = 128, rx = 128, ry = 128;
    uint8_t l2 = 0, r2 = 0;
    uint8_t dpad = 8;                 // 0=N,1=NE..7=NW, 8=released

    bool square = false, cross = false, circle = false, triangle = false;
    bool l1 = false, r1 = false, l2Button = false, r2Button = false;
    bool create = false, options = false, l3 = false, r3 = false;
    bool ps = false, touchpadClick = false, mute = false;
    bool edgeLeftFn = false, edgeRightFn = false, edgeLeftPaddle = false, edgeRightPaddle = false;

    int16_t  gyro[3]  = {};
    int16_t  accel[3] = {};
    uint32_t sensorTimestamp = 0;
    TouchPoint touch[2];

    uint8_t statusByte = 0;
    uint8_t batteryPercent = 0;
    uint8_t chargingState = 0;        // 0 discharging, 1 charging, 2 full, other = error
    uint8_t plugFlags = 0;            // raw byte after status (bit0 headphones — best effort)
};

namespace Detail {
    inline int16_t Le16(const uint8_t* p) noexcept { return static_cast<int16_t>(p[0] | (p[1] << 8)); }
    inline uint32_t Le32(const uint8_t* p) noexcept
    {
        return static_cast<uint32_t>(p[0]) | (static_cast<uint32_t>(p[1]) << 8) |
               (static_cast<uint32_t>(p[2]) << 16) | (static_cast<uint32_t>(p[3]) << 24);
    }
    inline void DecodeButtons(InputState& s, uint8_t b0, uint8_t b1, uint8_t b2) noexcept
    {
        s.dpad      = b0 & 0x0F;
        s.square    = (b0 & 0x10) != 0;
        s.cross     = (b0 & 0x20) != 0;
        s.circle    = (b0 & 0x40) != 0;
        s.triangle  = (b0 & 0x80) != 0;
        s.l1        = (b1 & 0x01) != 0;
        s.r1        = (b1 & 0x02) != 0;
        s.l2Button  = (b1 & 0x04) != 0;
        s.r2Button  = (b1 & 0x08) != 0;
        s.create    = (b1 & 0x10) != 0;
        s.options   = (b1 & 0x20) != 0;
        s.l3        = (b1 & 0x40) != 0;
        s.r3        = (b1 & 0x80) != 0;
        s.ps            = (b2 & 0x01) != 0;
        s.touchpadClick = (b2 & 0x02) != 0;
        s.mute          = (b2 & 0x04) != 0;
        s.edgeLeftFn      = (b2 & 0x10) != 0;
        s.edgeRightFn     = (b2 & 0x20) != 0;
        s.edgeLeftPaddle  = (b2 & 0x40) != 0;
        s.edgeRightPaddle = (b2 & 0x80) != 0;
    }
}

// `data` may or may not start with the report id; pass hasReportId accordingly.
inline InputState ParseInputReport(const uint8_t* data, size_t len, bool hasReportId, uint32_t reportIdHint = 0) noexcept
{
    InputState s;
    if (data == nullptr || len < 10) return s;

    uint32_t id = reportIdHint;
    size_t base = 0;
    if (hasReportId) { id = data[0]; base = 1; }

    if (id == 0x31)
    {
        s.transport = Transport::Bluetooth;
        base += 1;  // skip seq/tag byte
    }
    else if (id == 0x01 && hasReportId && len < 60)
    {
        // Bluetooth simple report: sticks, buttons, triggers only.
        s.transport = Transport::Bluetooth;
        s.simpleMode = true;
        const uint8_t* p = data + base;
        if (len - base < 9) return s;
        s.lx = p[0]; s.ly = p[1]; s.rx = p[2]; s.ry = p[3];
        Detail::DecodeButtons(s, p[4], p[5], p[6]);
        s.l2 = p[7]; s.r2 = p[8];
        s.valid = true;
        return s;
    }

    const uint8_t* p = data + base;
    if (len < base + 54) return s;

    s.lx = p[0]; s.ly = p[1]; s.rx = p[2]; s.ry = p[3];
    s.l2 = p[4]; s.r2 = p[5];
    Detail::DecodeButtons(s, p[7], p[8], p[9]);
    for (int i = 0; i < 3; ++i)
    {
        s.gyro[i]  = Detail::Le16(&p[15 + i * 2]);
        s.accel[i] = Detail::Le16(&p[21 + i * 2]);
    }
    s.sensorTimestamp = Detail::Le32(&p[27]);
    for (int i = 0; i < 2; ++i)
    {
        const uint8_t* t = &p[32 + i * 4];
        s.touch[i].active = (t[0] & 0x80) == 0;
        s.touch[i].id     = t[0] & 0x7F;
        s.touch[i].x      = static_cast<uint16_t>(t[1] | ((t[2] & 0x0F) << 8));
        s.touch[i].y      = static_cast<uint16_t>(((t[2] & 0xF0) >> 4) | (t[3] << 4));
    }
    s.statusByte = p[52];
    const uint8_t level = s.statusByte & 0x0F;
    s.chargingState = (s.statusByte & 0xF0) >> 4;
    if (s.chargingState == 2) s.batteryPercent = 100;
    else
    {
        const unsigned pct = level * 10u + 5u;
        s.batteryPercent = static_cast<uint8_t>(pct > 100 ? 100 : pct);
    }
    if (len > base + 53) s.plugFlags = p[53];
    s.valid = true;
    return s;
}

inline const char* DpadName(uint8_t d) noexcept
{
    static const char* names[] = { "up", "up_right", "right", "down_right", "down", "down_left", "left", "up_left" };
    return d < 8 ? names[d] : "none";
}

inline const char* ChargingName(uint8_t c) noexcept
{
    switch (c)
    {
    case 0x0: return "discharging";
    case 0x1: return "charging";
    case 0x2: return "full";
    case 0xA: return "voltage_or_temperature_out_of_range";
    case 0xB: return "temperature_error";
    case 0xF: return "charging_error";
    default:  return "unknown";
    }
}

} // namespace DS5
