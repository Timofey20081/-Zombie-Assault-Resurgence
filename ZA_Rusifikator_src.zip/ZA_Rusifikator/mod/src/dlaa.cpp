// ZAPad DLAA: NVIDIA DLSS (DLAA mode) in place of URP's TAA resolve.
//
// How it works:
//  * InitializeAdditionalCameraData: the game camera is switched to URP temporal AA for the frame, so URP jitters the
//    projection, renders motion vectors and records its TAA pass. MSAA is dropped (TAA needs it off).
//  * TemporalAA.<Render>b__16_0 (the TAA resolve render function): instead of the TAA shader we queue a native
//    plugin event with the colour, depth, motion vector and destination textures.
//  * The plugin event runs on Unity's render thread: our own D3D12 command list evaluates DLSS into a UAV texture and
//    copies it into the destination; Unity's IUnityGraphicsD3D12v7::ExecuteCommandList handles the resource states.
// Unity's native plugin interfaces come from the game's own plugin_helper.dll (NK_GetUnityInterfaces).
#define NOMINMAX
#include "dlaa.h"
#include <d3d12.h>
#include <dxgi.h>
#include <algorithm>
#include <atomic>
#include <mutex>
#include <vector>
#include <cmath>
#include "Unity/IUnityInterface.h"
#include "Unity/IUnityGraphics.h"
#include "Unity/IUnityGraphicsD3D12.h"
#include "ngx/nvsdk_ngx.h"
#include "ngx/nvsdk_ngx_helpers.h"
#include "ngx/nvsdk_ngx_helpers_d3d.h"

namespace DLAA {
static LogFn L = nullptr;
static Cfg C;
static std::wstring g_dir;
static uintptr_t g_ga = 0;

// ---- managed side
static void* (*g_nativePtr)(void*) = nullptr;           // Texture.GetNativeTexturePtr_Injected(IntPtr)
static void* (*g_nativeDepth)(void*) = nullptr;         // RenderTexture.GetNativeDepthBufferPtr_Injected(IntPtr)
static void (*g_issue)(void*, void*, int, void*) = nullptr;   // CommandBuffer.IssuePluginEventAndDataInternal_Injected
static const MethodInfo* g_toRT = nullptr;              // TextureHandle -> RTHandle
using ToRT_t = uint8_t* (*)(const void*, const MethodInfo*);

// ---- native side
static IUnityInterfaces* g_ui = nullptr;
static IUnityGraphicsD3D12v7* g_gfx = nullptr;
static std::atomic<bool> g_ok{false}, g_failed{false}, g_initQueued{false}, g_reset{true};
static constexpr int EV_INIT = 0x5A44C001, EV_EVAL = 0x5A44C002;

struct Frame { ID3D12Resource *color, *depth, *mv, *dst; bool depthIsDS; float jx, jy; };
static Frame g_frames[16]; static std::atomic<unsigned> g_fi{0};
static std::atomic<float> g_jx{0}, g_jy{0};

static ID3D12Device* g_dev = nullptr;
static NVSDK_NGX_Parameter* g_params = nullptr;
static NVSDK_NGX_Handle* g_feat = nullptr;
static UINT g_fw = 0, g_fh = 0; static DXGI_FORMAT g_ffmt = DXGI_FORMAT_UNKNOWN;
static ID3D12Resource* g_out = nullptr;
static const int RING = 6;
static ID3D12CommandAllocator* g_alloc[RING] = {};
static UINT64 g_fence[RING] = {};
static ID3D12GraphicsCommandList* g_list = nullptr;
static int g_ri = 0; static LARGE_INTEGER g_lastEval{};
static int g_evals = 0;
static ID3D12Fence* g_myFence = nullptr; static UINT64 g_myVal = 0;
struct Dead { NVSDK_NGX_Handle* feat; ID3D12Resource* tex; UINT64 fence; };
static std::vector<Dead> g_dead;

static void NVSDK_CONV NgxLog(const char* msg, NVSDK_NGX_Logging_Level, NVSDK_NGX_Feature) {
    if (!L) return;
    std::string s(msg); while (!s.empty() && (s.back() == '\n' || s.back() == '\r')) s.pop_back();
    if (s.find("error") != s.npos || s.find("Error") != s.npos || s.find("fail") != s.npos || s.find("warn") != s.npos) L("ngx: %s", s.c_str());
}

static void Fail(const char* what, long long code = 0) { if (L) L("dlaa: %s (0x%llx), DLAA off", what, code); g_ok = false; g_failed = true; }

static bool WaitFence(UINT64 v) {
    ID3D12Fence* f = g_gfx->GetFrameFence();
    if (!f || f->GetCompletedValue() >= v) return true;
    HANDLE e = CreateEventW(nullptr, FALSE, FALSE, nullptr);
    f->SetEventOnCompletion(v, e); DWORD r = WaitForSingleObject(e, 500); CloseHandle(e);
    return r == WAIT_OBJECT_0;
}

static void InitNative() {     // render thread
    g_dev = g_gfx->GetDevice();
    if (!g_dev) { Fail("no D3D12 device"); return; }
    const wchar_t* paths[1] = {g_dir.c_str()};
    NVSDK_NGX_FeatureCommonInfo fi{}; fi.PathListInfo.Path = paths; fi.PathListInfo.Length = 1;
    fi.LoggingInfo.LoggingCallback = NgxLog; fi.LoggingInfo.MinimumLoggingLevel = NVSDK_NGX_LOGGING_LEVEL_ON; fi.LoggingInfo.DisableOtherLoggingSinks = true;
    NVSDK_NGX_Result r = NVSDK_NGX_D3D12_Init_with_ProjectID("5a4d3c2b-7e61-4f0a-9b1c-2d3e4f506172", NVSDK_NGX_ENGINE_TYPE_CUSTOM, "1.0", g_dir.c_str(), g_dev, &fi);
    if (NVSDK_NGX_FAILED(r)) { Fail("NGX init failed (NVIDIA RTX card and a recent driver are needed)", r); return; }
    if (NVSDK_NGX_FAILED(NVSDK_NGX_D3D12_GetCapabilityParameters(&g_params)) || !g_params) { Fail("NGX parameters"); return; }
    int avail = 0, needDrv = 0; unsigned drvMaj = 0, drvMin = 0;
    NVSDK_NGX_Parameter_GetI(g_params, NVSDK_NGX_Parameter_SuperSampling_Available, &avail);
    NVSDK_NGX_Parameter_GetI(g_params, NVSDK_NGX_Parameter_SuperSampling_NeedsUpdatedDriver, &needDrv);
    NVSDK_NGX_Parameter_GetUI(g_params, NVSDK_NGX_Parameter_SuperSampling_MinDriverVersionMajor, &drvMaj);
    NVSDK_NGX_Parameter_GetUI(g_params, NVSDK_NGX_Parameter_SuperSampling_MinDriverVersionMinor, &drvMin);
    if (!avail) { if (needDrv) { if (L) L("dlaa: driver %u.%u or newer is needed", drvMaj, drvMin); } Fail("DLSS not available on this GPU"); return; }
    for (int i = 0; i < RING; ++i)
        if (FAILED(g_dev->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, IID_PPV_ARGS(&g_alloc[i])))) { Fail("command allocator"); return; }
    if (FAILED(g_dev->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, g_alloc[0], nullptr, IID_PPV_ARGS(&g_list)))) { Fail("command list"); return; }
    g_list->Close();
    if (L) L("dlaa: NGX ready, DLSS available, preset %c", 'A' + C.preset - 1);
    g_ok = true;
}

static bool IsHdrFormat(DXGI_FORMAT f) {
    return f == DXGI_FORMAT_R16G16B16A16_FLOAT || f == DXGI_FORMAT_R11G11B10_FLOAT || f == DXGI_FORMAT_R32G32B32A32_FLOAT || f == DXGI_FORMAT_R16G16B16A16_TYPELESS || f == DXGI_FORMAT_R9G9B9E5_SHAREDEXP;
}
static bool g_hdr = false;
static bool EnsureFeature(ID3D12GraphicsCommandList* cl, UINT w, UINT h, DXGI_FORMAT fmt, const D3D12_RESOURCE_DESC& dd, DXGI_FORMAT colorFmt) {
    if (g_feat && w == g_fw && h == g_fh && fmt == g_ffmt) return true;
    if (g_feat || g_out) g_dead.push_back({g_feat, g_out, g_myVal + 1});   // may still be in flight: released later
    g_feat = nullptr; g_out = nullptr;
    D3D12_RESOURCE_DESC od = dd; od.Flags = D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS;
    if (od.Format == DXGI_FORMAT_R8G8B8A8_UNORM_SRGB || od.Format == DXGI_FORMAT_R8G8B8A8_TYPELESS) od.Format = DXGI_FORMAT_R8G8B8A8_UNORM;   // UAVs can't be sRGB; same copy family
    if (od.Format == DXGI_FORMAT_B8G8R8A8_UNORM_SRGB || od.Format == DXGI_FORMAT_B8G8R8A8_TYPELESS) od.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
    if (od.Format == DXGI_FORMAT_R16G16B16A16_TYPELESS) od.Format = DXGI_FORMAT_R16G16B16A16_FLOAT; od.MipLevels = 1; od.SampleDesc = {1, 0}; od.Alignment = 0;
    D3D12_HEAP_PROPERTIES hp{}; hp.Type = D3D12_HEAP_TYPE_DEFAULT;
    HRESULT hr = g_dev->CreateCommittedResource(&hp, D3D12_HEAP_FLAG_NONE, &od, D3D12_RESOURCE_STATE_UNORDERED_ACCESS, nullptr, IID_PPV_ARGS(&g_out));
    if (FAILED(hr)) { Fail("output texture", hr); return false; }
    NVSDK_NGX_DLSS_Create_Params cp{};
    cp.Feature.InWidth = w; cp.Feature.InHeight = h; cp.Feature.InTargetWidth = w; cp.Feature.InTargetHeight = h;
    cp.Feature.InPerfQualityValue = NVSDK_NGX_PerfQuality_Value_DLAA;
    g_hdr = IsHdrFormat(colorFmt);
    cp.InFeatureCreateFlags = (g_hdr ? NVSDK_NGX_DLSS_Feature_Flags_IsHDR : 0) | NVSDK_NGX_DLSS_Feature_Flags_MVLowRes | NVSDK_NGX_DLSS_Feature_Flags_DepthInverted |
                              (C.autoExposure && g_hdr ? NVSDK_NGX_DLSS_Feature_Flags_AutoExposure : 0);
    for (const char* k : {NVSDK_NGX_Parameter_DLSS_Hint_Render_Preset_DLAA, NVSDK_NGX_Parameter_DLSS_Hint_Render_Preset_Quality, NVSDK_NGX_Parameter_DLSS_Hint_Render_Preset_Balanced,
                          NVSDK_NGX_Parameter_DLSS_Hint_Render_Preset_Performance, NVSDK_NGX_Parameter_DLSS_Hint_Render_Preset_UltraPerformance, NVSDK_NGX_Parameter_DLSS_Hint_Render_Preset_UltraQuality})
        NVSDK_NGX_Parameter_SetUI(g_params, k, (unsigned)C.preset);
    NVSDK_NGX_Result r = NGX_D3D12_CREATE_DLSS_EXT(cl, 1, 1, &g_feat, g_params, &cp);
    if (NVSDK_NGX_FAILED(r)) { Fail("DLSS feature create failed", r); return false; }
    g_fw = w; g_fh = h; g_ffmt = fmt; g_reset = true;
    if (L) L("dlaa: DLAA %ux%u, output format %d, colour format %d (%s)", w, h, (int)fmt, (int)colorFmt, g_hdr ? "HDR" : "LDR");
    return true;
}

static void Barrier(ID3D12GraphicsCommandList* cl, ID3D12Resource* r, D3D12_RESOURCE_STATES a, D3D12_RESOURCE_STATES b) {
    D3D12_RESOURCE_BARRIER br{}; br.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION; br.Transition.pResource = r;
    br.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES; br.Transition.StateBefore = a; br.Transition.StateAfter = b;
    cl->ResourceBarrier(1, &br);
}

static void ReleaseDead() {
    ID3D12Fence* f = g_gfx->GetFrameFence(); UINT64 done = f ? f->GetCompletedValue() : 0;
    for (size_t i = 0; i < g_dead.size();)
        if (g_dead[i].fence <= done) { if (g_dead[i].feat) NVSDK_NGX_D3D12_ReleaseFeature(g_dead[i].feat); if (g_dead[i].tex) g_dead[i].tex->Release(); g_dead.erase(g_dead.begin() + i); }
        else ++i;
}

// Unity flushes its own command lists before this event (FlushCommandBuffers), URP's TAA draw has just run (inputs in
// PIXEL_SHADER_RESOURCE, destination in RENDER_TARGET), and our list goes straight onto Unity's graphics queue after it.
static void Eval(const Frame& f) {    // render thread
    if (!g_ok || !f.color || !f.dst || !f.mv || !f.depth) return;
    ID3D12CommandQueue* q = g_gfx->GetCommandQueue();
    if (!q) { Fail("no graphics queue"); return; }
    if (!g_myFence && FAILED(g_dev->CreateFence(0, D3D12_FENCE_FLAG_NONE, IID_PPV_ARGS(&g_myFence)))) { Fail("fence"); return; }
    for (size_t k = 0; k < g_dead.size();) {   // old features/textures, once the GPU is past them
        if (g_dead[k].fence <= g_myFence->GetCompletedValue()) { if (g_dead[k].feat) NVSDK_NGX_D3D12_ReleaseFeature(g_dead[k].feat); if (g_dead[k].tex) g_dead[k].tex->Release(); g_dead.erase(g_dead.begin() + k); } else ++k;
    }
    D3D12_RESOURCE_DESC cd = f.color->GetDesc(), dd = f.dst->GetDesc();
    UINT w = (UINT)dd.Width, h = dd.Height;
    int i = g_ri; g_ri = (g_ri + 1) % RING;
    if (g_myFence->GetCompletedValue() < g_fence[i]) {
        HANDLE e = CreateEventW(nullptr, FALSE, FALSE, nullptr); g_myFence->SetEventOnCompletion(g_fence[i], e); WaitForSingleObject(e, 500); CloseHandle(e);
    }
    g_alloc[i]->Reset(); g_list->Reset(g_alloc[i], nullptr);
    ID3D12GraphicsCommandList* cl = g_list;
    if (!EnsureFeature(cl, w, h, dd.Format, dd, cd.Format)) { cl->Close(); return; }
    LARGE_INTEGER now, fq; QueryPerformanceCounter(&now); QueryPerformanceFrequency(&fq);
    float dtms = g_lastEval.QuadPart ? (float)((now.QuadPart - g_lastEval.QuadPart) * 1000.0 / fq.QuadPart) : 16.6f; g_lastEval = now;
    const D3D12_RESOURCE_STATES ps = D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE, all = ps | D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE;
    const D3D12_RESOURCE_STATES dps = f.depthIsDS ? (ps | D3D12_RESOURCE_STATE_DEPTH_READ) : ps, dall = f.depthIsDS ? (all | D3D12_RESOURCE_STATE_DEPTH_READ) : all;
    Barrier(cl, f.color, ps, all); Barrier(cl, f.mv, ps, all); Barrier(cl, f.depth, dps, dall);
    NVSDK_NGX_D3D12_DLSS_Eval_Params ep{};
    ep.Feature.pInColor = f.color; ep.Feature.pInOutput = g_out;
    ep.pInDepth = f.depth; ep.pInMotionVectors = f.mv;
    ep.InJitterOffsetX = f.jx * C.jitterX; ep.InJitterOffsetY = f.jy * C.jitterY;
    ep.InRenderSubrectDimensions = {(unsigned)std::min<UINT64>(cd.Width, w), std::min(cd.Height, h)};
    ep.InReset = g_reset.exchange(false) ? 1 : 0;
    ep.InMVScaleX = C.mvX * (float)w; ep.InMVScaleY = C.mvY * (float)h;
    ep.InPreExposure = 1.f; ep.InExposureScale = 1.f; ep.InFrameTimeDeltaInMsec = dtms;
    NVSDK_NGX_Result r = NGX_D3D12_EVALUATE_DLSS_EXT(cl, g_feat, g_params, &ep);
    Barrier(cl, f.color, all, ps); Barrier(cl, f.mv, all, ps); Barrier(cl, f.depth, dall, dps);
    if (NVSDK_NGX_FAILED(r)) { cl->Close(); Fail("DLSS evaluate failed", r); return; }
    Barrier(cl, g_out, D3D12_RESOURCE_STATE_UNORDERED_ACCESS, D3D12_RESOURCE_STATE_COPY_SOURCE);
    Barrier(cl, f.dst, D3D12_RESOURCE_STATE_RENDER_TARGET, D3D12_RESOURCE_STATE_COPY_DEST);
    if (C.split) {
        D3D12_TEXTURE_COPY_LOCATION d{}, sl{}; d.pResource = f.dst; d.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX; sl.pResource = g_out; sl.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
        UINT dy = C.split == 2 ? 40 : 0;
        D3D12_BOX box{0, 0, 0, C.split == 2 ? w : w / 2, h - dy, 1}; cl->CopyTextureRegion(&d, 0, dy, 0, &sl, &box);
    } else cl->CopyResource(f.dst, g_out);
    Barrier(cl, f.dst, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_RENDER_TARGET);
    Barrier(cl, g_out, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
    if (FAILED(cl->Close())) { Fail("command list close"); return; }
    ID3D12CommandList* lists[1] = {cl};
    q->ExecuteCommandLists(1, lists);
    q->Signal(g_myFence, ++g_myVal); g_fence[i] = g_myVal;
    if (++g_evals <= 4 && L) L("dlaa: frame %d (jitter %.3f %.3f) dst %p color %p", g_evals, f.jx, f.jy, f.dst, f.color);
}

static void UNITY_INTERFACE_API OnEvent(int id, void* data) {
    __try {
        if (id == EV_INIT) { if (!g_ok && !g_failed) InitNative(); }
        else if (id == EV_EVAL && data) Eval(*(Frame*)data);
    } __except (EXCEPTION_EXECUTE_HANDLER) { g_ok = false; g_failed = true; }
}

// ---- main thread hooks
static void* NativeOf(const void* handle, bool* isDepth) {
    *isDepth = false;
    uint8_t* rth = ((ToRT_t)MethodPtr(g_toRT))(handle, g_toRT);
    if (!rth) return nullptr;
    uint8_t* tex = *(uint8_t**)(rth + 0x18); if (!tex) tex = *(uint8_t**)(rth + 0x20);
    if (!tex) return nullptr;
    void* native = *(void**)(tex + 0x10);   // UnityEngine.Object.m_CachedPtr
    if (!native) return nullptr;
    void* p = g_nativePtr(native);
    if (!p && g_nativeDepth) { p = g_nativeDepth(native); *isDepth = p != nullptr; }
    return p;
}

static const MethodInfo* g_jitMat = nullptr; static FieldInfo* g_jitFuncF = nullptr;
using JitMat_t = void* (*)(float* ret, void* cd, void* jf, const MethodInfo*);
using InitAdd_t = void (*)(void*, uint8_t*, bool, bool, uint8_t*, const MethodInfo*);
static InitAdd_t o_InitAdd;
static int g_iaLog = 0; static std::vector<void*> g_seenCams;
static std::string ObjName(void* o) {
    if (!o) return "?";
    Il2CppClass* k = il2cpp_object_get_class((Il2CppObject*)o);
    const MethodInfo* m = k ? il2cpp_class_get_method_from_name(k, "get_name", 0) : nullptr;
    if (!m) return "?";
    Il2CppObject* exc = nullptr; Il2CppObject* s = il2cpp_runtime_invoke(m, o, nullptr, &exc);
    if (!s || exc) return "?";
    int n = *(int*)((uint8_t*)s + 0x10); const wchar_t* w = (const wchar_t*)((uint8_t*)s + 0x14);
    std::string r; for (int i = 0; i < n && i < 60; ++i) r += (char)(w[i] < 128 ? w[i] : '?'); return r;
}
static std::atomic<bool> g_off{false};
static void PollHotkey() {   // Ctrl+F12: DLAA on/off on the fly (the game's own anti-aliasing when off)
    static bool was = false;
    bool down = (GetAsyncKeyState(VK_CONTROL) & 0x8000) && (GetAsyncKeyState(VK_F12) & 0x8000);
    if (down && !was) { g_off = !g_off; g_reset = true; if (L) L("dlaa: %s (Ctrl+F12)", g_off ? "off" : "on"); }
    was = down;
}
static void h_InitAdd(void* cam, uint8_t* add, bool rf, bool last, uint8_t* cd, const MethodInfo* mi) {
    PollHotkey();
    if (g_off) { o_InitAdd(cam, add, rf, last, cd, mi); return; }
    if (L && cam && g_seenCams.size() < 16 && std::find(g_seenCams.begin(), g_seenCams.end(), cam) == g_seenCams.end()) {
        g_seenCams.push_back(cam);
        L("dlaa: camera '%s' renderType %d post %d aa %d target %p", ObjName(cam).c_str(), add ? *(int*)(add + 0x2c) : -1, add ? (int)*(bool*)(add + 0x4c) : -1, add ? *(int*)(add + 0x50) : -1, cd ? *(void**)(cd + 0xf0) : nullptr);
    }
    if (g_failed || !add || !cd || *(int*)(add + 0x2c) != 0 /*Base*/ || !*(bool*)(add + 0x4c) /*post-processing*/) {
        static ULONGLONG t0 = 0; ULONGLONG t = GetTickCount64();
        static int nsk = 0; if (L && add && t - t0 > 5000 && nsk++ < 3) { t0 = t; L("dlaa: skipped camera '%s' (renderType %d, post %d)", ObjName(cam).c_str(), *(int*)(add + 0x2c), (int)*(bool*)(add + 0x4c)); }
        o_InitAdd(cam, add, rf, last, cd, mi); return;
    }
    int saved = *(int*)(add + 0x50);
    *(int*)(add + 0x50) = 3;                  // AntialiasingMode.TemporalAntiAliasing
    o_InitAdd(cam, add, rf, last, cd, mi);
    *(int*)(add + 0x50) = saved;              // keep the game's own setting untouched
    if (*(void**)(cd + 0xf0) || *(int*)(cd + 0x188) != 1) {
        static ULONGLONG t1 = 0; ULONGLONG t = GetTickCount64();
        static int nsk2 = 0; if (L && t - t1 > 5000 && nsk2++ < 3) { t1 = t; L("dlaa: skipped camera '%s' (target %p, type %d)", ObjName(cam).c_str(), *(void**)(cd + 0xf0), *(int*)(cd + 0x188)); }
        *(int*)(cd + 0x1cc) = saved; return;
    }   // render-texture or non-game camera
    *(int*)(cd + 0x1cc) = 3;                  // UniversalCameraData.antialiasing = TAA
    { static ULONGLONG t0 = 0; ULONGLONG t = GetTickCount64(); static int nset = 0; if (L && t - t0 > 5000 && nset++ < 3) { t0 = t; L("dlaa: TAA set on '%s' (%dx%d, renderScale %.2f, upscale %d)", ObjName(cam).c_str(), *(int*)(cd + 0x160), *(int*)(cd + 0x164), *(float*)(cd + 0x16c), *(int*)(cd + 0x174)); } }
    *(int*)(cd + 0x100) = 1;                  // cameraTargetDescriptor.msaaSamples: TAA needs MSAA off
    *(float*)(cd + 0x218) = 1.f;              // taaSettings.jitterScale
    *(float*)(cd + 0x21c) = C.mipBias;        // taaSettings.mipBias
    if (g_jitMat && g_jitFuncF) {             // URP computed the jitter while TAA was still off: redo it
        void* jf = nullptr; il2cpp_field_static_get_value(g_jitFuncF, &jf);
        if (jf) { float m[16]; ((JitMat_t)MethodPtr(g_jitMat))(m, cd, jf, g_jitMat); memcpy(cd + 0x90, m, sizeof m); }   // UniversalCameraData.m_JitterMatrix
    }
}

// URP refuses TAA on a camera with overlay cameras stacked on it (the game's hub/mission camera has them)
using TaaOn_t = bool (*)(uint8_t*, const MethodInfo*);
static TaaOn_t o_TaaOn;
static bool h_TaaOn(uint8_t* cd, const MethodInfo* mi) {
    if (o_TaaOn(cd, mi)) return true;
    if (g_failed || !cd) return false;
    return *(int*)(cd + 0x1cc) == 3 && *(void**)(cd + 0x200) && *(int*)(cd + 0x100) <= 1 && !*(void**)(cd + 0xf0) && *(int*)(cd + 0xe8) == 0 /*Base*/;
}
using Jit_t = void (*)(int, float*, bool*, const MethodInfo*);
static Jit_t o_Jit;
static void h_Jit(int frame, float* j, bool* allow, const MethodInfo* mi) { o_Jit(frame, j, allow, mi); g_jx = j[0]; g_jy = j[1]; }

using Taa_t = void (*)(void*, uint8_t*, void**, const MethodInfo*);
static Taa_t o_Taa;
static int g_skipLog = 0;
static int g_taaCalls = 0; static double g_taaT0 = 0;
static void h_Taa(void* self, uint8_t* data, void** ctx, const MethodInfo* mi) {
    ++g_taaCalls;
    if (g_taaCalls == 1 && L) L("dlaa: TAA pass reached");
    { static ULONGLONG t0 = 0; static int c0 = 0; ULONGLONG t = GetTickCount64();
      if (t - t0 > 5000) { if (L && t0 && g_taaCalls < 20000) L("dlaa: %d TAA passes in 5 s, evals %d, ok %d", g_taaCalls - c0, g_evals, (int)g_ok.load()); t0 = t; c0 = g_taaCalls; } }
    if (g_failed || g_off || !g_issue) { o_Taa(self, data, ctx, mi); return; }
    uint8_t* rcmd = ctx ? (uint8_t*)ctx[1] : nullptr;
    uint8_t* cb = rcmd ? *(uint8_t**)(rcmd + 0x10) : nullptr;
    void* cbNative = cb ? *(void**)(cb + 0x10) : nullptr;
    if (!cbNative) { o_Taa(self, data, ctx, mi); return; }
    if (!g_initQueued.exchange(true)) g_issue(cbNative, (void*)OnEvent, EV_INIT, nullptr);
    if (!g_ok) { o_Taa(self, data, ctx, mi); return; }
    Frame& f = g_frames[g_fi++ % 16];
    bool d0, d1, d2, dd;
    f.dst = (ID3D12Resource*)NativeOf(data + 0x10, &d0);
    f.color = (ID3D12Resource*)NativeOf(data + 0x20, &d1);
    f.depth = (ID3D12Resource*)NativeOf(data + 0x30, &dd);
    f.mv = (ID3D12Resource*)NativeOf(data + 0x40, &d2);
    f.depthIsDS = dd; f.jx = g_jx; f.jy = g_jy;
    if (!f.dst || !f.color || !f.depth || !f.mv) {
        if (g_skipLog++ < 3 && L) L("dlaa: missing texture (dst %p color %p depth %p mv %p), TAA used", f.dst, f.color, f.depth, f.mv);
        o_Taa(self, data, ctx, mi); return;
    }
    o_Taa(self, data, ctx, mi);   // URP's TAA draw first: known resource states; DLAA overwrites its result
    g_issue(cbNative, (void*)OnEvent, EV_EVAL, &f);
}

using TaaRender_t = void (*)(void*, void*, uint8_t*, void*, void*, void*, void*, const MethodInfo*);
static TaaRender_t o_TaaRender; static int g_trLog = 0;
static void h_TaaRender(void* rg, void* mat, uint8_t* cd, void* c, void* d, void* m, void* dst, const MethodInfo* mi) {
    o_TaaRender(rg, mat, cd, c, d, m, dst, mi);
}
// URP refuses TAA on a camera that has an overlay camera stack (the game's world camera does); DLAA is fine with it
using TaaEn_t = bool (*)(uint8_t*, const MethodInfo*);
static TaaEn_t o_TaaEn;
static bool h_TaaEn(uint8_t* cd, const MethodInfo* mi) {
    if (o_TaaEn(cd, mi)) return true;
    if (g_failed || g_off || !cd) return false;
    return *(int*)(cd + 0x1cc) == 3 && *(void**)(cd + 0x200) && *(int*)(cd + 0x100) == 1;
}
void ResetHistory() { g_reset = true; }

static Il2CppClass* Find(Il2CppDomain* d, const char* ns, const char* name) {
    size_t n = 0; auto as = il2cpp_domain_get_assemblies(d, &n);
    for (size_t i = 0; i < n; ++i) if (Il2CppClass* k = il2cpp_class_from_name(il2cpp_assembly_get_image(as[i]), ns, name)) return k;
    return nullptr;
}

bool Install(Il2CppDomain* dom, uintptr_t ga, HookFn hook, LogFn log, const std::wstring& dir, const Cfg& cfg) {
    L = log; C = cfg; g_dir = dir; g_ga = ga;
    if (GetFileAttributesW((dir + L"\\nvngx_dlss.dll").c_str()) == INVALID_FILE_ATTRIBUTES) { L("dlaa: nvngx_dlss.dll missing"); return false; }
    HMODULE ph = GetModuleHandleW(L"plugin_helper.dll");
    auto getUi = ph ? (IUnityInterfaces * (*)())GetProcAddress(ph, "NK_GetUnityInterfaces") : nullptr;
    g_ui = getUi ? getUi() : nullptr;
    if (!g_ui) { L("dlaa: Unity plugin interfaces not found"); return false; }
    IUnityGraphics* g = g_ui->Get<IUnityGraphics>();
    if (!g || g->GetRenderer() != kUnityGfxRendererD3D12) { L("dlaa: the game is not running on D3D12 (renderer %d)", g ? (int)g->GetRenderer() : -1); return false; }
    g_gfx = g_ui->Get<IUnityGraphicsD3D12v7>();
    if (!g_gfx) { L("dlaa: IUnityGraphicsD3D12v7 missing"); return false; }
    UnityD3D12PluginEventConfig ec{};
    ec.graphicsQueueAccess = kUnityD3D12GraphicsQueueAccess_Allow;
    ec.flags = kUnityD3D12EventConfigFlag_FlushCommandBuffers | kUnityD3D12EventConfigFlag_SyncWorkerThreads | kUnityD3D12EventConfigFlag_ModifiesCommandBuffersState;
    ec.ensureActiveRenderTextureIsBound = false;
    g_gfx->ConfigureEvent(EV_EVAL, &ec); g_gfx->ConfigureEvent(EV_INIT, &ec);

    g_nativePtr = (void* (*)(void*))il2cpp_resolve_icall("UnityEngine.Texture::GetNativeTexturePtr_Injected");
    g_nativeDepth = (void* (*)(void*))il2cpp_resolve_icall("UnityEngine.RenderTexture::GetNativeDepthBufferPtr_Injected");
    g_issue = (void (*)(void*, void*, int, void*))il2cpp_resolve_icall("UnityEngine.Rendering.CommandBuffer::IssuePluginEventAndDataInternal_Injected");
    if (!g_nativePtr || !g_issue) { L("dlaa: engine calls not found"); return false; }

    Il2CppClass* th = Find(dom, "UnityEngine.Rendering.RenderGraphModule", "TextureHandle");
    if (th) { void* it = nullptr; const MethodInfo* m;
        while ((m = il2cpp_class_get_methods(th, &it))) if (!strcmp(il2cpp_method_get_name(m), "op_Implicit")) {
            char* rn = il2cpp_type_get_name(il2cpp_method_get_return_type(m));
            if (rn && !strcmp(rn, "UnityEngine.Rendering.RTHandle")) g_toRT = m;
            if (rn) il2cpp_free(rn);
        } }
    Il2CppClass* taa = Find(dom, "UnityEngine.Rendering.Universal", "TemporalAA");
    Il2CppClass* urp = Find(dom, "UnityEngine.Rendering.Universal", "UniversalRenderPipeline");
    Il2CppClass* lam = nullptr;
    if (taa && il2cpp_class_get_nested_types) { void* it = nullptr; Il2CppClass* n; while ((n = il2cpp_class_get_nested_types(taa, &it))) if (!strcmp(il2cpp_class_get_name(n), "<>c")) lam = n; }
    if (!g_toRT || !taa || !urp || !lam) { L("dlaa: render pipeline classes not found"); return false; }
    g_jitMat = il2cpp_class_get_method_from_name(taa, "CalculateJitterMatrix", 2);
    g_jitFuncF = il2cpp_class_get_field_from_name(taa, "s_JitterFunc");
    if (!g_jitMat || !g_jitFuncF) L("dlaa: jitter matrix method not found");
    bool ok = hook(il2cpp_class_get_method_from_name(lam, "<Render>b__16_0", 2), (void*)h_Taa, (void**)&o_Taa, "TemporalAA resolve (DLAA)")
           && hook(il2cpp_class_get_method_from_name(taa, "CalculateJitter", 3), (void*)h_Jit, (void**)&o_Jit, "TemporalAA.CalculateJitter")
           && hook(il2cpp_class_get_method_from_name(urp, "InitializeAdditionalCameraData", 5), (void*)h_InitAdd, (void**)&o_InitAdd, "URP.InitializeAdditionalCameraData");
    Il2CppClass* ucd = Find(dom, "UnityEngine.Rendering.Universal", "UniversalCameraData");
    if (ok && ucd) hook(il2cpp_class_get_method_from_name(ucd, "IsTemporalAAEnabled", 0), (void*)h_TaaOn, (void**)&o_TaaOn, "UniversalCameraData.IsTemporalAAEnabled");
    if (ok) { Il2CppClass* ucd = Find(dom, "UnityEngine.Rendering.Universal", "UniversalCameraData");
              if (ucd) hook(il2cpp_class_get_method_from_name(ucd, "IsTemporalAAEnabled", 0), (void*)h_TaaEn, (void**)&o_TaaEn, "UniversalCameraData.IsTemporalAAEnabled"); }
    if (ok) hook(il2cpp_class_get_method_from_name(taa, "Render", 7), (void*)h_TaaRender, (void**)&o_TaaRender, "TemporalAA.Render");
    if (ok) L("dlaa: installed, preset %c, mip bias %.2f", 'A' + C.preset - 1, C.mipBias);
    return ok;
}
}
