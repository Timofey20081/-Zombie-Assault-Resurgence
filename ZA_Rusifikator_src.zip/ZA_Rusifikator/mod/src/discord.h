// ZAPad Discord Rich Presence over the local Discord IPC pipe (no SDK needed).
#pragma once
#include <windows.h>
#include <string>
#include <mutex>
#include <atomic>
#include <cstdint>
#include <ctime>

namespace DRP {
inline double Now_() { static LARGE_INTEGER f = [] { LARGE_INTEGER x; QueryPerformanceFrequency(&x); return x; }(); LARGE_INTEGER c; QueryPerformanceCounter(&c); return (double)c.QuadPart / f.QuadPart; }
struct Info {
    std::wstring hero, cls, scene;   // scene = lowercase Unity scene name
    int level = 0;
    bool menu = true;
};
inline std::mutex g_mx; inline Info g_info; inline std::atomic<bool> g_dirty{true};
inline std::string g_clientId; inline std::atomic<double> g_lastSeen{0}; inline void (*g_log)(const char*, ...) = nullptr;

inline void Set(const Info& i) {
    std::lock_guard<std::mutex> lk(g_mx);
    if (i.hero != g_info.hero || i.cls != g_info.cls || i.scene != g_info.scene || i.level != g_info.level || i.menu != g_info.menu) { g_info = i; g_dirty = true; }
}
inline std::string U8(const std::wstring& w) {
    if (w.empty()) return {};
    int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), nullptr, 0, 0, 0);
    std::string s(n, 0); WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), s.data(), n, 0, 0); return s;
}
inline std::string Esc(const std::string& s) {
    std::string o; for (char c : s) { if (c == '"' || c == '\\') { o += '\\'; o += c; } else if ((unsigned char)c < 0x20) o += ' '; else o += c; } return o;
}
inline std::wstring ClassName(const std::wstring& c) {
    if (c.find(L"assault") != c.npos) return L"Штурмовик";
    if (c.find(L"heavy") != c.npos) return L"Тяжеловес";
    if (c.find(L"medic") != c.npos) return L"Медик";
    return c;
}
// details (top line) and state (second line) from the scene
inline void Where(const std::wstring& s, bool menu, std::wstring& details, std::wstring& state) {
    struct M { const wchar_t* key; const wchar_t* name; int kind; };   // kind: 0 hub, 1 story, 2 operation, 3 prologue, 4 lobby, 5 loadout
    static const M map[] = {
        {L"hub_aegisstation", L"Станция «Эгида»", 0},
        {L"mission_trusgan_investigateasteroid", L"Исследовать астероид", 1},
        {L"mission_trusgan_returnregen", L"Возвращение в «Феникс»", 1},
        {L"mission_bester_rupturedreality", L"Разорванная реальность", 1},
        {L"mission_m29-376_intothevoid", L"В Пустоту", 1},
        {L"op_abandonedcolony", L"Заброшенная колония", 2},
        {L"op_forgottenoutpost", L"Забытый аванпост", 2},
        {L"op_geode_map", L"Пещера жеод", 2},
        {L"op_icefield", L"Станция «Имир»", 2},
        {L"op_mining_facility_raktaa", L"Горнодобывающий комплекс", 2},
        {L"op_terra", L"Площадка терраформирования", 2},
        {L"prologue", L"Пролог", 3},
        {L"lobby", L"Лобби", 4},
        {L"equipment_loadout", L"Снаряжение", 5},
    };
    if (menu || s.empty()) { details = L"В главном меню"; state.clear(); return; }
    for (auto& m : map) if (s.find(m.key) != s.npos) {
        switch (m.kind) {
        case 0: details = L"На станции «Эгида»"; state = L"Отдыхает между заданиями"; return;
        case 1: details = L"Сюжет: " + std::wstring(m.name); state = L"На задании"; return;
        case 2: details = L"Операция: " + std::wstring(m.name); state = L"На задании"; return;
        case 3: details = L"Сюжет: Пролог"; state = L"На задании"; return;
        case 4: details = L"В лобби"; state = L"Собирает отряд"; return;
        case 5: details = L"На станции «Эгида»"; state = L"Подбирает снаряжение"; return;
        }
    }
    details = L"В игре"; state.clear();
}

struct Pipe {
    HANDLE h = INVALID_HANDLE_VALUE;
    bool Open() {
        for (int i = 0; i < 10; ++i) {
            std::wstring n = L"\\\\.\\pipe\\discord-ipc-" + std::to_wstring(i);
            h = CreateFileW(n.c_str(), GENERIC_READ | GENERIC_WRITE, 0, nullptr, OPEN_EXISTING, 0, nullptr);
            if (h != INVALID_HANDLE_VALUE) return true;
        }
        return false;
    }
    void Close() { if (h != INVALID_HANDLE_VALUE) CloseHandle(h); h = INVALID_HANDLE_VALUE; }
    bool Send(uint32_t op, const std::string& js) {
        std::string b(8 + js.size(), 0); uint32_t n = (uint32_t)js.size();
        memcpy(&b[0], &op, 4); memcpy(&b[4], &n, 4); memcpy(&b[8], js.data(), js.size());
        DWORD w = 0; return WriteFile(h, b.data(), (DWORD)b.size(), &w, nullptr) && w == b.size();
    }
    bool Recv(std::string& out) {   // one frame, non-blocking if nothing is waiting
        DWORD avail = 0; if (!PeekNamedPipe(h, nullptr, 0, nullptr, &avail, nullptr)) return false;
        if (avail < 8) return true;
        uint32_t hd[2]; DWORD r = 0; if (!ReadFile(h, hd, 8, &r, nullptr) || r != 8) return false;
        out.assign(hd[1], 0); DWORD got = 0;
        while (got < hd[1]) { if (!ReadFile(h, &out[got], hd[1] - got, &r, nullptr) || !r) return false; got += r; }
        return true;
    }
};

inline DWORD WINAPI Thread(LPVOID) {
    Pipe p; bool ready = false; double nextTry = 0; std::wstring lastScene; int64_t since = (int64_t)time(nullptr); int nonce = 0;
    for (;;) {
        Sleep(1000);
        double now = Now_();
        if (p.h == INVALID_HANDLE_VALUE) {
            if (now < nextTry) continue;
            nextTry = now + 15;
            if (!p.Open()) continue;
            ready = false;
            if (!p.Send(0, "{\"v\":1,\"client_id\":\"" + g_clientId + "\"}")) { p.Close(); continue; }
        }
        std::string msg;
        while (true) {
            msg.clear();
            if (!p.Recv(msg)) { if (g_log) g_log("discord: disconnected"); p.Close(); ready = false; break; }
            if (msg.empty()) break;
            if (msg.find("\"READY\"") != msg.npos) { ready = true; g_dirty = true; if (g_log) g_log("discord: connected"); }
            else if (msg.find("\"ERROR\"") != msg.npos && g_log) g_log("discord: %s", msg.substr(0, 200).c_str());
        }
        { bool m = now - g_lastSeen.load() > 4; std::lock_guard<std::mutex> lk(g_mx); if (m != g_info.menu) { g_info.menu = m; g_dirty = true; } }
        if (!ready || p.h == INVALID_HANDLE_VALUE || !g_dirty.exchange(false)) continue;
        Info i; { std::lock_guard<std::mutex> lk(g_mx); i = g_info; }
        bool menu = now - g_lastSeen.load() > 4;   // no player character updates: main menu / loading
        if (menu != i.menu) { std::lock_guard<std::mutex> lk(g_mx); g_info.menu = menu; i.menu = menu; }
        if (i.scene != lastScene) { lastScene = i.scene; since = (int64_t)time(nullptr); }
        std::wstring det, st; Where(i.scene, i.menu, det, st);
        std::wstring who;
        if (!i.cls.empty()) who = ClassName(i.cls) + (i.level ? L", ур. " + std::to_wstring(i.level) : L"");
        if (!i.hero.empty()) who = i.hero + (who.empty() ? L"" : L" (" + who + L")");
        if (!who.empty()) st = st.empty() ? who : st + L" · " + who;
        std::string js = "{\"cmd\":\"SET_ACTIVITY\",\"args\":{\"pid\":" + std::to_string(GetCurrentProcessId()) + ",\"activity\":{";
        js += "\"details\":\"" + Esc(U8(det)) + "\"";
        if (!st.empty()) js += ",\"state\":\"" + Esc(U8(st)) + "\"";
        js += ",\"timestamps\":{\"start\":" + std::to_string(since) + "}";
        js += ",\"assets\":{\"large_image\":\"logo\",\"large_text\":\"Зомби-штурм: Пробуждение (русификатор MeT1oR & Tianku)\"";
        if (!i.cls.empty()) { std::wstring c = i.cls; for (auto& ch : c) ch = towlower(ch); js += ",\"small_image\":\"" + Esc(U8(c)) + "\",\"small_text\":\"" + Esc(U8(ClassName(i.cls))) + "\""; }
        js += "}}},\"nonce\":\"" + std::to_string(++nonce) + "\"}";
        if (!p.Send(1, js)) { p.Close(); ready = false; }
    }
}
inline void Start(const std::string& clientId, void (*log)(const char*, ...)) {
    if (clientId.empty()) return;
    g_clientId = clientId; g_log = log;
    CloseHandle(CreateThread(nullptr, 0, Thread, nullptr, 0, nullptr));
    if (g_log) g_log("discord: rich presence on");
}
}
