EDITS = {}
EDITS["T_HVM_Kevlar5_Vest_BaseColour_FE"] = [
    dict(box=(707, 194, 812, 223), text="ВСБ", font="russo", mode="light", rot=180, erase="box", fill="copy", fit="tight", pad=1, ebox=(706, 193, 814, 224)),
    dict(box=(1395, 306, 1500, 341), text="ВСБ", font="russo", mode="light", erase="box", fill="copy", fit="tight", pad=1, ebox=(1392, 303, 1515, 347)),
]
def L(box, text, rot=0, flip=False, font="russo", mode="light", **kw):
    if kw.pop("big", False):
        d = dict(box=box, text=text, rot=rot, flip=flip, font=font, mode=mode, erase="box", fill="copy", fit="tight", pad=1)
        d.setdefault("ebox", (box[0] - 1, box[1] - 1, box[2] + 1, box[3] + 1)); d.setdefault("feather", 0)
    else:
        d = dict(box=box, text=text, rot=rot, flip=flip, font=font, mode=mode, erase=None, fit="tight", pad=1, ir=3)
    d.setdefault("grunge", 0.3)
    d.update(kw); return d
EDITS["T_HVM_A-753_Turret_BaseColour_FE"] = [
    L((478, 249, 529, 265), "ВСБ", big=True), L((478, 602, 529, 616), "ВСБ", rot=180, big=True),
    L((59, 619, 112, 636), "ВСБ", rot=180, big=True), L((304, 620, 357, 637), "ВСБ", rot=180, big=True),
]
EDITS["T_HVM_M-88_Frag_Grenade_BaseColour_FE"] = [
    L((684, 772, 701, 845), "ВСБ", rot=270, color=(160, 140, 50)),
    L((650, 843, 670, 910), "ОСКОЛ.", rot=270, color=(180, 162, 62), font="tektur", weight=700),
    L((630, 843, 645, 910), "ВЗРЫВООПАСНО", rot=270, color=(175, 157, 62), font="tektur", weight=500),
]
EDITS["T_CM_Cryo_Grenade_BaseColour_FE"] = [
    L((17, 82, 58, 102), "КМ", mode="dark", erase=None, pad=1, ir=3), L((896, 82, 935, 103), "КМ", mode="dark", erase=None, pad=1, ir=3),
    L((204, 385, 214, 452), "ВНИМАНИЕ", rot=270, font="oswald", weight=600, ebox=(204, 385, 214, 452)),
    L((204, 781, 214, 859), "ВНИМАНИЕ", rot=270, font="oswald", weight=600, ebox=(204, 781, 214, 859)),
]
def V(box, text, **kw):   # vertical text, reading bottom->top
    kw.setdefault("rot", 270); return L(box, text, **kw)
EDITS["T_Ronson_66GN_Flashbang_Grenade_BaseColour_FE"] = [
    V((2, 192, 27, 320), "ВНИМАНИЕ", font="oswald", weight=600, rot=90), V((2, 702, 27, 832), "ВНИМАНИЕ", font="oswald", weight=600, rot=90),
    V((114, 202, 145, 252), "Р24", rot=270), V((114, 712, 145, 762), "Р24", rot=270),
    V((116, 254, 142, 312), "СВЕТО-\nШУМОВАЯ", font="oswald", weight=600, gap=0.1, rot=270), V((116, 764, 142, 822), "СВЕТО-\nШУМОВАЯ", font="oswald", weight=600, gap=0.1, rot=270),
    V((66, 208, 86, 308), "Р24-002-375", font="oswald", rot=90, fill="inpaint", erase=None, pad=1),
    V((117, 462, 168, 558), "СВЕТО-\nШУМОВАЯ", font="oswald", weight=600, gap=0.1, rot=270),
    V((686, 586, 705, 624), "ТЯНИ", font="oswald", weight=600, rot=270),
]
EDITS["T_Ronson_WP_79_AR_BaseColour_FE"] = [
    V((496, 4, 522, 92), "ВНИМАНИЕ", font="oswald", weight=600, rot=90, flip=True), V((538, 4, 562, 92), "ВНИМАНИЕ", font="oswald", weight=600, rot=270),
]
EDITS["T_Ronson_MK_VII_Flame_Turret_BaseColour_FE"] = [
    L((x0, 449, x1, 460), "ОСТОРОЖНО", font="oswald", weight=500) for x0, x1 in ((440, 485), (600, 645), (740, 785), (880, 922))
]
EDITS["T_Ronson_Warden_Vest_BaseColour_FE"] = [
    V((150, 1076, 190, 1186), "ОГНЕСТРАЖ", font="oswald", weight=500, rot=90),
]
EDITS["T_CM_Supernova_Turret_BaseColour_FE"] = [V((210, 908, 242, 962), "КМ", mode="dark", rot=90)]
EDITS["T_HIKS_Heavyshot_Guardian_Turret_BaseColour_FE"] = [
    V((295, 188, 310, 229), "ХИКС", mode="dark", rot=270, vflip=True), V((890, 494, 905, 542), "ХИКС", mode="dark", rot=270, flip=True),
]
EDITS["T_Morlok_Concussion_Grenade_BaseColour_FE"] = [
    V((213, 158, 230, 254), "ОГЛУШАЮЩАЯ", font="oswald", weight=600, rot=270, flip=True, inner=(216, 158, 228, 254)),
    V((231, 148, 249, 254), "ФУГАСНАЯ", font="oswald", weight=600, rot=270, flip=True, inner=(233, 150, 246, 254)),
]
EDITS["T_Morlok_Blizzard_AR_BaseColour_FE"] = [
    L((361, 405, 426, 419), "МОРЛОК", font="russo"), L((103, 432, 169, 447), "МОРЛОК", font="russo", flip=True),
]
EDITS["T_Morlok_Frostbite_Pistol_BaseColour_FE"] = [
    L((710, 120, 757, 134), "ОСТОРОЖНО", font="oswald", weight=600),
    L((451, 211, 517, 224), "МОРЛОК", flip=True), V((766, 448, 780, 512), "МОРЛОК", rot=90),
]
EDITS["T_Morlok_Galvanizer_SMG_BaseColour_FE"] = [L((130, 136, 214, 153), "МОРЛОК")]
EDITS["T_Morlok_Ice_Storm_LMG_BaseColour_FE"] = [V((94, 362, 106, 410), "МОРЛОК", rot=90, flip=True, inner=(96, 368, 104, 407))]
EDITS["T_Morlok_Vesuvius_PowerWeapon_BaseColour_FE"] = [
    L((582, 369, 638, 385), "ВНИМАНИЕ", font="oswald", weight=600), L((734, 369, 790, 385), "ВНИМАНИЕ", font="oswald", weight=600),
    V((871, 115, 888, 175), "МОРЛОК", rot=90), V((891, 845, 908, 905), "МОРЛОК", rot=90),
]
EDITS["T_Morlok_Voltaic_Bolter_Pistol_BaseColour_FE"] = [
    V((356, 156, 375, 226), "ВНИМАНИЕ", font="oswald", weight=600, rot=90, flip=True),
    L((430, 425, 498, 443), "МОРЛОК", flip=True), V((610, 407, 628, 478), "МОРЛОК", rot=90),
    V((988, 561, 1006, 638), "ВНИМАНИЕ", font="oswald", weight=600, rot=90, flip=True),
]
EDITS["T_Morlok_Mining_Laser_Turret_BaseColour_FE"] = [
    V((246, 205, 256, 246), "МОРЛОК", rot=90),
    L((666, 31, 713, 58), "МОРЛОК", angle=27, thr=0.7, color=(222, 205, 200), fit="box", inner=(668, 33, 711, 56)),
    L((934, 562, 970, 596), "МОРЛОК", angle=-37, thr=0.7, color=(222, 205, 200), fit="box", inner=(935, 564, 969, 594)),
]
EDITS["T_RIA_Arctic_Circle_Turret_BaseColour_FE"] = [L((433, 145, 469, 162), "РИА")]
EDITS["T_RIA_J96_Pulser_Grenade_BaseColour_FE"] = [
    L((281, 475, 350, 487), "ВЫСОКАЯ МОЩНОСТЬ", inner=(283, 477, 348, 486), flip=True, font="oswald", weight=600, thr=0.25, color=(165, 135, 50)),
    L((440, 670, 491, 682), "ОПАСНО", flip=True, font="oswald", weight=700, thr=0.25),
]
EDITS["T_RIA_T48_Blaze_LMG_BaseColour_FE"] = [
    L((818, 589, 862, 599), "ВНИМАНИЕ", font="oswald", weight=600, thr=0.3, color=(160, 132, 45), erase="box", fill="dark", ebox=(818, 590, 862, 598), inner=(820, 590, 860, 598)),
    L((834, 822, 878, 831), "ВНИМАНИЕ", font="oswald", weight=600, thr=0.3, color=(160, 132, 45), erase="box", fill="dark", ebox=(834, 823, 878, 830), inner=(836, 823, 876, 830)),
]
EDITS["T_Rancor_Acid_Bomb_Grenade_BaseColour_FE"] = [
    V((92, 54, 101, 105), "КИСЛОТНАЯ", font="oswald", weight=600, rot=270, thr=0.55, color=(200, 190, 185), margin=2),
    V((85, 54, 92, 111), "ФУГАСНАЯ", font="oswald", weight=600, inner=(86, 56, 92, 109), rot=270, thr=0.3, color=(190, 150, 40), margin=2),
    L((854, 371, 908, 380), "ФУГАСНАЯ", font="oswald", weight=600, rot=180, thr=0.3, color=(190, 150, 40)),
    L((856, 380, 908, 390), "КИСЛОТНАЯ", font="oswald", weight=600, rot=180, thr=0.55, color=(200, 190, 185)),
]
EDITS["T_Rancor_Caustic_Flare_PowerWeapon_BaseColour_FE"] = [
    L((212, 20, 285, 35), "ВНИМАНИЕ", flip=True, font="oswald", weight=700, thr=0.75, color=(225, 250, 200), inner=(213, 21, 286, 34)),
    V((834, 14, 854, 98), "ВНИМАНИЕ", rot=270, font="oswald", weight=700, thr=0.75, color=(225, 250, 200), inner=(837, 17, 851, 95)),
]
EDITS["T_Shotlite_Impact_Grenade_BaseColour_FE"] = [
    V((415, 302, 434, 430), "ВНИМАНИЕ", rot=270, font="oswald", weight=700, thr=0.35, color=(200, 130, 30), inner=(416, 305, 433, 427)),
    V((412, 790, 432, 904), "ВНИМАНИЕ", rot=270, font="oswald", weight=700, thr=0.35, color=(200, 130, 30), inner=(413, 793, 431, 901)),
    V((122, 210, 138, 264), "УДАРНАЯ", rot=90, mode="dark", font="oswald", weight=500, erase="box", fill="inpaint", ebox=(125, 211, 137, 264), inner=(127, 213, 136, 263)),
    V((126, 640, 142, 697), "УДАРНАЯ", rot=90, mode="dark", font="oswald", weight=500),
]
EDITS["T_Smoke_Stack_FPM_Fire_Grenade_BaseColour_FE"] = [
    L((45, 14, 98, 34), "ЛЕГКО-\nВОСПЛАМЕНЯЕМО", font="oswald", weight=600, thr=0.35, color=(185, 140, 30), align="l", gap=0.12, inner=(46, 15, 97, 33)),
    L((369, 14, 422, 34), "ЛЕГКО-\nВОСПЛАМЕНЯЕМО", font="oswald", weight=600, thr=0.35, color=(185, 140, 30), align="l", gap=0.12, inner=(370, 15, 421, 33)),
    V((542, 774, 551, 822), "ВНИМАНИЕ", rot=270, font="oswald", weight=600, thr=0.35, color=(175, 130, 40)),
    V((541, 913, 550, 968), "ВНИМАНИЕ", rot=270, font="oswald", weight=600, thr=0.35, color=(175, 130, 40)),
]
W = dict(font="oswald", weight=700)
EDITS["T_Smoke_Stack_Pathfinder_Sniper_BaseColour_FE"] = [V((333, 641, 345, 686), "ВНИМАНИЕ", rot=90, mode="dark", fill="light", erase="box", ebox=(334, 642, 344, 685), inner=(335, 643, 343, 684), **W)]
EDITS["T_Smoke_Stack_Sidewinder_Sniper_BaseColour_FE"] = [
    L((443, 41, 500, 53), "ВНИМАНИЕ", flip=True, mode="dark", fill="light", erase="box", ebox=(444, 42, 499, 52), inner=(446, 43, 498, 51), **W),
    V((1003, 36, 1016, 94), "ВНИМАНИЕ", rot=270, mode="dark", fill="light", erase="box", ebox=(1004, 37, 1015, 93), inner=(1005, 38, 1014, 92), **W),
    V((333, 641, 345, 688), "ВНИМАНИЕ", rot=90, mode="dark", fill="light", erase="box", ebox=(334, 642, 344, 687), inner=(335, 643, 343, 686), **W),
]
EDITS["T_Teknoboom_Balkengewehr_PowerWeapon_BaseColour_FE"] = [
    L((560, 43, 598, 54), "ВНИМАНИЕ", thr=0.6, color=(225, 220, 200), **W),
    L((192, 73, 225, 80), "ОСТОРОЖНО", thr=0.65, color=(235, 225, 160), **W),
    L((118, 251, 153, 262), "ОСТОРОЖНО", flip=True, thr=0.65, color=(235, 225, 160), **W),
    L((100, 986, 155, 998), "ВНИМАНИЕ", flip=True, thr=0.6, color=(225, 220, 200), **W),
]
EDITS["T_Teknoboom_Energiewerfer_RL_BaseColour_FE"] = [
    V((816, 218, 828, 260), "ВНИМАНИЕ", rot=90, mode="dark", **W),
    L((432, 417, 467, 428), "ВНИМАНИЕ", flip=True, thr=0.7, color=(235, 230, 215), **W),
]
def streu(dx, dy):
    S = lambda b: (b[0] + dx, b[1] + dy, b[2] + dx, b[3] + dy)
    return [
        V(S((158, 686, 169, 734)), "МУЛЬТИ", rot=90, thr=0.5, pad=2, color=(215, 220, 190), **W),
        V(S((170, 638, 181, 735)), "ВЫСОКОСКОРОСТНАЯ", rot=90, thr=0.6, color=(215, 220, 190), **W),
        V(S((326, 661, 339, 745)), "ВНИМАНИЕ", rot=90, thr=0.5, pad=2, inner=S((328, 663, 337, 738)), color=(205, 210, 170), **W),
    ]
EDITS["T_Teknoboom_Streugranate_Grenade_BaseColour_FE"] = streu(0, 0) + streu(383, -117)
EDITS["T_Ronson_Warden_Legs_BaseColour_FE"] = [
    V((239, 396, 260, 467), "Р-О", rot=90, flip=True, font="russo", thr=0.55, color=(175, 205, 225)),
    V((650, 616, 664, 654), "Р-О", rot=90, flip=True, font="russo", thr=0.45, pad=2, color=(165, 190, 205)),
]
EDITS["T_Shotlite_Rapid_Coolant_Deployment_Tower_Turret_BaseColour_FE"] = [
    V((842, 419, 851, 453), "Б.Б.О.", rot=90, font="russo", color=(175, 175, 180), erase="box", fill="inpaint", ebox=(843, 420, 850, 452), inner=(844, 422, 849, 451)),
    V((899, 806, 909, 839), "Б.Б.О.", rot=270, font="russo", color=(170, 170, 175), erase="box", fill="inpaint", ebox=(900, 807, 908, 838), inner=(901, 809, 907, 837)),
]
EDITS["T_HVM_Kevlar5_Vest_BaseColour_IG"] = [
    L((170, 49, 212, 59), "ВСБ", rot=180, font="russo", thr=0.6, color=(215, 215, 205), pad=1),
    L((340, 81, 380, 91), "ВСБ", rot=180, font="russo", thr=0.6, color=(215, 215, 205), pad=1),
]
EDITS["T_Ronson_Warden_Vest_BaseColour_FE"].append(V((131, 822, 186, 987), "Р-О", rot=90, font="russo", thr=0.6, color=(170, 205, 220), pad=2))
EDITS["T_Ronson_Warden_Vest_BaseColour_IG"] = [
    L((254, 135, 304, 152), "Р-О", font="russo", thr=0.6, color=(170, 205, 220), pad=1),
    L((200, 143, 231, 152), "ОГНЕСТРАЖ", font="oswald", weight=500, thr=0.5, color=(150, 185, 200), pad=1),
]

# ---- orientation fixes after side-by-side review against the English originals
def _fix(stem, k, **kw):
    e = EDITS[stem][k]
    for key, v in kw.items():
        if v == "toggle": e[key] = not e.get(key, False)
        else: e[key] = v
_fix("T_CM_Cryo_Grenade_BaseColour_FE", 2, flip="toggle"); _fix("T_CM_Cryo_Grenade_BaseColour_FE", 3, flip="toggle")
_fix("T_Ronson_66GN_Flashbang_Grenade_BaseColour_FE", 8, flip="toggle")
_fix("T_Ronson_WP_79_AR_BaseColour_FE", 0, vflip="toggle")
_fix("T_Morlok_Ice_Storm_LMG_BaseColour_FE", 0, vflip="toggle")
_fix("T_Morlok_Voltaic_Bolter_Pistol_BaseColour_FE", 0, vflip="toggle"); _fix("T_Morlok_Voltaic_Bolter_Pistol_BaseColour_FE", 3, vflip="toggle")
_fix("T_Rancor_Acid_Bomb_Grenade_BaseColour_FE", 0, text="КОРРОЗИЙНАЯ")
_fix("T_Rancor_Acid_Bomb_Grenade_BaseColour_FE", 2, rot=0, flip=True)
_fix("T_Rancor_Acid_Bomb_Grenade_BaseColour_FE", 3, rot=0, flip=True, text="КОРРОЗИЙНАЯ")
_fix("T_Smoke_Stack_Sidewinder_Sniper_BaseColour_FE", 0, flip=False, vflip=True)
