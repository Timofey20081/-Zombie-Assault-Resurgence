// shared memory between ZAPad (in the game) and ZAKbd.exe (ASUS Aura, out of process)
#pragma once
#include <cstdint>
namespace KBShm {
constexpr int Max = 512;
struct Block {
    volatile long ready;      // helper: 1 = layout filled, -1 = failed
    volatile long quit;       // game: 1 = release the keyboard and exit
    volatile long seq;        // game: bumped after colours are written
    int count;
    float x[Max], y[Max];
    uint16_t code[Max];
    uint32_t color[Max];      // 0x00BBGGRR
    char name[64];
};
inline void Name(wchar_t* out, size_t n, unsigned pid) { swprintf(out, n, L"Local\\ZAKbd_%u", pid); }
}
