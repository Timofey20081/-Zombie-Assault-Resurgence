// hdhaptics.h — persistent low-latency DualSense HD haptics stream (USB audio, channels 3/4).
// Voices are synthesised and mixed in a render thread, so many short effects can overlap.
#pragma once
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <mmreg.h>
#include <mmdeviceapi.h>
#include <audioclient.h>
#include <functiondiscoverykeys_devpkey.h>
#include <atomic>
#include <cmath>
#include <mutex>
#include <vector>
#include <random>
#include <string>
#include <cstdio>
#include <cstring>
#include <algorithm>

namespace HD {

enum Side { Left = 1, Right = 2, Both = 3, Speaker = 4 };

struct Voice {
    double start;           // seconds on the stream clock
    float f0, f1, dur, amp; // sweep f0->f1 Hz
    int side; int shape;    // shape: 1 = sharp attack + fast decay, 2 = smooth decay, 0 = flat, 9 = noise
    double phase = 0;
};

inline std::mutex g_mx;
inline std::vector<Voice> g_voices;
inline std::atomic<double> g_clock{0};
inline std::atomic<bool> g_run{false};
inline HANDLE g_thread;
inline unsigned g_rate = 48000;
inline std::atomic<float> g_rumLo{0}, g_rumHi{0};
inline void SetRumble(float lo, float hi) { g_rumLo = lo; g_rumHi = hi; }
inline std::atomic<float> g_spkGain{1.0f};
inline char g_status[128] = "off";
inline const char* Status() { return g_status; }

// radio: one decoded clip (48 kHz) streamed to the speaker, a new line replaces the old one
inline std::vector<float> g_radio; inline size_t g_radioPos = 0; inline std::atomic<float> g_radioGain{0.9f};
inline void PlayRadio(std::vector<float>&& pcm) { std::lock_guard<std::mutex> lk(g_mx); g_radio = std::move(pcm); g_radioPos = 0; }
struct Smp { std::vector<float> s; size_t pos = 0; float gain = 1; };
inline std::vector<Smp> g_smp;
inline void PlaySample(std::vector<float>&& pcm, float gain) { std::lock_guard<std::mutex> lk(g_mx); if (g_smp.size() < 6) g_smp.push_back({std::move(pcm), 0, gain}); }
inline void StopRadio() { std::lock_guard<std::mutex> lk(g_mx); g_radio.clear(); g_radioPos = 0; }
inline void Add(Voice v) { std::lock_guard<std::mutex> lk(g_mx); if (g_voices.size() < 64) g_voices.push_back(v); }
inline void Play(float hz, float dur, float amp, Side s, int shape) { if (g_run) Add({g_clock + 0.004, hz, hz, dur, amp, s, shape}); }
inline void PlayAt(float delay, float hz, float dur, float amp, Side s) { if (g_run) Add({g_clock + delay, hz, hz, dur, amp, s, 1}); }
inline void Sweep(float f0, float f1, float dur, float amp, Side s) { if (g_run) Add({g_clock + 0.004, f0, f1, dur, amp, s, 2}); }
inline void Tone(float delay, float f0, float f1, float dur, float amp) { if (g_run) Add({g_clock + 0.004 + delay, f0, f1, dur, amp, Speaker, 2}); }
inline void Click(float delay, float amp) { if (g_run) Add({g_clock + 0.004 + delay, 0, 0, 0.012f, amp, Speaker, 9}); }
inline void Noise(float dur, float amp, Side s) { if (g_run) Add({g_clock + 0.004, 0, 0, dur, amp, s, 9}); }

inline bool FindEndpoint(IMMDeviceEnumerator* en, IMMDevice** out) {
    IMMDeviceCollection* col = nullptr;
    if (FAILED(en->EnumAudioEndpoints(eRender, DEVICE_STATE_ACTIVE, &col))) return false;
    UINT n = 0; col->GetCount(&n);
    for (UINT i = 0; i < n; ++i) {
        IMMDevice* d = nullptr; if (FAILED(col->Item(i, &d))) continue;
        IPropertyStore* ps = nullptr; PROPVARIANT v; PropVariantInit(&v);
        bool match = false;
        if (SUCCEEDED(d->OpenPropertyStore(STGM_READ, &ps)) && SUCCEEDED(ps->GetValue(PKEY_Device_FriendlyName, &v)) && v.vt == VT_LPWSTR) {
            std::wstring name = v.pwszVal; for (auto& c : name) c = towlower(c);
            match = name.find(L"wireless controller") != std::wstring::npos || name.find(L"dualsense") != std::wstring::npos;
        }
        PropVariantClear(&v); if (ps) ps->Release();
        if (match) { *out = d; col->Release(); return true; }
        d->Release();
    }
    col->Release();
    return false;
}

inline DWORD WINAPI Render(LPVOID) {
    CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    IMMDeviceEnumerator* en = nullptr; IMMDevice* dev = nullptr; IAudioClient* cl = nullptr; IAudioRenderClient* rc = nullptr;
    HANDLE evt = CreateEventW(nullptr, FALSE, FALSE, nullptr);
    bool exclusive = false; unsigned ch = 4, bytes = 2; bool isFloat = false; UINT32 bufFrames = 0;
    auto fail = [&]() { if (!strcmp(g_status, "off")) snprintf(g_status, sizeof g_status, "failed"); if (rc) rc->Release(); if (cl) cl->Release(); if (dev) dev->Release(); if (en) en->Release(); g_run = false; return 0ul; };
    if (FAILED(CoCreateInstance(__uuidof(MMDeviceEnumerator), nullptr, CLSCTX_ALL, __uuidof(IMMDeviceEnumerator), (void**)&en))) { snprintf(g_status, sizeof g_status, "%s", "no audio enumerator"); return fail(); }
    if (!FindEndpoint(en, &dev)) { snprintf(g_status, sizeof g_status, "%s", "DualSense audio endpoint not found"); return fail(); }
    if (FAILED(dev->Activate(__uuidof(IAudioClient), CLSCTX_ALL, nullptr, (void**)&cl))) { snprintf(g_status, sizeof g_status, "%s", "audio activate failed"); return fail(); }
    WAVEFORMATEX* mix = nullptr; cl->GetMixFormat(&mix);
    HRESULT hr = E_FAIL;
    if (mix && mix->nChannels >= 4) {
        ch = mix->nChannels; g_rate = mix->nSamplesPerSec; bytes = mix->wBitsPerSample / 8;
        isFloat = mix->wFormatTag == WAVE_FORMAT_IEEE_FLOAT || (mix->wFormatTag == WAVE_FORMAT_EXTENSIBLE &&
                  ((WAVEFORMATEXTENSIBLE*)mix)->SubFormat.Data1 == 3);
        hr = cl->Initialize(AUDCLNT_SHAREMODE_SHARED, AUDCLNT_STREAMFLAGS_EVENTCALLBACK, 100000 /*10 ms*/, 0, mix, nullptr);
    }
    if (FAILED(hr)) {
        if (mix) { cl->Release(); cl = nullptr; dev->Activate(__uuidof(IAudioClient), CLSCTX_ALL, nullptr, (void**)&cl); }
        WAVEFORMATEXTENSIBLE ex = {};
        ex.Format.wFormatTag = WAVE_FORMAT_EXTENSIBLE; ex.Format.nChannels = 4; ex.Format.nSamplesPerSec = 48000;
        ex.Format.wBitsPerSample = 16; ex.Format.nBlockAlign = 8; ex.Format.nAvgBytesPerSec = 48000 * 8; ex.Format.cbSize = 22;
        ex.Samples.wValidBitsPerSample = 16; ex.dwChannelMask = 0x33;
        ex.SubFormat = {0x00000001, 0x0000, 0x0010, {0x80, 0x00, 0x00, 0xAA, 0x00, 0x38, 0x9B, 0x71}};
        REFERENCE_TIME def = 0, mn = 0; cl->GetDevicePeriod(&def, &mn);
        hr = cl->Initialize(AUDCLNT_SHAREMODE_EXCLUSIVE, AUDCLNT_STREAMFLAGS_EVENTCALLBACK, def, def, &ex.Format, nullptr);
        if (hr == AUDCLNT_E_BUFFER_SIZE_NOT_ALIGNED) {
            UINT32 fr = 0; cl->GetBufferSize(&fr); cl->Release(); cl = nullptr;
            dev->Activate(__uuidof(IAudioClient), CLSCTX_ALL, nullptr, (void**)&cl);
            REFERENCE_TIME al = (REFERENCE_TIME)(10000.0 * 1000.0 * fr / 48000.0 + 0.5);
            hr = cl->Initialize(AUDCLNT_SHAREMODE_EXCLUSIVE, AUDCLNT_STREAMFLAGS_EVENTCALLBACK, al, al, &ex.Format, nullptr);
        }
        ch = 4; bytes = 2; isFloat = false; g_rate = 48000; exclusive = true;
    }
    if (mix) CoTaskMemFree(mix);
    if (FAILED(hr)) { snprintf(g_status, sizeof g_status, "%s", "audio init failed (set Wireless Controller to Quadraphonic or close DSX)"); return fail(); }
    cl->SetEventHandle(evt);
    cl->GetBufferSize(&bufFrames);
    if (FAILED(cl->GetService(__uuidof(IAudioRenderClient), (void**)&rc))) { snprintf(g_status, sizeof g_status, "%s", "render client failed"); return fail(); }
    std::mt19937 rng(7); std::uniform_real_distribution<float> uni(-1.f, 1.f);
    std::vector<float> L, R, S;
    double rumPhLo = 0, rumPhHi = 0; float rumLoS = 0, rumHiS = 0;
    uint64_t frame = 0;
    snprintf(g_status, sizeof g_status, "%s %uch %u Hz %ubit%s buf=%u", exclusive ? "exclusive" : "shared", ch, g_rate, bytes * 8, isFloat ? " float" : "", bufFrames);
    cl->Start();
    while (g_run) {
        if (WaitForSingleObject(evt, 200) != WAIT_OBJECT_0) continue;
        UINT32 pad = 0; if (!exclusive) cl->GetCurrentPadding(&pad);
        UINT32 n = bufFrames - pad; if (!n) continue;
        BYTE* buf = nullptr; if (FAILED(rc->GetBuffer(n, &buf))) break;
        L.assign(n, 0.f); R.assign(n, 0.f); S.assign(n, 0.f);
        // motor emulation on the actuators (the controller ignores the rumble motors while HD audio is used)
        {
            float tl = g_rumLo, th = g_rumHi;
            for (UINT32 i = 0; i < n; ++i) {
                rumLoS += (tl - rumLoS) * 0.002f; rumHiS += (th - rumHiS) * 0.002f;
                rumPhLo += 6.2831853 * 55.0 / g_rate; rumPhHi += 6.2831853 * 160.0 / g_rate;
                float lo = rumLoS * 0.9f * (float)sin(rumPhLo), hi = rumHiS * 0.6f * (float)sin(rumPhHi);
                L[i] += lo + hi * 0.5f; R[i] += lo * 0.7f + hi;
            }
            if (rumPhLo > 1e6) rumPhLo = fmod(rumPhLo, 6.2831853); if (rumPhHi > 1e6) rumPhHi = fmod(rumPhHi, 6.2831853);
        }
        double t0 = (double)frame / g_rate;
        {
            std::lock_guard<std::mutex> lk(g_mx);
            for (auto& v : g_voices) {
                for (UINT32 i = 0; i < n; ++i) {
                    double t = t0 + (double)i / g_rate - v.start;
                    if (t < 0 || t > v.dur) continue;
                    float x = (float)(t / v.dur);
                    float env = v.shape == 1 ? expf(-6.f * x) * std::min(1.f, (float)t * 400.f)
                              : v.shape == 2 ? (1.f - x) * (1.f - x) * std::min(1.f, (float)t * 200.f)
                              : v.shape == 9 ? (1.f - x) : 1.f;
                    float s;
                    if (v.shape == 9) s = uni(rng);
                    else { float f = v.f0 + (v.f1 - v.f0) * x; v.phase += 6.2831853 * f / g_rate; s = (float)sin(v.phase); }
                    s *= v.amp * env;
                    if (v.side & Left) L[i] += s;
                    if (v.side & Right) R[i] += s;
                    if (v.side & Speaker) S[i] += s;
                }
            }
            if (g_radioPos < g_radio.size()) {
                float gn = g_radioGain;
                for (UINT32 i = 0; i < n && g_radioPos < g_radio.size(); ++i) S[i] += g_radio[g_radioPos++] * gn;
            }
            for (auto& sm : g_smp) for (UINT32 i = 0; i < n && sm.pos < sm.s.size(); ++i) S[i] += sm.s[sm.pos++] * sm.gain;
            g_smp.erase(std::remove_if(g_smp.begin(), g_smp.end(), [](const Smp& x) { return x.pos >= x.s.size(); }), g_smp.end());
            double tEnd = t0 + (double)n / g_rate;
            g_voices.erase(std::remove_if(g_voices.begin(), g_voices.end(), [&](const Voice& v) { return v.start + v.dur < tEnd; }), g_voices.end());
        }
        for (UINT32 i = 0; i < n; ++i) {
            float l = std::max(-1.f, std::min(1.f, L[i])), r = std::max(-1.f, std::min(1.f, R[i]));
            float sp = S[i] * g_spkGain.load(); { float m = fabsf(sp); if (m > 0.7f) sp = (sp > 0 ? 1.f : -1.f) * (0.7f + 0.3f * tanhf((m - 0.7f) / 0.3f)); }   // clean up to 0.7, soft knee above
            for (unsigned c = 0; c < ch; ++c) {
                float val = c == 2 ? l : c == 3 ? r : (c < 2 ? sp : 0.f);   // 3/4 = actuators, 1/2 = speaker / headphones
                BYTE* p = buf + ((size_t)i * ch + c) * bytes;
                if (isFloat) memcpy(p, &val, 4);
                else if (bytes == 2) { int16_t v = (int16_t)(val * 32767); memcpy(p, &v, 2); }
                else if (bytes == 4) { int32_t v = (int32_t)(val * 2147483647.0); memcpy(p, &v, 4); }
                else if (bytes == 3) { int32_t v = (int32_t)(val * 8388607); p[0] = v & 0xff; p[1] = (v >> 8) & 0xff; p[2] = (v >> 16) & 0xff; }
            }
        }
        rc->ReleaseBuffer(n, 0);
        frame += n; g_clock = (double)frame / g_rate;
    }
    cl->Stop(); fail(); CloseHandle(evt);
    return 0;
}

inline bool Start() {
    if (g_run) return true;
    g_run = true;
    g_thread = CreateThread(nullptr, 0, Render, nullptr, 0, nullptr);
    Sleep(300);
    return g_run;
}
inline void Stop() { g_run = false; if (g_thread) { WaitForSingleObject(g_thread, 1000); CloseHandle(g_thread); g_thread = nullptr; } }

} // namespace HD
