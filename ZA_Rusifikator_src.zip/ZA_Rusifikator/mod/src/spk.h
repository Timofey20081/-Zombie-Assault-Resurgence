// ZAPad radio voice: dialogue lines replayed on the DualSense speaker through a radio filter.
// ZASpk.dat (built offline): header, clip table (IMA ADPCM 4-bit, 11025 Hz), key table (text hash -> clip, male/female).
#pragma once
#include <cstdint>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <algorithm>

namespace SPK {
struct Clip { uint32_t off, n; };
struct Key { uint32_t h; uint16_t m, f; };
struct Pack {
    std::vector<uint8_t> g_dat; uint32_t g_rate = 11025;
    const Clip* g_clips = nullptr; uint32_t g_nClips = 0;
    const Key* g_keys = nullptr; uint32_t g_nKeys = 0;
    bool Load(const std::wstring& path);
    const Key* Lookup(uint32_t h) const;
    int Find(uint32_t h, bool female) const;
    std::vector<float> Decode(int clip, bool radio) const;
    bool IsRadio(int clip) const { return clip >= 0 && (uint32_t)clip < g_nClips && (g_clips[clip].n & 0x80000000u); }
};
inline Pack g_voice, g_sfx;
inline bool Pack::Load(const std::wstring& path) {
    FILE* f = _wfopen(path.c_str(), L"rb"); if (!f) return false;
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    g_dat.resize(n); bool ok = fread(g_dat.data(), 1, n, f) == (size_t)n; fclose(f);
    if (!ok || n < 16 || memcmp(g_dat.data(), "ZSPK", 4)) { g_dat.clear(); return false; }
    uint32_t* h = (uint32_t*)g_dat.data(); g_rate = h[1]; g_nClips = h[2]; g_nKeys = h[3];
    g_clips = (const Clip*)(g_dat.data() + 16); g_keys = (const Key*)(g_dat.data() + 16 + 8 * g_nClips);
    return true;
}
inline uint32_t Low(uint32_t o) {
    if (o >= 0x41 && o <= 0x5a) return o + 32;
    if (o >= 0x410 && o <= 0x42f) return o + 32;
    if (o >= 0x400 && o <= 0x40f) return o + 80;
    return o;
}
// same normalisation as the offline builder: drop <tags> and {placeholders}, keep latin/cyrillic letters and digits
inline void Hashes(const wchar_t* s, int len, uint32_t& full, uint32_t& pre) {
    uint32_t h = 2166136261u, hp = 2166136261u; int cnt = 0, depthT = 0, depthB = 0;
    for (int i = 0; i < len; ++i) {
        wchar_t c = s[i];
        if (c == L'<') { depthT = 1; continue; } if (depthT) { if (c == L'>') depthT = 0; continue; }
        if (c == L'{') { depthB = 1; continue; } if (depthB) { if (c == L'}') depthB = 0; continue; }
        uint32_t o = (uint32_t)c, lo = Low(o);
        bool keep = (c >= L'0' && c <= L'9') || (lo >= 'a' && lo <= 'z') || (o >= 0x400 && o <= 0x4ff);
        if (!keep) continue;
        h ^= lo & 0xff; h *= 16777619u; h ^= lo >> 8; h *= 16777619u;
        if (cnt < 40) { hp ^= lo & 0xff; hp *= 16777619u; hp ^= lo >> 8; hp *= 16777619u; }
        ++cnt;
    }
    full = cnt >= 4 ? h : 0; pre = cnt >= 4 ? (hp ^ 0x5a5a5a5au) : 0;
}
inline const Key* Pack::Lookup(uint32_t h) const {
    if (!g_nKeys || !h) return nullptr;
    const Key* e = std::lower_bound(g_keys, g_keys + g_nKeys, h, [](const Key& k, uint32_t v) { return k.h < v; });
    return (e == g_keys + g_nKeys || e->h != h) ? nullptr : e;
}
inline int Pack::Find(uint32_t h, bool female) const {
    const Key* e = Lookup(h); if (!e) return -1;
    uint16_t c = female ? e->f : e->m; return c == 0xffff ? -1 : c;
}
// decode + upsample to 48 kHz, with a short squelch burst at both ends
inline std::vector<float> Pack::Decode(int clip, bool radio) const {
    static const int st[89] = {7,8,9,10,11,12,13,14,16,17,19,21,23,25,28,31,34,37,41,45,50,55,60,66,73,80,88,97,107,118,130,143,157,173,190,209,230,253,279,307,337,371,408,449,494,544,598,658,724,796,876,963,1060,1166,1282,1411,1552,1707,1878,2066,2272,2499,2749,3024,3327,3660,4026,4428,4871,5358,5894,6484,7132,7845,8630,9493,10442,11487,12635,13899,15289,16818,18500,20350,22385,24623,27086,29794,32767};
    static const int it[16] = {-1,-1,-1,-1,2,4,6,8,-1,-1,-1,-1,2,4,6,8};
    const Clip& c = g_clips[clip]; const uint8_t* p = g_dat.data() + c.off;
    const uint32_t cn = c.n & 0x7fffffffu;
    std::vector<float> src(cn); int pred = 0, idx = 0;
    for (uint32_t i = 0; i < cn; ++i) {
        int code = (i & 1) ? (p[i >> 1] >> 4) : (p[i >> 1] & 15);
        int step = st[idx], d = step >> 3;
        if (code & 4) d += step; if (code & 2) d += step >> 1; if (code & 1) d += step >> 2;
        pred += (code & 8) ? -d : d; pred = std::max(-32768, std::min(32767, pred));
        idx = std::max(0, std::min(88, idx + it[code]));
        src[i] = pred / 32768.f;
    }
    const double r = (double)g_rate / 48000.0; size_t n = (size_t)(cn / r);
    const size_t sq = radio ? 48000 / 12 : 0;   // ~80 ms squelch for radio lines
    std::vector<float> out(n + 2 * sq);
    uint32_t rng = 12345;
    auto noise = [&] { rng = rng * 1664525u + 1013904223u; return ((rng >> 9) / 4194304.f - 1.f); };
    for (size_t i = 0; i < sq; ++i) out[i] = noise() * 0.07f * (1.f - (float)i / sq);
    for (size_t i = 0; i < n; ++i) {
        double x = i * r; size_t a = (size_t)x; float t = (float)(x - a);
        float v = a + 1 < src.size() ? src[a] * (1 - t) + src[a + 1] * t : src[std::min(a, src.size() - 1)];
        if (radio) v = tanhf(v * 1.3f) / tanhf(1.3f) * 0.85f;   // speaker overdrive: the "walkie-talkie" grit
        out[sq + i] = v;
    }
    for (size_t i = 0; i < sq; ++i) out[sq + n + i] = noise() * 0.08f * (1.f - (float)i / sq) + (i < sq / 2 ? 0.07f * (float)sin(6.2831853 * 1400.0 * i / 48000.0) : 0.f);   // squelch + roger beep
    return out;
}
}
