// Мастер установки русификатора «Зомби-штурм: Пробуждение» (Zombie Assault: Resurgence) — by MeT1oR & Tianku
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

[assembly: AssemblyTitle("Русификатор «Зомби-штурм: Пробуждение» Lite")]
[assembly: AssemblyDescription("Русификатор Zombie Assault: Resurgence")]
[assembly: AssemblyCompany("MeT1oR & Tianku")]
[assembly: AssemblyProduct("Русификатор «Зомби-штурм: Пробуждение»")]
[assembly: AssemblyCopyright("MeT1oR & Tianku")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

namespace ZaSetup
{
    public class Wizard : Form
    {
        const string Title = "Русификатор «Зомби-штурм: Пробуждение»";
        const string RegKey = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\ZA_Rusifikator";
        const int W = 600, H = 430, BottomY = 378;

        readonly bool uninstallMode;
        Image wizImg, smallImg;
        int page;
        Button bBack, bNext, bCancel;
        Panel[] pages;
        // controls
        TextBox tPath; Label lPathState;
        RadioButton rEn, rPt; CheckBox cLogos;
        TextBox tReady;
        Label lStatus; ProgressBar bar; ListBox log;
        Label lFinTitle, lFinText; CheckBox cRunGame;
        Installer inst = new Installer();
        bool busy, success;

        static Stream Res(string n) { return Assembly.GetExecutingAssembly().GetManifestResourceStream(n); }

        public Wizard(bool uninstall)
        {
            uninstallMode = uninstall;
            Text = (uninstall ? "Удаление: " : "Установка: ") + Title + " " + Installer.Version + " Lite";
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }
            Font = SystemFonts.MessageBoxFont;
            FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = true;
            StartPosition = FormStartPosition.CenterScreen;
            AutoScaleMode = AutoScaleMode.None;
            ClientSize = new Size(W, H);
            BackColor = SystemColors.Control;
            wizImg = Image.FromStream(Res("wizard.png"));
            smallImg = Image.FromStream(Res("small.png"));

            Controls.Add(new Label { BorderStyle = BorderStyle.Fixed3D, Location = new Point(0, BottomY), Size = new Size(W, 2) });
            var brand = new Label { Text = "by MeT1oR & Tianku", ForeColor = SystemColors.GrayText, AutoSize = true, Location = new Point(12, BottomY + 17) };
            Controls.Add(brand);
            bBack = Btn("< &Назад", 336); bNext = Btn("&Далее >", 420); bCancel = Btn("Отмена", 512);
            bBack.Click += (s, e) => Go(page - 1);
            bNext.Click += (s, e) => Next();
            bCancel.Click += (s, e) => Close();
            AcceptButton = bNext;

            pages = new[] { WelcomePage(), FolderPage(), OptionsPage(), ReadyPage(), ProgressPage(), FinishPage() };
            foreach (var p in pages) { p.Visible = false; Controls.Add(p); }

            inst.OpenPayload = () => Res("payload.zip");
            inst.Log = (m, k) => BeginInvoke((Action)(() => AddLog(m, k)));
            inst.Progress = v => BeginInvoke((Action)(() => bar.Value = Math.Max(0, Math.Min(100, v))));

            string g = Installer.FindGame(Path.GetDirectoryName(Application.ExecutablePath));
            if (g == null) try { using (var k = Registry.LocalMachine.OpenSubKey(RegKey)) if (k != null) g = k.GetValue("InstallLocation") as string; } catch { }
            if (g != null) tPath.Text = g;
            CheckPath();

            FormClosing += (s, e) =>
            {
                if (busy) { e.Cancel = true; return; }
                if (page < 4 && !uninstallMode && MessageBox.Show(this, "Установка не завершена. Выйти из программы установки?", "Выход", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) e.Cancel = true;
            };
            Go(uninstallMode ? 1 : 0);
        }

        Button Btn(string t, int x)
        {
            var b = new Button { Text = t, Location = new Point(x, BottomY + 12), Size = new Size(82, 26), UseVisualStyleBackColor = true };
            Controls.Add(b); return b;
        }

        // ---------------------------------------------------------- page builders
        Panel Side(string title, out Label text)
        {
            var p = new Panel { Location = new Point(0, 0), Size = new Size(W, BottomY), BackColor = Color.White };
            p.Controls.Add(new PictureBox { Image = wizImg, Location = new Point(0, 0), Size = new Size(200, 380), SizeMode = PictureBoxSizeMode.StretchImage });
            p.Controls.Add(new Label { Text = title, Location = new Point(218, 16), Size = new Size(366, 74), Font = new Font(Font.FontFamily, 12f, FontStyle.Bold) });
            text = new Label { Location = new Point(218, 96), Size = new Size(366, 270) };
            p.Controls.Add(text);
            return p;
        }

        Panel Inner(string title, string sub)
        {
            var p = new Panel { Location = new Point(0, 0), Size = new Size(W, BottomY) };
            var head = new Panel { Location = new Point(0, 0), Size = new Size(W, 58), BackColor = Color.White };
            head.Controls.Add(new Label { Text = title, Location = new Point(22, 10), AutoSize = true, Font = new Font(Font, FontStyle.Bold) });
            head.Controls.Add(new Label { Text = sub, Location = new Point(38, 30), AutoSize = true });
            head.Controls.Add(new PictureBox { Image = smallImg, Location = new Point(W - 60, 3), Size = new Size(52, 52), SizeMode = PictureBoxSizeMode.Zoom });
            p.Controls.Add(head);
            p.Controls.Add(new Label { BorderStyle = BorderStyle.Fixed3D, Location = new Point(0, 58), Size = new Size(W, 2) });
            return p;
        }

        Panel WelcomePage()
        {
            Label t; var p = Side("Вас приветствует мастер установки русификатора «Зомби-штурм: Пробуждение»", out t);
            t.Text = "Русификатор для Steam-версии Zombie Assault: Resurgence.\n\n" +
                     "Это Lite-версия: простая установка со стандартными настройками. Только перевод текста (меню, способности, оружие, заказы, сюжетные диалоги, Кодекс) " +
                     "и шрифты с кириллицей. Названия компаний и снаряжения, логотипы и надписи на текстурах остаются оригинальными. " +
                     "Русские названия, логотипы, текстуры, моды геймпада, клавиатуры, DLAA и Discord есть в полной версии.\n\n" +
                     "Версия " + Installer.Version + " Lite для игры с " + Installer.GameBuild + ".\n\n" +
                     "Закройте игру перед установкой.\n\n" +
                     "Нажмите «Далее», чтобы продолжить, или «Отмена», чтобы выйти из программы установки.";
            return p;
        }

        Panel FolderPage()
        {
            var p = Inner("Папка игры", "Где установлена Zombie Assault: Resurgence?");
            p.Controls.Add(new Label { Text = "Русификатор будет установлен в папку игры, в которой лежит zombieassault.exe.\nОбычно она находится автоматически. Если нет, нажмите «Обзор…» и укажите её.", Location = new Point(36, 76), Size = new Size(530, 40) });
            tPath = new TextBox { Location = new Point(36, 128), Width = 430 };
            tPath.TextChanged += (s, e) => CheckPath();
            var b = new Button { Text = "&Обзор…", Location = new Point(476, 126), Size = new Size(88, 25), UseVisualStyleBackColor = true };
            b.Click += (s, e) => Browse();
            lPathState = new Label { Location = new Point(36, 160), Size = new Size(530, 40) };
            p.Controls.Add(tPath); p.Controls.Add(b); p.Controls.Add(lPathState);
            return p;
        }

        Panel OptionsPage()
        {
            var p = Inner("Параметры установки", "Выберите, что установить.");
            var g = new GroupBox { Text = "Язык в игре", Location = new Point(36, 72), Size = new Size(530, 78) };
            rEn = new RadioButton { Text = "Русский вместо английского (рекомендуется)", Location = new Point(14, 22), AutoSize = true, Checked = true };
            rPt = new RadioButton { Text = "Русский вместо португальского (английский останется, выбрать Português)", Location = new Point(14, 46), AutoSize = true };
            g.Controls.Add(rEn); g.Controls.Add(rPt); p.Controls.Add(g);
            cLogos = new CheckBox { Checked = false };   // Lite: original logos
            return p;
        }

        Panel ReadyPage()
        {
            var p = Inner("Всё готово к установке", "Проверьте параметры и нажмите «Установить».");
            tReady = new TextBox { Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, Location = new Point(36, 76), Size = new Size(530, 280), BackColor = SystemColors.Window };
            p.Controls.Add(tReady);
            return p;
        }

        Panel ProgressPage()
        {
            var p = Inner(uninstallMode ? "Удаление" : "Установка", uninstallMode ? "Подождите, русификатор удаляется…" : "Подождите, русификатор устанавливается…");
            lStatus = new Label { Location = new Point(36, 76), Size = new Size(530, 18) };
            bar = new ProgressBar { Location = new Point(36, 98), Size = new Size(530, 20) };
            log = new ListBox { Location = new Point(36, 130), Size = new Size(530, 230), IntegralHeight = false, HorizontalScrollbar = true };
            p.Controls.Add(lStatus); p.Controls.Add(bar); p.Controls.Add(log);
            return p;
        }

        Panel FinishPage()
        {
            var p = Side("", out lFinText);
            lFinTitle = (Label)p.Controls[1];
            cRunGame = new CheckBox { Text = "Запустить игру", Location = new Point(220, 324), AutoSize = true, BackColor = Color.White };
            lFinText.Size = new Size(366, 196);
            p.Controls.Add(cRunGame);
            return p;
        }

        // ---------------------------------------------------------- navigation
        void Go(int n)
        {
            page = n;
            for (int i = 0; i < pages.Length; i++) pages[i].Visible = i == n;
            bBack.Enabled = n > 0 && n < 4 && !(uninstallMode && n <= 1);
            bNext.Text = n == 3 ? "&Установить" : n == 5 ? "&Завершить" : (uninstallMode && n == 1 ? "&Удалить" : "&Далее >");
            bCancel.Enabled = n < 4;
            bNext.Enabled = n != 4 && (n != 1 || Installer.IsGame(tPath.Text));
            if (n == 3) tReady.Text = Summary();
            bNext.Focus();
        }

        void Next()
        {
            if (page == 5) { Finish(); return; }
            if (page == 1 && uninstallMode) { Run(true); return; }
            if (page == 1 && !CheckRunning()) return;
            if (page == 3) { Run(false); return; }
            Go(page + 1);
        }

        string Summary()
        {
            var l = new List<string>();
            l.Add("Папка игры:"); l.Add("      " + tPath.Text); l.Add("");
            l.Add("Будет установлено:");
            l.Add("      Перевод текста и шрифты с кириллицей (" + (rPt.Checked ? "вместо португальского" : "вместо английского") + ")");
            l.Add("      Шрифт засекреченного текста и исправление диалогов");
            if (cLogos.Checked) l.Add("      Русские логотипы компаний");
            l.Add(""); l.Add("Оригинальные файлы сохраняются рядом (*.orig) и возвращаются при удалении.");
            l.Add("Удалить русификатор можно через «Параметры → Приложения» Windows или запустив эту программу снова.");
            return string.Join("\r\n", l);
        }

        void CheckPath()
        {
            bool ok = Installer.IsGame(tPath.Text);
            lPathState.ForeColor = ok ? Color.FromArgb(0, 120, 40) : Color.FromArgb(190, 30, 30);
            lPathState.Text = ok ? "Игра найдена." : (string.IsNullOrWhiteSpace(tPath.Text) ? "Папка игры не найдена автоматически. Укажите её вручную." : "В этой папке нет zombieassault.exe.");
            if (page == 1) bNext.Enabled = ok;
        }

        void Browse()
        {
            using (var d = new FolderBrowserDialog { Description = "Укажите папку игры Zombie Assault (где лежит zombieassault.exe)", ShowNewFolderButton = false })
            {
                if (Directory.Exists(tPath.Text)) d.SelectedPath = tPath.Text;
                if (d.ShowDialog(this) == DialogResult.OK) tPath.Text = d.SelectedPath;
            }
        }

        bool CheckRunning()
        {
            while (Process.GetProcessesByName("zombieassault").Length > 0)
                if (MessageBox.Show(this, "Игра запущена. Закройте её и нажмите «Повторить».", Title, MessageBoxButtons.RetryCancel, MessageBoxIcon.Information) == DialogResult.Cancel) return false;
            return true;
        }

        void AddLog(string m, Kind k)
        {
            string pre = k == Kind.Ok ? "✓ " : k == Kind.Warn ? "! " : k == Kind.Error ? "✗ " : "";
            log.Items.Add(pre + m); log.TopIndex = Math.Max(0, log.Items.Count - 1);
            lStatus.Text = m;
        }

        // ---------------------------------------------------------- run
        void Run(bool uninstall)
        {
            if (uninstall && !CheckRunning()) return;
            inst.Game = tPath.Text; inst.Lang = rPt.Checked ? "portuguese" : "english";
            inst.Logos = cLogos.Checked;
            Go(4); busy = true; bNext.Enabled = bBack.Enabled = bCancel.Enabled = false;
            ControlBox = false;
            var th = new Thread(() =>
            {
                bool ok = true;
                try
                {
                    if (uninstall) { inst.Uninstall(); Unregister(); }
                    else { ok = inst.Install(); if (ok) Register(); }
                }
                catch (UnauthorizedAccessException) { ok = false; inst.Log("Нет доступа к папке игры. Запустите программу от имени администратора.", Kind.Error); }
                catch (Exception ex) { ok = false; inst.Log("Ошибка: " + ex.Message, Kind.Error); }
                BeginInvoke((Action)(() => Done(uninstall, ok)));
            }) { IsBackground = true };
            th.Start();
        }

        void Done(bool uninstall, bool ok)
        {
            busy = false; success = ok; ControlBox = true;
            if (uninstall)
            {
                lFinTitle.Text = "Русификатор удалён";
                lFinText.Text = "Игра возвращена к оригиналу.\n\nНажмите «Завершить», чтобы закрыть программу.";
                cRunGame.Visible = false;
            }
            else if (ok)
            {
                lFinTitle.Text = "Установка русификатора завершена";
                lFinText.Text = ("Игра переведена на русский язык." + (inst.Lang == "portuguese" ? " В настройках игры выберите язык Português." : "") + "\n\n") +
                    "Если Steam обновит игру, перевод может слететь: просто запустите установку снова (или скачайте новую версию русификатора).\n\nПриятной игры!";
                cRunGame.Checked = false;
            }
            else
            {
                lFinTitle.Text = "Установка не завершена";
                lFinText.Text = "Часть файлов не удалось установить: скорее всего, игра обновилась и эта версия русификатора ей не подходит, или нет доступа к папке игры.\n\nПодробности были в списке на предыдущем шаге. Оригинальные файлы игры не повреждены.";
                cRunGame.Visible = false;
            }
            Go(5);
        }

        void Finish()
        {
            try
            {
                if (cRunGame.Visible && cRunGame.Checked) Process.Start(new ProcessStartInfo(Path.Combine(tPath.Text, "zombieassault.exe")) { WorkingDirectory = tPath.Text, UseShellExecute = true });
            }
            catch { }
            if (uninstallMode) ScheduleSelfDelete();
            page = 6; Close();
        }

        // ---------------------------------------------------------- Programs & Features
        void Register()
        {
            try
            {
                string dir = Path.Combine(inst.Game, "ZA_Rusifikator");
                Directory.CreateDirectory(dir);
                string un = Path.Combine(dir, "uninstall.exe");
                if (!string.Equals(Path.GetFullPath(Application.ExecutablePath), Path.GetFullPath(un), StringComparison.OrdinalIgnoreCase))
                    File.Copy(Application.ExecutablePath, un, true);
                using (var k = Registry.LocalMachine.CreateSubKey(RegKey))
                {
                    k.SetValue("DisplayName", "Русификатор Zombie Assault: Resurgence (Lite)");
                    k.SetValue("DisplayVersion", Installer.Version + " Lite");
                    k.SetValue("Publisher", "MeT1oR & Tianku");
                    k.SetValue("DisplayIcon", un);
                    k.SetValue("InstallLocation", inst.Game);
                    k.SetValue("UninstallString", "\"" + un + "\" /uninstall");
                    k.SetValue("NoModify", 1, RegistryValueKind.DWord);
                    k.SetValue("NoRepair", 1, RegistryValueKind.DWord);
                    k.SetValue("EstimatedSize", (int)(new FileInfo(un).Length / 1024 + 30000), RegistryValueKind.DWord);
                }
            }
            catch (Exception ex) { inst.Log("Не удалось добавить в список программ: " + ex.Message, Kind.Warn); }
        }

        void Unregister()
        {
            try { Registry.LocalMachine.DeleteSubKeyTree(RegKey, false); } catch { }
        }

        void ScheduleSelfDelete()
        {
            try
            {
                string me = Application.ExecutablePath;
                if (!Path.GetFileName(me).Equals("uninstall.exe", StringComparison.OrdinalIgnoreCase)) return;
                Process.Start(new ProcessStartInfo("cmd.exe", "/c ping 127.0.0.1 -n 3 >nul & del /f /q \"" + me + "\"") { CreateNoWindow = true, UseShellExecute = false, WindowStyle = ProcessWindowStyle.Hidden });
            }
            catch { }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (page >= 5) { base.OnFormClosing(e); return; }
            base.OnFormClosing(e);
        }
    }

    static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            bool un = args.Any(a => a.Equals("/uninstall", StringComparison.OrdinalIgnoreCase) || a.Equals("-uninstall", StringComparison.OrdinalIgnoreCase));
            Application.Run(new Wizard(un));
        }
    }
}
