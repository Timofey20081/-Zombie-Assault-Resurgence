"""Validate Russian translations (tr/ru_*.tsv) against English and build ru XML.

usage: python3 za_build.py check | build OUT.xml
"""
import glob, html, json, re, sys
from collections import Counter

W = "/home/claude/work"
EN_XML = f"{W}/extract/English.txt"
rows = json.load(open(f"{W}/tr/en_all.json"))
en = {r["id"]: r["en"] for r in rows}

def load_ru():
    ru, where = {}, {}
    for fn in sorted(glob.glob(f"{W}/tr/ru_*.tsv")) + sorted(glob.glob(f"{W}/tr/lit_*.tsv")) + sorted(glob.glob(f"{W}/tr/adapt_*.tsv")):
        override = "/lit_" in fn or "/adapt_" in fn
        for ln, line in enumerate(open(fn, encoding="utf-8"), 1):
            line = line.rstrip("\n")
            if not line.strip():
                continue
            if "\t" not in line:
                print(f"BAD LINE {fn}:{ln}: {line[:80]}"); continue
            k, v = line.split("\t", 1)
            v = v.replace("¶", "\n")
            if k in ru and not (override and ("/ru_" in where[k] or ("/lit_" in where[k] and "/adapt_" in fn))):
                print(f"DUP {k} in {fn} (prev {where[k]})")
            ru[k], where[k] = v, f"{fn}:{ln}"
    return ru, where

PH = re.compile(r"\{[^{}]*\}")
TAG = re.compile(r"<[^<>]+>")

def check(ru, where):
    errs = 0
    for k, v in ru.items():
        if k not in en:
            print(f"UNKNOWN ID {k} @ {where[k]}"); errs += 1; continue
        e = en[k]
        # {Text; Text; } style blocks are translated inside; compare only numeric placeholders
        norm = lambda p: re.sub(r":.*;.*", ":<choice>", p, flags=re.S) + "}" if ";" in p else p
        pe = Counter(norm(p) for p in PH.findall(e) if re.match(r"\{\d", p))
        pr = Counter(norm(p) for p in PH.findall(v) if re.match(r"\{\d", p))
        be = Counter(re.findall(r"\[[a-z0-9]+\]", e)); br = Counter(re.findall(r"\[[a-z0-9]+\]", v))
        if be != br:
            print(f"TOKENS {k}: en={dict(be)} ru={dict(br)} @ {where[k]}"); errs += 1
        if pe != pr:
            print(f"PLACEHOLDER {k}: en={dict(pe)} ru={dict(pr)} @ {where[k]}"); errs += 1
        te = Counter(re.sub(r"\s+", "", t) for t in TAG.findall(e))
        tr = Counter(re.sub(r"\s+", "", t) for t in TAG.findall(v))
        if te != tr:
            print(f"TAGS {k}: en={dict(te)} ru={dict(tr)} @ {where[k]}"); errs += 1
        if e.count("\\\\") != v.count("\\\\"):
            print(f"SEPARATOR {k}: en={e.count(chr(92)*2)} ru={v.count(chr(92)*2)} @ {where[k]}"); errs += 1
        if e.count("\n") != v.count("\n") or e.count("\\n") != v.count("\\n"):
            print(f"NEWLINES {k}: real en={e.count(chr(10))} ru={v.count(chr(10))}; literal en={e.count(chr(92)+'n')} ru={v.count(chr(92)+'n')} @ {where[k]}"); errs += 1
        if v.count("{") != v.count("}"):
            print(f"BRACES {k} @ {where[k]}"); errs += 1
    return errs

# The game's "\\\\" separator (label \\ value) looks like a typo to Russian players:
# replace it with normal punctuation at build time (sources keep it, so the
# checks against English still work).
SEP = re.compile(r"[ \t]*\\{2,}[ \t]*")
SEP_FIXED = {"Separator": "—", "SeparatorFormat_Prefix": "— {0}", "SeparatorFormat_Suffix": "{0}"}

def desep(k, v):
    if k in SEP_FIXED:
        return SEP_FIXED[k]
    out_lines = []
    for line in v.split("\n"):
        def rep(m):
            left, right = line[: m.start()], line[m.end():]
            l_txt = TAG.sub("", left).strip()
            r_txt = TAG.sub("", right).strip()
            if not r_txt:                      # trailing: drop
                return ""
            if not l_txt:                      # leading
                return "— " if not left.strip() else " — "
            if l_txt.endswith((":", "—")):
                return " "
            if l_txt.endswith("}"):
                return " — "
            if l_txt.split()[-1].lower() in ("через", "в", "до", "на", "за", "с", "по", "из", "от", "к"):
                return " "
            return ": "
        new = SEP.sub(rep, line)
        new = re.sub(r"\s+$", "", new) if SEP.search(line) else new
        out_lines.append(new)
    return "\n".join(out_lines)

def build(ru, out):
    ru = {k: desep(k, v) for k, v in ru.items()}
    for k in SEP_FIXED:
        ru.setdefault(k, SEP_FIXED[k])
    src = open(EN_XML, encoding="utf-8").read()
    done = set()
    def rep(m):
        k = html.unescape(m.group(1))
        if k in ru:
            done.add(k)
            return m.group(0)[: m.start(2) - m.start(0)] + html.escape(ru[k], quote=False) + "</T>"
        return m.group(0)
    res = re.sub(r'<T\s+id\s*=\s*"([^"]*)"\s*>(.*?)</T>', rep, src, flags=re.S)
    import xml.etree.ElementTree as ET
    ET.fromstring(res.encode("utf-8"))  # must stay valid XML
    open(out, "w", encoding="utf-8", newline="\n").write(res)
    return len(done)

if __name__ == "__main__":
    ru, where = load_ru()
    errs = check(ru, where)
    translatable = [k for k, v in en.items() if re.search(r"[A-Za-z]{2,}", PH.sub("", TAG.sub("", v)))]
    missing = [k for k in translatable if k not in ru]
    print(f"translated {len(ru)} / {len(en)}; errors {errs}; untranslated-with-letters {len(missing)}")
    if len(sys.argv) > 1 and sys.argv[1] == "missing":
        for k in missing: print("  ", k, repr(en[k])[:90])
    if len(sys.argv) > 2 and sys.argv[1] == "build":
        print("replaced", build(ru, sys.argv[2]))
