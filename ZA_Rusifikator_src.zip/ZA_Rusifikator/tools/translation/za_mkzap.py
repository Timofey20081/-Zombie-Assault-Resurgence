"""Make a ZAP1 patch (orig -> new) with copy/literal ops. usage: za_mkzap.py orig new out.zap"""
import sys, struct

orig_p, new_p, out_p = sys.argv[1:4]
o = open(orig_p, "rb").read()
n = open(new_p, "rb").read()
K, STRIDE = 32, 8
idx = {}
for off in range(0, len(o) - K + 1, STRIDE):
    idx.setdefault(o[off:off + K], off)

ops, lit = [], bytearray()
def flush():
    global lit
    if lit:
        ops.append((1, bytes(lit))); lit = bytearray()

i = 0
N = len(n)
while i < N:
    m = idx.get(n[i:i + K]) if i + K <= N else None
    if m is None:
        lit.append(n[i]); i += 1; continue
    b = 0
    start_o, start_n = m, i
    # extend forward in chunks
    L = K + b
    while start_n + L < N and start_o + L < len(o):
        step = min(4096, N - start_n - L, len(o) - start_o - L)
        if n[start_n + L:start_n + L + step] == o[start_o + L:start_o + L + step]:
            L += step; continue
        while start_n + L < N and start_o + L < len(o) and n[start_n + L] == o[start_o + L]:
            L += 1
        break
    flush()
    if ops and ops[-1][0] == 0 and ops[-1][1] + ops[-1][2] == start_o:
        ops[-1] = (0, ops[-1][1], ops[-1][2] + L)
    else:
        ops.append((0, start_o, L))
    i = start_n + L
flush()

# verify
out = bytearray()
for op in ops:
    out += o[op[1]:op[1] + op[2]] if op[0] == 0 else op[1]
assert bytes(out) == n
with open(out_p, "wb") as f:
    f.write(b"ZAP1" + struct.pack("<qi", len(n), len(ops)))
    for op in ops:
        if op[0] == 0: f.write(struct.pack("<Bqi", 0, op[1], op[2]))
        else: f.write(struct.pack("<Bi", 1, len(op[1])) + op[1])
import os
print("ops", len(ops), "literal bytes", sum(len(x[1]) for x in ops if x[0] == 1), "patch", os.path.getsize(out_p))
