// DualSenseHelper.h — GameInput v4 port of Microsoft's DualSense companion helper.
//
// Drop-in successor of the v3 header: same function names, plus
//   * GameInput API v4 (microsoft.gameinput 4.x NuGet),
//   * Bluetooth (report 0x31 + CRC32) with automatic USB/BT detection,
//   * every adaptive trigger effect (see DualSenseProtocol.h),
//   * player LED mask/brightness, mic mute, motor power, audio volumes,
//   * input report reading (battery, touchpad, raw motion).
//
// Usage:
//   using namespace GameInput::DualSense;
//   if (IsDualSense(device->GetVendorId(), device->GetProductId()))
//   {
//       SetDualSenseLightbar(device, 255, 0, 0);
//       DS5::TriggerEffect fx; DS5::EncodeWeapon(fx, 3, 6, 8);
//       SetDualSenseTriggerEffect(device, Trigger::Right, fx);
//   }
//
// MIT License (same as the original Microsoft helper).

#pragma once

#include <GameInput.h>

#if !defined(GAMEINPUT_API_VERSION) || GAMEINPUT_API_VERSION < 4
#error DualSenseHelper (v4 port) requires GameInput API version 4 or later.
#endif

#include <atomic>
#include <stdint.h>
#include <string.h>
#include "DualSenseProtocol.h"

namespace GameInput { namespace DualSense {

using GiDevice = ::GameInput::v4::IGameInputDevice;
using GiReport = ::GameInput::v4::IGameInputRawDeviceReport;

using Trigger   = ::DS5::Trigger;
using Transport = ::DS5::Transport;

enum class PlayerLed : uint8_t
{
    Off     = 0,
    Player1 = 1,
    Player2 = 2,
    Player3 = 3,
    Player4 = 4,
    Player5 = 5,
};

inline bool IsDualSense(uint16_t vendorId, uint16_t productId) noexcept
{
    return ::DS5::IsDualSense(vendorId, productId);
}

namespace Detail {

    inline std::atomic<uint8_t>  g_btSequence{0};
    inline std::atomic<uint32_t> g_usbSizeThatWorked{0};

    inline bool ContainsNoCase(const char* hay, const char* needle) noexcept
    {
        if (!hay || !needle) return false;
        const size_t n = strlen(needle);
        for (const char* p = hay; *p; ++p)
        {
            size_t i = 0;
            while (i < n && p[i])
            {
                char a = p[i], b = needle[i];
                if (a >= 'A' && a <= 'Z') a = static_cast<char>(a - 'A' + 'a');
                if (b >= 'A' && b <= 'Z') b = static_cast<char>(b - 'A' + 'a');
                if (a != b) break;
                ++i;
            }
            if (i == n) return true;
        }
        return false;
    }

    inline bool HasReport(uint32_t count, const ::GameInput::v4::GameInputRawDeviceReportInfo* infos, uint32_t id) noexcept
    {
        for (uint32_t i = 0; i < count; ++i) if (infos[i].id == id) return true;
        return false;
    }

} // namespace Detail

// Detects whether the controller talks over USB or Bluetooth.
inline Transport DetectTransport(GiDevice* device) noexcept
{
    if (device == nullptr) return Transport::Usb;

    ::GameInput::v4::GameInputRawDeviceReportInfo infos[64] = {};
    uint32_t count = device->GetOutputReportCount();
    if (count > 64) count = 64;
    if (count > 0)
    {
        count = device->GetOutputReportInfo(count, infos);
        if (Detail::HasReport(count, infos, ::DS5::BtOutputReportId)) return Transport::Bluetooth;
        if (Detail::HasReport(count, infos, ::DS5::UsbOutputReportId)) return Transport::Usb;
    }

    char path[1024] = {};
    device->GetPnpPath(sizeof(path) - 1, path);
    if (Detail::ContainsNoCase(path, "00001124-0000-1000-8000-00805f9b34fb") ||
        Detail::ContainsNoCase(path, "bthenum") ||
        Detail::ContainsNoCase(path, "bthledevice"))
    {
        return Transport::Bluetooth;
    }

    count = device->GetInputReportCount();
    if (count > 64) count = 64;
    if (count > 0)
    {
        count = device->GetInputReportInfo(count, infos);
        if (Detail::HasReport(count, infos, 0x31)) return Transport::Bluetooth;
    }
    return Transport::Usb;
}

// Sends a prepared report. Tries the report sizes known to work (USB: 64 → descriptor
// size → 63 → 48; Bluetooth: 78) and remembers the one that worked.
inline HRESULT SendDualSenseReport(GiDevice* device, const ::DS5::OutputReport& report, Transport transport) noexcept
{
    if (device == nullptr) return E_POINTER;

    const uint32_t reportId = (transport == Transport::Bluetooth) ? ::DS5::BtOutputReportId : ::DS5::UsbOutputReportId;

    GiReport* raw = nullptr;
    HRESULT hr = device->CreateRawDeviceReport(reportId, ::GameInput::v4::GameInputRawOutputReport, &raw);
    if (FAILED(hr)) return hr;

    const size_t native = raw->GetRawDataSize();
    size_t candidates[6] = {};
    size_t n = 0;
    auto add = [&](size_t s) {
        if (s == 0 || s > ::DS5::MaxReportSize) return;
        for (size_t i = 0; i < n; ++i) if (candidates[i] == s) return;
        candidates[n++] = s;
    };

    if (transport == Transport::Bluetooth)
    {
        add(::DS5::BtReportSize);
        if (native >= ::DS5::BtReportSize) add(native);
    }
    else
    {
        add(Detail::g_usbSizeThatWorked.load());
        add(::DS5::UsbDefaultReportSize);
        if (native >= ::DS5::UsbMinReportSize) add(native);
        add(63);
        add(::DS5::UsbMinReportSize);
    }

    const uint8_t seq = static_cast<uint8_t>(Detail::g_btSequence.fetch_add(1) & 0x0F);
    uint8_t buf[::DS5::MaxReportSize];
    hr = E_INVALIDARG;
    for (size_t i = 0; i < n; ++i)
    {
        const size_t size = candidates[i];
        if (report.Serialize(transport, seq, buf, size) == 0) continue;
        if (!raw->SetRawData(size, buf)) { hr = E_INVALIDARG; continue; }
        hr = device->SendRawDeviceOutput(raw);
        if (SUCCEEDED(hr))
        {
            if (transport == Transport::Usb) Detail::g_usbSizeThatWorked.store(static_cast<uint32_t>(size));
            break;
        }
    }
    raw->Release();
    return hr;
}

inline HRESULT SendDualSenseReport(GiDevice* device, const ::DS5::OutputReport& report) noexcept
{
    return SendDualSenseReport(device, report, DetectTransport(device));
}

// ---------------------------------------------------------------------------
// Original helper API (now USB + Bluetooth)
// ---------------------------------------------------------------------------

inline HRESULT SetDualSenseLightbar(GiDevice* device, uint8_t r, uint8_t g, uint8_t b) noexcept
{
    ::DS5::OutputReport rep;
    rep.Lightbar(r, g, b);
    return SendDualSenseReport(device, rep);
}

// Ends the firmware's blue start-up glow so the host color sticks.
inline HRESULT ReleaseDualSenseLightbar(GiDevice* device) noexcept
{
    ::DS5::OutputReport rep;
    rep.LightbarSetup(::DS5::LightbarSetupBits::LightOut);
    return SendDualSenseReport(device, rep);
}

// Lightbar off: fades out the start-up glow and sets black.
inline HRESULT TurnOffDualSenseLightbar(GiDevice* device) noexcept
{
    ::DS5::OutputReport rep;
    rep.LightbarSetup(::DS5::LightbarSetupBits::LightOut).Lightbar(0, 0, 0);
    return SendDualSenseReport(device, rep);
}

inline HRESULT SetDualSensePlayerLed(GiDevice* device, PlayerLed player) noexcept
{
    const uint8_t index = static_cast<uint8_t>(player);
    ::DS5::OutputReport rep;
    rep.PlayerLeds(index <= 5 ? ::DS5::PlayerLedPatterns[index] : 0);
    return SendDualSenseReport(device, rep);
}

inline HRESULT SetDualSensePlayerLedMask(GiDevice* device, uint8_t mask, ::DS5::LedBrightness brightness, bool instant = false) noexcept
{
    ::DS5::OutputReport rep;
    rep.PlayerLeds(mask, instant).Brightness(brightness);
    return SendDualSenseReport(device, rep);
}

// leftMotor = strong/low-frequency, rightMotor = weak/high-frequency.
inline HRESULT SetDualSenseRumble(GiDevice* device, uint8_t leftMotor, uint8_t rightMotor, bool vibrationV2 = false) noexcept
{
    ::DS5::OutputReport rep;
    rep.Rumble(leftMotor, rightMotor, vibrationV2);
    return SendDualSenseReport(device, rep);
}

inline HRESULT SetDualSenseMuteLed(GiDevice* device, bool on) noexcept
{
    ::DS5::OutputReport rep;
    rep.MuteLight(on ? ::DS5::MuteLed::On : ::DS5::MuteLed::Off);
    return SendDualSenseReport(device, rep);
}

inline HRESULT SetDualSenseMuteLed(GiDevice* device, ::DS5::MuteLed mode) noexcept
{
    ::DS5::OutputReport rep;
    rep.MuteLight(mode);
    return SendDualSenseReport(device, rep);
}

inline HRESULT SetDualSenseMicMute(GiDevice* device, bool muted) noexcept
{
    ::DS5::OutputReport rep;
    rep.MicMute(muted);
    return SendDualSenseReport(device, rep);
}

inline HRESULT SetDualSenseMotorPower(GiDevice* device, uint8_t triggerReduction, uint8_t rumbleReduction) noexcept
{
    ::DS5::OutputReport rep;
    rep.MotorPower(triggerReduction, rumbleReduction);
    return SendDualSenseReport(device, rep);
}

inline HRESULT SetDualSenseTriggerEffect(GiDevice* device, Trigger trigger, const ::DS5::TriggerEffect& effect) noexcept
{
    ::DS5::OutputReport rep;
    rep.TriggerEffectFor(trigger, effect);
    return SendDualSenseReport(device, rep);
}

inline HRESULT SetDualSenseTriggerOff(GiDevice* device, Trigger trigger) noexcept
{
    ::DS5::TriggerEffect e;
    ::DS5::EncodeTriggerOff(e);
    return SetDualSenseTriggerEffect(device, trigger, e);
}

// Legacy simple effects (same bytes as Microsoft's v3 helper).
inline HRESULT SetDualSenseTriggerFeedback(GiDevice* device, Trigger trigger, uint8_t startPosition, uint8_t force) noexcept
{
    ::DS5::TriggerEffect e;
    ::DS5::EncodeSimpleFeedback(e, startPosition, force);
    return SetDualSenseTriggerEffect(device, trigger, e);
}

inline HRESULT SetDualSenseTriggerWeapon(GiDevice* device, Trigger trigger, uint8_t startPosition, uint8_t endPosition, uint8_t strength) noexcept
{
    ::DS5::TriggerEffect e;
    ::DS5::EncodeSimpleWeapon(e, startPosition, endPosition, strength);
    return SetDualSenseTriggerEffect(device, trigger, e);
}

inline HRESULT SetDualSenseTriggerVibration(GiDevice* device, Trigger trigger, uint8_t frequency, uint8_t resistance, uint8_t startPosition) noexcept
{
    ::DS5::TriggerEffect e;
    ::DS5::EncodeSimpleVibration(e, frequency, resistance, startPosition);
    return SetDualSenseTriggerEffect(device, trigger, e);
}

// ---------------------------------------------------------------------------
// Input
// ---------------------------------------------------------------------------

// Reads the latest raw input report and decodes it (battery, touch, raw motion...).
inline bool ReadDualSenseInput(::GameInput::v4::IGameInput* gameInput, GiDevice* device, ::DS5::InputState* out,
                               uint8_t* rawCopy = nullptr, size_t rawCopySize = 0, size_t* rawLen = nullptr) noexcept
{
    if (!gameInput || !device || !out) return false;
    ::GameInput::v4::IGameInputReading* reading = nullptr;
    if (FAILED(gameInput->GetCurrentReading(::GameInput::v4::GameInputKindRawDeviceReport, device, &reading)) || !reading)
    {
        return false;
    }
    bool ok = false;
    GiReport* report = nullptr;
    if (reading->GetRawReport(&report) && report)
    {
        ::GameInput::v4::GameInputRawDeviceReportInfo info = {};
        report->GetReportInfo(&info);
        uint8_t data[512] = {};
        const size_t len = report->GetRawData(sizeof(data), data);
        const bool hasId = len > 0 && data[0] == static_cast<uint8_t>(info.id) && info.id != 0;
        *out = ::DS5::ParseInputReport(data, len, hasId, info.id);
        ok = out->valid;
        if (rawCopy && rawCopySize)
        {
            const size_t c = len < rawCopySize ? len : rawCopySize;
            memcpy(rawCopy, data, c);
            if (rawLen) *rawLen = c;
        }
        report->Release();
    }
    reading->Release();
    return ok;
}

}} // namespace GameInput::DualSense
