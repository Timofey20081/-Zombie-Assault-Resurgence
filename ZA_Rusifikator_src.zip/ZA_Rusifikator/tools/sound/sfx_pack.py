# Builds ZASfx.dat v2: game sounds that ZAPad plays on the DualSense speaker *instead of* the PC speakers.
# Key table: event id (or event id ^ Weapon_Type switch id for reloads) -> run of clip variants.
import json, struct, subprocess, os, re
B = "/mnt/user-data/uploads/Zombie Assault/zombieassault_Data/StreamingAssets/Audio/GeneratedSoundBanks/Windows/"
W = "/home/claude/work/snd/ww2ogg"
RATE = 24000
def bank_media(path):
    b = open(path, 'rb').read(); i = 0; sec = {}
    while i < len(b):
        tag = b[i:i+4]; ln = struct.unpack('<I', b[i+4:i+8])[0]; sec[tag] = b[i+8:i+8+ln]; i += 8 + ln
    out = {}; d = sec.get(b'DIDX', b'')
    for k in range(len(d) // 12):
        mid, off, sz = struct.unpack('<III', d[k*12:k*12+12]); out[mid] = sec[b'DATA'][off:off+sz]
    return out
WANT = {
 "UI": ["Select", "ShowToast", "StrongboxAppear", "StrongboxCollect", "StrongboxCommon_Light1", "StrongboxCommon_Light2", "StrongboxCommon_Light3",
        "StrongboxCommon_Open", "StrongboxCommon_PuckAppear", "StrongboxCommon_PuckLand", "Ability_CooldownComplete", "onFailedRequire",
        "Achievements_Toilet", "TutorialTextIn", "UI_LoadingPanel_In", "UI_LoadingPanel_Out"],
 "Player": ["Ability_Adrenaline", "Ability_Biocleanse", "Ability_Dash", "Ability_DieAnotherDay", "Ability_Haven", "Ability_HoldTheLine",
            "Ability_KineticBurst", "Ability_Medkit", "Ability_Medkit_Heal", "Ability_Orbital_Aim", "Ability_Orbital_Fire",
            "FirstAidKit_Heal", "FirstAidKit_PickUp", "PlayerEquipArmour", "PlayerEquipGun"],
 "Weapon": ["TurretSpawn"],
 "Effects": ["SupplyDrop_Collect", "Cache_Collect"],
}
RELOAD = {"Shotgun": "sfx_shotgun_reload", "Dominator": "sfx_dominator_reload", "Pistol": "GunPistolReload", "Pulsar": "sfx_CM273Pulsar_reload",
          "SMG": "GunARReload", "LMG": "GunARReload", "Shiden": "sfx_shiden_reload", "Galvanizer": "sfx_galvanizer_reload", "AR": "GunARReload",
          "ART25": "sfx_AR_T25_reload", "AR77a": "sfx_AR_77a_reload", "Polaris": "sfx_CM458Polaris_reload", "KR3182": "sfx_KR3182_reload",
          "VoltaicBolter": "sfx_voltaicBolter_reload", "Morlok_Frostbite": "sfx_morlokFrostbite_reload", "Hyperion": "sfx_hyperion_reload",
          "RIA_T9": "sfx_RIA_T9_reload", "Blizzard": "sfx_blizzard_reload", "HVM_MPG": "sfx_HVM_MPG_reload", "SG_T35": "sfx_SG_T35_reload",
          "M450": "sfx_HiksM450_reload", "LBM15": "sfx_LBM15_reload"}
media = {}; names = {}; info = {}
for bk in WANT.keys() | {"Weapon"}:
    info[bk] = json.load(open(B + bk + ".json"))["SoundBanksInfo"]["SoundBanks"][0]
    media.update(bank_media(B + bk + ".bnk"))
    for m in info[bk]["Media"]:
        names[int(m["Id"])] = m["ShortName"].split("\\")[-1]
        if m.get("Location") != "Memory":
            p = B + m.get("Path", m["Id"] + ".wem")
            if os.path.exists(p): media[int(m["Id"])] = open(p, "rb").read()
def pcm_of(mid):
    raw, ogg = f"raw2/{mid}.wem", f"ogg2/{mid}.ogg"
    if not os.path.exists(ogg):
        open(raw, "wb").write(media[mid]); subprocess.run([f"{W}/ww2ogg", raw, "-o", ogg, "--pcb", f"{W}/packed_codebooks_aoTuV_603.bin"], capture_output=True)
    n = names.get(mid, "").lower(); loop = "_lp" in n or "loop" in n
    t = "1.5" if loop else "4.0"
    af = f"afade=t=out:st={float(t)-0.3}:d=0.3,highpass=f=150,loudnorm=I=-14:TP=-1.5:LRA=11"
    return subprocess.run(["ffmpeg", "-v", "error", "-i", ogg, "-t", t, "-af", af, "-ac", "1", "-ar", str(RATE), "-f", "s16le", "-"], capture_output=True).stdout
clips = []; keys = []; log = []
def add(key, mids, label):
    mids = [m for m in mids if m in media]
    if not mids: log.append(f"MISSING {label}"); return
    first = len(clips)
    for m in mids:
        p = pcm_of(m)
        if len(p) < 200: continue
        ad = subprocess.run(["./adpcm"], input=p, capture_output=True).stdout; clips.append((len(p) // 2, ad))
    if len(clips) > first: keys.append((key, first, len(clips) - first)); log.append(f"{label}: {len(clips)-first} [{', '.join(names.get(m,'?') for m in mids)}]")
ids = {}
for bk, evs in WANT.items():
    for e in info[bk]["Events"]:
        if e["Name"] in evs:
            ms = [int(m["Id"]) for m in e.get("MediaRefs", [])]
            ms = [m for m in ms if "loop" not in names.get(m, "").lower() and "_lp" not in names.get(m, "").lower()] or ms
            add(int(e["Id"]), ms, e["Name"]); ids[e["Name"]] = int(e["Id"])
wev = {e["Name"]: int(e["Id"]) for e in info["Weapon"]["Events"]}
sw = {s["Name"]: int(s["Id"]) for s in info["Weapon"]["SwitchGroups"][0]["Switches"]}
byname = {v: k for k, v in names.items()}
for swn, pre in RELOAD.items():
    ms = sorted([m for n, m in byname.items() if n.startswith(pre)], key=lambda m: names[m])
    add(wev["WeaponReload"] ^ sw[swn], ms, f"reload {swn}")
add(wev["WeaponReload"], sorted([m for n, m in byname.items() if n.startswith("GunARReload")]), "reload default")
keys.sort(); assert len({k for k, _, _ in keys}) == len(keys)
out = bytearray(b"ZSPK") + struct.pack("<III", RATE, len(clips), len(keys))
off = 16 + 8 * len(clips) + 8 * len(keys); tab = bytearray(); blob = bytearray()
for n, ad in clips: tab += struct.pack("<II", off + len(blob), n); blob += ad
out += tab + b"".join(struct.pack("<IHH", h, a, c) for h, a, c in keys) + blob
open("ZASfx.dat", "wb").write(out)
print("\n".join(log)); print("clips", len(clips), "keys", len(keys), "bytes", len(out))
json.dump({"events": ids, "weapon": wev, "switch_group": int(info["Weapon"]["SwitchGroups"][0]["Id"])}, open("sfx2_ids.json", "w"))
