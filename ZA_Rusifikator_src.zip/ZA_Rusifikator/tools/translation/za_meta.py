"""Replace the hardcoded dialogue separator " \\ " (speaker name \\ line) in
global-metadata.dat with ": " + soft hyphen (invisible), keeping the size."""
import sys
src, out = sys.argv[1:3]
d = bytearray(open(src, "rb").read())
pat = b"</color> \\\\ "
i = d.find(pat)
assert i >= 0 and d.find(pat, i + 1) < 0, "pattern not found exactly once"
j = i + len(b"</color>")
d[j:j + 4] = b": \xc2\xad"
open(out, "wb").write(d)
print("patched at", j)
