// Wwise event ids (from the game's SoundbanksInfo json)
#pragma once
#include <cstdint>
namespace AKE {
constexpr uint32_t Ability_Adrenaline = 3391951637u;
constexpr uint32_t Ability_Biocleanse = 234133865u;
constexpr uint32_t Ability_Dash = 3427993496u;
constexpr uint32_t Ability_DieAnotherDay = 2896063351u;
constexpr uint32_t Ability_Haven = 1120891796u;
constexpr uint32_t Ability_HoldTheLine = 872125254u;
constexpr uint32_t Ability_KineticBurst = 2115412885u;
constexpr uint32_t Ability_Medkit = 985675626u;
constexpr uint32_t Ability_Orbital_Aim = 3878609677u;
constexpr uint32_t Ability_Orbital_Fire = 2277185346u;
constexpr uint32_t PlayerEquipGun = 1317117548u;
constexpr uint32_t SelfRevive = 3421197684u;
constexpr uint32_t Ability_CooldownComplete = 3888212718u;
constexpr uint32_t TurretSpawn = 1446045036u;
}
