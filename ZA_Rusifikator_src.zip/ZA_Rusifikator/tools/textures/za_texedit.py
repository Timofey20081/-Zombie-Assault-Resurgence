"""Replace English lettering on game textures with Russian.

usage: za_texedit.py spec.py SRC_DIR OUT_DIR [--preview PV_DIR]

spec.py defines EDITS = {"<file stem>": [edit, ...]} where edit is a dict:
  box     : (x0, y0, x1, y1) approx area of the old lettering (texture pixels, y down)
  text    : new text ("\n" for lines); "" = only erase
  font    : key of FONTS or path
  mode    : "light" (text brighter than its background) | "dark" | "alpha" (text lives in alpha)
  align   : "c" | "l" | "r"            (default c)
  fit     : "tight" (fit to old ink bbox) | "box"   (default tight)
  rot     : 0 | 90 | 180 | 270           (text direction, ccw)
  squeeze : min horizontal scale (default 0.55)
  grow    : max upscale of height vs old ink (default 1.0)
  color   : (r, g, b) override
  pad     : erase dilation px (default 2)
  thr     : manual luminance threshold 0..1
  weight  : variable font weight
"""
import sys, os, json, runpy
import numpy as np, cv2
from PIL import Image, ImageDraw, ImageFont

FD = "/home/claude/work/tex/fonts"
GF = "/home/claude/work/fonts/gf/ofl"
FONTS = {
    "oswald": (f"{FD}/Oswald[wght].ttf", 700),
    "oswald5": (f"{FD}/Oswald[wght].ttf", 500),
    "russo": (f"{FD}/RussoOne-Regular.ttf", None),
    "stencil": (f"{FD}/BlackOpsOne-Regular.ttf", None),
    "rubik": (f"{FD}/RubikMonoOne-Regular.ttf", None),
    "jura": (f"{FD}/Jura[wght].ttf", 700),
    "tektur": (None, 700),
    "saira": (None, 700),
}

def find_font(key):
    import glob
    if key == "tektur":
        return glob.glob(f"{GF}/tektur/*.ttf")[0]
    if key == "saira":
        return [f for f in glob.glob(f"{GF}/saira/*.ttf") if "Italic" not in f][0]
    return FONTS[key][0]

def load_font(key, size, weight=None):
    path = find_font(key) if key in FONTS else key
    f = ImageFont.truetype(path, size)
    w = weight or (FONTS.get(key, (None, None))[1])
    if w:
        try:
            axes = f.get_variation_axes()
            vals = []
            for a in axes:
                n = a.get("name", b"")
                n = n.decode() if isinstance(n, bytes) else n
                if n.lower().startswith("weight") or a.get("tag") == "wght":
                    vals.append(max(a["minimum"], min(a["maximum"], w)))
                else:
                    vals.append(a.get("default", a["minimum"]))
            f.set_variation_by_axes(vals)
        except Exception:
            pass
    return f

def render_text(text, key, weight=None, tracking=0.0, line_gap=0.25):
    """Render text big, return float mask cropped to ink (H, W) and per-line info."""
    S = 200
    f = load_font(key, S, weight)
    lines = text.split("\n")
    imgs = []
    for ln in lines:
        if not ln:
            imgs.append(None); continue
        # per-char with tracking
        w = 0; parts = []
        for ch in ln:
            bb = f.getbbox(ch)
            adv = f.getlength(ch)
            parts.append((ch, w)); w += adv + tracking * S
        W = int(w + S); H = int(S * 1.6)
        im = Image.new("L", (W, H), 0); d = ImageDraw.Draw(im)
        for ch, x in parts:
            d.text((x + S * 0.2, S * 0.2), ch, font=f, fill=255)
        a = np.array(im)
        imgs.append(a)
    # common vertical metrics: cap height from "Н"
    capb = f.getbbox("Н")
    cap_top, cap_bot = capb[1] + int(S * 0.2), capb[3] + int(S * 0.2)
    rows = []
    for a in imgs:
        if a is None:
            rows.append(None); continue
        cols = np.where(a.max(0) > 0)[0]
        a = a[:, cols[0]:cols[-1] + 1]
        top = min(cap_top, np.where(a.max(1) > 0)[0][0])
        bot = max(cap_bot, np.where(a.max(1) > 0)[0][-1] + 1)
        rows.append(a[top:bot])
    cap = cap_bot - cap_top
    gap = int(cap * line_gap)
    W = max(r.shape[1] for r in rows if r is not None)
    return rows, W, cap, gap

def compose_lines(rows, W, cap, gap, align):
    hs = [(r.shape[0] if r is not None else cap) for r in rows]
    H = sum(hs) + gap * (len(rows) - 1)
    out = np.zeros((H, W), np.float32); y = 0
    for r, h in zip(rows, hs):
        if r is not None:
            w = r.shape[1]
            x = 0 if align == "l" else (W - w if align == "r" else (W - w) // 2)
            out[y:y + h, x:x + w] = np.maximum(out[y:y + h, x:x + w], r / 255.0)
        y += h + gap
    return out

def lum(rgb):
    return rgb[..., 0] * 0.299 + rgb[..., 1] * 0.587 + rgb[..., 2] * 0.114


def copy_fill(img, rgb, em, x0, y0, e):
    """fill erase box with a nearby patch of the same texture, feathered."""
    H, W = img.shape[:2]
    ys, xs = np.where(em > 0)
    by0, by1, bx0, bx1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
    h, w = by1 - by0, bx1 - bx0
    ay0, ax0 = by0 + y0, bx0 + x0
    full = img[..., :3].astype(np.float32) / 255
    def ring_of(yy, xx):
        r = 3
        top = full[max(0, yy - r):yy, xx:xx + w]; bot = full[yy + h:yy + h + r, xx:xx + w]
        lef = full[yy:yy + h, max(0, xx - r):xx]; rig = full[yy:yy + h, xx + w:xx + w + r]
        return [top, bot, lef, rig]
    tgt = ring_of(ay0, ax0)
    cands = e.get("src") and [tuple(e["src"])] or []
    if not cands:
        for fy in (-2.2, -1.6, -1.1, 0, 1.1, 1.6, 2.2):
            for fx in (-1.6, -1.1, -0.5, 0, 0.5, 1.1, 1.6):
                if abs(fy) < 1.05 and abs(fx) < 1.05: continue
                cands.append((ax0 + int(fx * (w + 3)), ay0 + int(fy * (h + 3))))
    best, bs = None, 1e9
    for cx, cy in cands:
        if cx < 0 or cy < 0 or cx + w > W or cy + h > H: continue
        p = full[cy:cy + h, cx:cx + w]
        L = lum(p)
        gx = np.abs(np.diff(L, axis=1)).mean() + np.abs(np.diff(L, axis=0)).mean()
        rr = ring_of(cy, cx)
        d = 0; n = 0
        for a, b in zip(tgt, rr):
            if a.size and b.size and a.shape == b.shape:
                d += np.abs(a.mean((0, 1)) - b.mean((0, 1))).sum(); n += 1
        sc = d / max(1, n) * 3 + gx * 4 + float(np.percentile(L, 98) - np.percentile(L, 2)) * 3 + np.abs(np.median(p.reshape(-1, 3), 0) - np.median(np.concatenate([t.reshape(-1, 3) for t in tgt if t.size]), 0)).sum() * 6
        if sc < bs: bs, best = sc, (cx, cy)
    out = rgb.copy()
    if best is None: return out
    cx, cy = best
    patch = full[cy:cy + h, cx:cx + w]
    # match mean colour to the ring around the target
    ringc = np.concatenate([t.reshape(-1, 3) for t in tgt if t.size])
    Lr = lum(ringc); lo, hi = np.percentile(Lr, 15), np.percentile(Lr, 60)
    ringc = ringc[(Lr >= lo) & (Lr <= hi)] if ((Lr >= lo) & (Lr <= hi)).sum() > 5 else ringc
    pp = patch.reshape(-1, 3); Lp = lum(pp); plo, phi = np.percentile(Lp, 15), np.percentile(Lp, 60)
    pm = pp[(Lp >= plo) & (Lp <= phi)].mean(0) if ((Lp >= plo) & (Lp <= phi)).sum() > 5 else pp.mean(0)
    patch = np.clip(patch - pm + np.median(ringc, 0), 0, 1)
    f = e.get("feather", 2)
    m = np.ones((h, w), np.float32)
    if f:
        m[:] = 0; m[f:h - f, f:w - f] = 1
        m = cv2.GaussianBlur(m, (2 * f + 1, 2 * f + 1), f)
    m = np.maximum(m, 0.0)
    sub = out[by0:by1, bx0:bx1]
    # inside the strict ink zone take full patch
    out[by0:by1, bx0:bx1] = sub * (1 - m[..., None]) + patch * m[..., None]
    return out

def apply_edit(img, e, log):
    H, W = img.shape[:2]
    bx = e["box"]
    M = e.get("margin", 8)
    x0, y0 = max(0, bx[0] - M), max(0, bx[1] - M); x1, y1 = min(W, bx[2] + M), min(H, bx[3] + M)
    inbox = np.zeros((y1 - y0, x1 - x0), bool)
    inbox[max(0, bx[1]) - y0:min(H, bx[3]) - y0, max(0, bx[0]) - x0:min(W, bx[2]) - x0] = True
    rot = e.get("rot", 0)
    reg = img[y0:y1, x0:x1].astype(np.float32) / 255.0
    rgb, al = reg[..., :3], reg[..., 3]
    mode = e.get("mode", "light")
    if mode == "alpha":
        amax = max(1e-3, float(np.percentile(al[inbox], 99)))
        v = np.clip(al / amax, 0, 1)
    elif mode == "hole":
        amax = max(1e-3, float(np.percentile(al[inbox], 95)))
        v = 1 - np.clip(al / amax, 0, 1)
    else:
        v = lum(rgb)
        if mode == "dark":
            v = 1 - v
    valid = (al > 0.5 if mode not in ("alpha", "hole") and not e.get("anyal") else np.ones_like(al, bool)) & inbox
    if "thr" in e:
        thr = e["thr"] if mode != "dark" else 1 - e["thr"]
    else:
        vv = (v[valid] * 255).astype(np.uint8)
        thr, _ = cv2.threshold(vv.reshape(-1, 1), 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        thr = thr / 255.0
    mask = (v > thr) & valid
    if "keep" in e:  # sub-boxes (relative to texture) to exclude from detection
        for kx0, ky0, kx1, ky1 in e["keep"]:
            mask[max(0, ky0 - y0):max(0, ky1 - y0), max(0, kx0 - x0):max(0, kx1 - x0)] = False
    m8 = mask.astype(np.uint8)
    # drop specks
    n, lab, st, _ = cv2.connectedComponentsWithStats(m8, 8)
    for i in range(1, n):
        if st[i, cv2.CC_STAT_AREA] < e.get("minarea", 3):
            m8[lab == i] = 0
    ys, xs = np.where(m8 > 0)
    if len(xs) == 0:
        log.append(f"  !! no ink in {e['box']}"); return
    # robust ink bbox: big components only, trimmed percentiles
    n, lab, st, _ = cv2.connectedComponentsWithStats(m8, 8)
    tot = max(1, int(m8.sum()))
    big = np.zeros_like(m8)
    for i in range(1, n):
        if st[i, cv2.CC_STAT_AREA] >= max(e.get("minarea", 3), 0.015 * tot):
            big[lab == i] = 1
    ys2, xs2 = np.where(big > 0)
    if len(xs2) == 0: ys2, xs2 = ys, xs
    q = e.get("trim", 0.5)
    ix0, ix1 = int(np.percentile(xs2, q)), int(np.percentile(xs2, 100 - q)) + 1
    iy0, iy1 = int(np.percentile(ys2, q)), int(np.percentile(ys2, 100 - q)) + 1
    # text colour (eroded core)
    core = cv2.erode(m8, np.ones((2, 2), np.uint8)) if m8.sum() > 40 else m8
    if core.sum() == 0: core = m8
    col = np.array(e["color"], np.float32) / 255 if "color" in e else np.median(rgb[core > 0], 0)
    if mode == "hole": col = np.zeros(3, np.float32)
    tal = np.median(al[core > 0]) if mode == "alpha" else None
    ink_var = lum(rgb[core > 0]); ink_mean = max(1e-3, float(np.mean(ink_var)))
    # erase
    pad = e.get("pad", 2)
    em = cv2.dilate(m8, np.ones((2 * pad + 1, 2 * pad + 1), np.uint8))
    if e.get("erase") == "box":
        em = np.zeros_like(m8)
        ex = e.get("ebox")
        if ex:
            em[max(0, ex[1] - y0):ex[3] - y0, max(0, ex[0] - x0):ex[2] - x0] = 1
        else:
            em[max(0, iy0 - pad):iy1 + pad, max(0, ix0 - pad):ix1 + pad] = 1
    reg8 = (reg * 255).astype(np.uint8)
    if mode == "alpha":
        al2 = al.copy(); al2[em > 0] = 0
        new_rgb = rgb.copy()
        new_al = al2
    elif mode == "hole":
        ring = cv2.dilate(em, np.ones((9, 9), np.uint8)) - em
        ring = (ring > 0) & (al > 0.5 * amax)
        bgr = np.ascontiguousarray(reg8[..., :3][..., ::-1])
        ir = e.get("ir", 6)
        new_rgb = cv2.inpaint(bgr, em, ir, cv2.INPAINT_TELEA)[..., ::-1].astype(np.float32) / 255
        new_al = cv2.inpaint(np.ascontiguousarray(reg8[..., 3]), em, ir, cv2.INPAINT_TELEA).astype(np.float32) / 255
    else:
        bgr = np.ascontiguousarray(reg8[..., :3][..., ::-1])
        inp = cv2.inpaint(bgr, em, e.get("ir", 4), cv2.INPAINT_TELEA)[..., ::-1].astype(np.float32) / 255
        if e.get("erase") == "box" and e.get("fill") == "copy":
            inp = copy_fill(img, rgb, em, x0, y0, e)
        elif e.get("erase") == "box" and e.get("fill") != "inpaint":
            ring = cv2.dilate(em, np.ones((7, 7), np.uint8)) - em
            ring &= (~mask).astype(np.uint8)
            if ring.sum() > 10:
                pix = rgb[ring > 0]
                Lp = lum(pix)
                side = e.get("fill", "dark" if mode == "light" else "light")
                if side == "dark":
                    pix = pix[Lp <= np.percentile(Lp, 35)]
                elif side == "light":
                    pix = pix[Lp >= np.percentile(Lp, 65)]
                base = np.median(pix, 0)
                rng = np.random.default_rng(1)
                fillc = pix[rng.integers(0, len(pix), em.sum())]
                fillc = base + (fillc - base) * 0.6
                sm = np.zeros_like(inp); sm[em > 0] = fillc
                sm = cv2.GaussianBlur(sm, (3, 3), 0.7)
                inp = np.where(em[..., None] > 0, sm, inp)
        new_rgb = inp
        new_al = al.copy()
    # render new text
    txt = e.get("text", "")
    if txt:
        rows, RW, cap, gap = render_text(txt, e.get("font", "russo"), e.get("weight"), e.get("tracking", 0.0), e.get("gap", 0.25))
        tm = compose_lines(rows, RW, cap, gap, e.get("align", "c"))
        if e.get("flip"):
            tm = tm[:, ::-1]
        if e.get("vflip"):
            tm = tm[::-1, :]
        if rot:
            tm = np.rot90(tm, rot // 90)
        if e.get("angle"):
            from PIL import Image as _I
            tm = np.array(_I.fromarray((tm * 255).astype(np.uint8)).rotate(e["angle"], expand=True, resample=_I.BICUBIC)).astype(np.float32) / 255
        if e.get("fit", "tight") == "tight":
            bx0, by0, bx1, by1 = ix0, iy0, ix1, iy1
        else:
            bx0, by0, bx1, by1 = bx[0] - x0, bx[1] - y0, bx[2] - x0, bx[3] - y0
        if "inner" in e:   # explicit target box (texture coords)
            bx0, by0, bx1, by1 = e["inner"][0] - x0, e["inner"][1] - y0, e["inner"][2] - x0, e["inner"][3] - y0
        tw, th = bx1 - bx0, by1 - by0
        vertical = rot in (90, 270)
        if e.get("angle"):
            th_, tw_ = tm.shape; s_ = min(th / th_, tw / tw_)
            nh, nw = max(1, round(th_ * s_)), max(1, round(tw_ * s_))
            vertical = None
        th_, tw_ = tm.shape
        # scale so height matches (along text axis), squeeze width if needed
        if vertical is None:
            pass
        elif not vertical:
            s = th / th_ * e.get("grow", 1.0)
            sx = s
            if tm.shape[1] * sx > tw:
                sx = max(tw / tm.shape[1], s * e.get("squeeze", 0.55))
                if tm.shape[1] * sx > tw:
                    s = s * tw / (tm.shape[1] * sx); sx = tw / tm.shape[1]
            elif e.get("stretch"):
                sx = tw / tm.shape[1]
            nh, nw = max(1, round(th_ * s)), max(1, round(tw_ * sx))
        else:
            s = tw / tw_
            sy = s
            if th_ * sy > th:
                sy = max(th / th_, s * e.get("squeeze", 0.55))
                if th_ * sy > th:
                    s = s * th / (th_ * sy); sy = th / th_
            nh, nw = max(1, round(th_ * sy)), max(1, round(tw_ * s))
        small = cv2.resize(tm, (nw, nh), interpolation=cv2.INTER_AREA)
        canvas = np.zeros((y1 - y0, x1 - x0), np.float32)
        al_ = e.get("align", "c")
        cx = bx0 if al_ == "l" else (bx1 - nw if al_ == "r" else bx0 + (tw - nw) // 2)
        cy = by0 + (th - nh) // 2
        cx, cy = int(max(0, min(cx, canvas.shape[1] - nw))), int(max(0, min(cy, canvas.shape[0] - nh)))
        canvas[cy:cy + nh, cx:cx + nw] = small[:canvas.shape[0] - cy, :canvas.shape[1] - cx]
        a = np.clip(canvas, 0, 1)
        if mode == "hole":
            new_al = new_al * (1 - a)
        elif mode == "alpha":
            new_al = np.maximum(new_al, a * tal)
            ink = np.broadcast_to(col, new_rgb.shape)
            new_rgb = np.where(a[..., None] > 0, ink, new_rgb)
        else:
            # grunge: modulate by background variation
            bgL = lum(new_rgb); g = bgL / max(1e-3, float(np.mean(bgL[em > 0])) if (em > 0).any() else 1)
            g = np.clip(1 + (g - 1) * e.get("grunge", 0.8), 0.55, 1.35)
            ink = np.clip(col[None, None, :] * g[..., None], 0, 1)
            new_rgb = new_rgb * (1 - a[..., None]) + ink * a[..., None]
    out = np.dstack([new_rgb, new_al])
    img[y0:y1, x0:x1] = np.clip(out * 255 + 0.5, 0, 255).astype(np.uint8)
    log.append(f"  {txt!r:30} box={e['box']} ink=({ix0+x0},{iy0+y0},{ix1+x0},{iy1+y0}) col={tuple((col*255).astype(int))}")

def main():
    spec_p, src, out = sys.argv[1:4]
    pv = sys.argv[sys.argv.index("--preview") + 1] if "--preview" in sys.argv else None
    only = sys.argv[sys.argv.index("--only") + 1] if "--only" in sys.argv else None
    spec = runpy.run_path(spec_p)["EDITS"]
    os.makedirs(out, exist_ok=True)
    for stem, edits in spec.items():
        if only and only not in stem: continue
        im = np.array(Image.open(f"{src}/{stem}.png").convert("RGBA"))
        log = [stem]
        for e in edits:
            apply_edit(im, e, log)
        print("\n".join(log))
        Image.fromarray(im).save(f"{out}/{stem}.png")
        if pv:
            os.makedirs(pv, exist_ok=True)
            a = Image.fromarray(im); bg = Image.new("RGBA", a.size, (70, 70, 80, 255)); bg.alpha_composite(a)
            o = Image.open(f"{src}/{stem}.png").convert("RGBA"); bo = Image.new("RGBA", o.size, (70, 70, 80, 255)); bo.alpha_composite(o)
            k = max(1, min(4, 900 // max(a.size)))
            both = Image.new("RGB", (a.width * 2 * k + 8, a.height * k), (255, 0, 255))
            both.paste(bo.convert("RGB").resize((a.width * k, a.height * k), Image.LANCZOS), (0, 0))
            both.paste(bg.convert("RGB").resize((a.width * k, a.height * k), Image.LANCZOS), (a.width * k + 8, 0))
            both.save(f"{pv}/{stem}.jpg", quality=90)

if __name__ == "__main__":
    main()
