# Русификатор «Зомби-штурм: Пробуждение» (Zombie Assault: Resurgence)

by **MeT1oR & Tianku**

Исходный код установщиков русификатора, мода геймпада ZAPad и инструментов сборки перевода.
Для Steam-версии игры с обновлением от 13 ноября 2026.

Готовые установщики: [OneDrive](https://1drv.ms/f/c/61232d16c32d573a/IgAh1qG9JMrYSZgvXQg0wy5RAWJ5Gb9upStFmZeVO7wCMVQ?e=Ov2laQ) · [Nexus Mods](https://www.nexusmods.com/mods/40?game_id=10843&tab=description)

## Состав

| Папка | Что это |
|---|---|
| `installer/full` | Полный установщик 4.0 (WPF, .NET Framework 4.8): перевод на выбор, логотипы, надписи на текстурах, мод геймпада, DLAA, Discord, ASUS Aura |
| `installer/lite` | Lite-установщик 1.0 (WinForms): только перевод текста и шрифты |
| `installer/linux` | Lite 1.0 для Linux / Steam Deck (bash + python3, игра через Proton) |
| `mod/src` | ZAPad: `version.dll`-прокси для игры. DualSense/Xbox (триггеры, HD-вибрация, динамик, подсветка, тачпад, гироскоп), NVIDIA DLAA, Discord, ASUS Aura |
| `tools/translation` | Сборка вариантов перевода и бандлов локализации, патчи `resources.assets` и `global-metadata.dat` |
| `tools/translation/tr` | Сам перевод: `ru_*` (базовый слой), `lit_*`, `adapt_*` (авторская редакция) |
| `tools/textures` | Русские надписи на текстурах оружия, брони и уровней |
| `tools/sound` | Пакеты звуков для динамика DualSense (`ZASpk.dat`, `ZASfx.dat`) |

## Чего нет в репозитории

Файлы игры и всё, что из них получено, сюда не входят: бандлы, патчи `.zap`, звуки и картинки из игры, `payload.zip`.
Их собирают инструментами из `tools/` из своей копии игры. Также не входят:

- `mod/src/minhook/`: [MinHook](https://github.com/TsudaKageyu/minhook) (BSD-2);
- `mod/src/ngx/`: заголовки и `nvsdk_ngx_s.lib` из [NVIDIA DLSS SDK](https://github.com/NVIDIA/DLSS), `nvngx_dlss.dll` оттуда же;
- `mod/src/Unity/`: `IUnityInterface.h`, `IUnityGraphics.h`, `IUnityGraphicsD3D12.h` из папки `PluginAPI` редактора Unity;
- `GameInput.h`: NuGet-пакет Microsoft.GameInput v4;
- `installer/*/assets/`: иконки, баннер, шрифт [Inter](https://github.com/rsms/inter) (OFL), гифки, звуки установщика, `payload.zip`.

## Сборка

**Мод (Windows, Visual Studio 2022+):** в «x64 Native Tools Command Prompt» запустить `mod\build.bat`.
Результат `ZAPad_version.dll` кладётся в папку игры как `version.dll`.

**Полный установщик и Lite (Windows):** положить ресурсы в `assets\` рядом с `.csproj` и выполнить

```
dotnet build -c Release
```

**Linux Lite:** положить в `installer/linux/payload/` файлы `english/<бандл>`, `portuguese/<бандл>`, `resources.zap`, `metadata.zap` и запустить `./build.sh`.

## Сборка перевода

Скрипты на Python 3 (UnityPy, lz4, Pillow, numpy, pymorphy3). Пути к рабочей папке заданы в начале скриптов (`W = ...`), поправьте под себя.

1. `za_build.py check`: проверка перевода (плейсхолдеры, теги, разделители, переносы).
2. `za_variants.py OUT`: четыре варианта (авторский/точный × русские/английские названия) в XML.
3. `za_ui.py`: варианты «только интерфейс».
4. `za_bundles.py`: запись XML в бандлы локализации.
5. `za_meta.py` и `za_redacted.py`: разделитель в диалогах и шрифт засекреченного текста.
6. `za_mkzap.py orig new out.zap`: бинарный патч формата ZAP1, который применяют установщики.

Установщики сверяют SHA-256 каждого файла игры перед заменой, хранят оригинал рядом (`*.orig`) и возвращают его при удалении.
После обновления игры нужно обновить имена файлов и контрольные суммы в `Installer.cs` (и в `install.sh`) и пересобрать патчи.

## Благодарности

- Фото геймпадов в гифках: Evan-Amos, Wikimedia Commons, общественное достояние.
- `DualSenseHelper.h`: порт помощника DualSense от Microsoft на GameInput v4 (MIT).

Zombie Assault: Resurgence принадлежит Ninja Kiwi. Это неофициальный фанатский проект.
