// Установщик русификатора «Зомби-штурм: Пробуждение» (Zombie Assault: Resurgence) — MeT1oR & Tianku
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

namespace ZaSetup
{
    public enum Kind { Info, Ok, Warn, Error, Head }

    // ------------------------------------------------------------------ logic
    public class Installer
    {
        public const string Version = "1.0";
        public const string GameBuild = "обновлением от 13 ноября 2026";
        const string LOC = "localization_assets_all_fc03e8144bbdc66b764b78538acd9411.bundle";
        static readonly string[] LOC_OLD = { "localization_assets_all_83cba2f82f55e0748cff4e64852c0669.bundle", "localization_assets_all_c21dd4a971da50c093142a48dc7a25c8.bundle", "localization_assets_all_2bc6d9f6e4d49681f9d6f649d4cde85b.bundle" };
        const string UI = "ui_textures_assets_res_medium_d043f95000830658fb56a4629bcfde8d.bundle";

        public Action<string, Kind> Log = delegate { };
        public Action<int> Progress = delegate { };
        public string Game;
        public string Lang = "english";
        public bool Logos = true;
        public bool Voice = true;
        public bool VoiceTest = false;
        public Func<Stream> OpenPayload;

        class Item { public string Name, Rel, Orig, Src, Patch, New; public bool Required, Optional; }

        static string P(params string[] parts) { return Path.Combine(parts); }
        string Data { get { return P(Game, "zombieassault_Data"); } }
        string AA { get { return P(Data, "StreamingAssets", "aa", "StandaloneWindows64"); } }
        string Snd { get { return P(Data, "StreamingAssets", "Audio", "GeneratedSoundBanks", "Windows", "English(US)"); } }
        public string ToolDir { get { return P(Game, "ZA_Rusifikator"); } }

        static readonly Dictionary<string, string> Banks = new Dictionary<string, string> {
            { "Dialogue", "50EAEF9022CBD38808D3FCC22A103FC9D12569780519CB55320DB948D24BFD46" },
            { "Dialogue_Tutorial", "58ABB8A4CC511ECEFED9470CD030DFC017C7EF712B6AE6DE9A18F93C347CAB97" },
            { "Dialogue_Operations", "2246B9396514F793B46050A632AB27B29BE92E365270F82AF804EF15F728EB73" } };

        List<Item> Items()
        {
            var l = new List<Item>();
            l.Add(new Item { Name = "Тексты и шрифт", Rel = P("StreamingAssets", "aa", "StandaloneWindows64", LOC), Orig = "D4DC0CD935001E3389DEFFF281A539C729F43E77AB908CE98023291FB92E56EC", Src = Lang + "/" + LOC, Required = true });
            l.Add(new Item { Name = "Шрифт засекреченного текста", Rel = "resources.assets", Orig = "D497A04B8F529F4A93554C97D5C42A3A190E642BBC07583D5237380FEF80E67F", Patch = "resources.zap", New = "96CE4FCDFBD31C874F0FA457C878C245581353D0E6A8D104AE85C7E673F21141" });
            l.Add(new Item { Name = "Разделитель в диалогах", Rel = P("il2cpp_data", "Metadata", "global-metadata.dat"), Orig = "99B59F675D7250668698CE51D49614B065C8FD9F2A8EA1E282C1B6517DDA76A4", Patch = "metadata.zap", New = "3451BAFF11B709A2B67024C30B23144EEED90B8F8117AC628089751C3D1FD380" });
            l.Add(new Item { Name = "Логотипы компаний", Optional = true, Rel = P("StreamingAssets", "aa", "StandaloneWindows64", UI), Orig = "0C4C41366EE5B5CAB30DE761B0D76E1E421A4102095D2A45BB1D11F9D49EFFEE", Patch = "logos.zap", New = "49A853B47A12551CAD7C817405237B0C47F8C4944E4FDA0BB88845116F1F28C8" });
            return l;
        }

        public static string Sha(string p)
        {
            if (!File.Exists(p)) return "";
            using (var s = File.OpenRead(p)) using (var h = SHA256.Create())
                return BitConverter.ToString(h.ComputeHash(s)).Replace("-", "");
        }

        // ---------- game detection
        public static bool IsGame(string p) { return !string.IsNullOrEmpty(p) && File.Exists(P(p, "zombieassault.exe")); }

        public static string FindGame(string near)
        {
            var c = new List<string>();
            if (near != null) { c.Add(near); try { c.Add(Path.GetDirectoryName(near)); } catch { } }
            var steam = new List<string>();
            foreach (var kv in new[] { new[] { "HKCU", @"Software\Valve\Steam", "SteamPath" }, new[] { "HKLM", @"SOFTWARE\WOW6432Node\Valve\Steam", "InstallPath" }, new[] { "HKLM", @"SOFTWARE\Valve\Steam", "InstallPath" } })
            {
                try
                {
                    var root = kv[0] == "HKCU" ? Microsoft.Win32.Registry.CurrentUser : Microsoft.Win32.Registry.LocalMachine;
                    using (var k = root.OpenSubKey(kv[1]))
                        if (k != null && k.GetValue(kv[2]) != null) steam.Add(k.GetValue(kv[2]).ToString().Replace('/', '\\'));
                }
                catch { }
            }
            try { steam.Add(P(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Steam")); } catch { }
            var libs = new List<string>();
            foreach (var s in steam)
            {
                libs.Add(s);
                try
                {
                    var vdf = P(s, "steamapps", "libraryfolders.vdf");
                    if (File.Exists(vdf))
                        foreach (Match m in Regex.Matches(File.ReadAllText(vdf), "\"path\"\\s+\"([^\"]+)\""))
                            libs.Add(m.Groups[1].Value.Replace(@"\\", @"\"));
                }
                catch { }
            }
            try
            {
                foreach (var d in DriveInfo.GetDrives())
                {
                    if (d.DriveType != DriveType.Fixed) continue;
                    foreach (var sub in new[] { "SteamLibrary", "Steam", P("Games", "Steam"), P("Games", "SteamLibrary"), P("Program Files (x86)", "Steam") })
                        libs.Add(P(d.RootDirectory.FullName, sub));
                }
            }
            catch { }
            foreach (var l in libs.Distinct()) c.Add(P(l, "steamapps", "common", "Zombie Assault"));
            foreach (var p in c) if (IsGame(p)) return Path.GetFullPath(p);
            return null;
        }

        // ---------- helpers
        ZipArchive zip;
        ZipArchiveEntry Entry(string name) { return zip.GetEntry(name.Replace('\\', '/')); }

        static void Unprotect(string p) { if (File.Exists(p)) File.SetAttributes(p, FileAttributes.Normal); }
        static void CopyOver(string src, string dst) { Unprotect(dst); File.Copy(src, dst, true); }

        void ExtractTo(ZipArchiveEntry e, string dst)
        {
            Unprotect(dst);
            using (var s = e.Open()) using (var f = File.Create(dst)) s.CopyTo(f);
        }

        void ApplyPatch(string orig, ZipArchiveEntry patch, string outp)
        {
            byte[] o = File.ReadAllBytes(orig);
            using (var ps = patch.Open()) using (var ms = new MemoryStream())
            {
                ps.CopyTo(ms); ms.Position = 0;
                var br = new BinaryReader(ms);
                if (Encoding.ASCII.GetString(br.ReadBytes(4)) != "ZAP1") throw new Exception("повреждённый патч");
                long size = br.ReadInt64(); int n = br.ReadInt32();
                Unprotect(outp);
                using (var fs = File.Create(outp))
                {
                    for (int k = 0; k < n; k++)
                    {
                        if (br.ReadByte() == 0) { long off = br.ReadInt64(); int len = br.ReadInt32(); fs.Write(o, (int)off, len); }
                        else { int len = br.ReadInt32(); byte[] b = br.ReadBytes(len); fs.Write(b, 0, len); }
                    }
                }
                if (new FileInfo(outp).Length != size) throw new Exception("размер не совпал");
            }
        }

        bool RestoreIfOrig(string t, string origSha)
        {
            string bak = t + ".orig";
            if (Sha(bak) == origSha) { CopyOver(bak, t); Unprotect(bak); File.Delete(bak); return true; }
            return Sha(t) == origSha;
        }

        // ---------- install / uninstall
        public bool Install()
        {
            using (var ps = OpenPayload())
            using (zip = new ZipArchive(ps, ZipArchiveMode.Read))
            {
                CleanupStale();
                var items = Items();
                int fail = 0, step = 0, steps = items.Count + 2;
                foreach (var it in items)
                {
                    Progress(++step * 100 / steps);
                    string t = P(Data, it.Rel), bak = t + ".orig";
                    if (it.Optional && !Logos)
                    {
                        RestoreIfOrig(t, it.Orig);
                        Log(it.Name + ": пропущено (оригинал)", Kind.Info);
                        continue;
                    }
                    if (!File.Exists(t)) { Log(it.Name + ": файл игры не найден", Kind.Warn); if (it.Required) fail++; continue; }
                    if (Sha(t) == it.Orig) { CopyOver(t, bak); }
                    else if (Sha(bak) != it.Orig)
                    {
                        Log(it.Name + ": файл игры другой версии (игра обновилась?), пропускаю", Kind.Warn);
                        if (it.Required) fail++;
                        continue;
                    }
                    bool ok;
                    try
                    {
                        if (it.Patch != null) { ApplyPatch(bak, Entry(it.Patch), t); ok = Sha(t) == it.New; }
                        else
                        {
                            var e = Entry(it.Src);
                            ExtractTo(e, t);
                            string want; using (var s = e.Open()) using (var h = SHA256.Create()) want = BitConverter.ToString(h.ComputeHash(s)).Replace("-", "");
                            ok = Sha(t) == want;
                        }
                    }
                    catch (Exception ex) { ok = false; Log("   " + ex.Message, Kind.Error); }
                    if (ok) Log(it.Name + ": установлено", Kind.Ok);
                    else
                    {
                        CopyOver(bak, t);
                        Log(it.Name + ": не удалось, возвращён оригинал", Kind.Error);
                        if (it.Required) fail++;
                    }
                }
                Progress(100);
                return fail == 0;
            }
        }

        // voice kit -> <game>\ZA_Rusifikator\voice (не трогаем уже записанное и отмеченное)
        void UnpackTools()
        {
            int n = 0;
            foreach (var e in zip.Entries)
            {
                if (!e.FullName.StartsWith("voice/") || e.FullName.EndsWith("/")) continue;
                string dst = P(ToolDir, e.FullName.Replace('/', Path.DirectorySeparatorChar));
                bool always = e.FullName == "voice/media.tsv";
                if (File.Exists(dst) && !always) continue;
                Directory.CreateDirectory(Path.GetDirectoryName(dst));
                ExtractTo(e, dst); if (!always) n++;
            }
            if (n > 0) Log("Набор для озвучки распакован: " + P("ZA_Rusifikator", "voice"), Kind.Info);
        }

        public int CountRecordings()
        {
            string rec = P(ToolDir, "voice", "Записи");
            return Directory.Exists(rec) ? Directory.GetFiles(rec, "*.wav", SearchOption.AllDirectories).Length : 0;
        }

        void BuildVoice()
        {
            var recs = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            string recDir = P(ToolDir, "voice", "Записи");
            if (Directory.Exists(recDir))
                foreach (var f in Directory.GetFiles(recDir, "*.wav", SearchOption.AllDirectories)) recs[Path.GetFileName(f)] = f;
            var map = new Dictionary<string, Dictionary<uint, string>>();
            var known = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            string tsv = P(ToolDir, "voice", "media.tsv");
            if (File.Exists(tsv))
                foreach (var line in File.ReadAllLines(tsv, Encoding.UTF8))
                {
                    var f = line.Split('\t'); if (f.Length < 4) continue;
                    known.Add(f[3]);
                    if (!map.ContainsKey(f[0])) map[f[0]] = new Dictionary<uint, string>();
                    if (VoiceTest) map[f[0]][uint.Parse(f[1])] = "<test>";
                    else if (Voice && recs.ContainsKey(f[3])) map[f[0]][uint.Parse(f[1])] = recs[f[3]];
                }
            var unknown = recs.Keys.Where(k => !known.Contains(k)).ToList();
            if (Voice && unknown.Count > 0) Log("Озвучка: файлы с неизвестными именами пропущены: " + string.Join(", ", unknown.Take(10)) + (unknown.Count > 10 ? "…" : ""), Kind.Warn);
            int total = map.Values.Sum(d => d.Count);
            if (total == 0)
            {
                foreach (var b in Banks) RestoreIfOrig(P(Snd, b.Key + ".bnk"), b.Value);
                Log(Voice ? "Озвучка: записей пока нет, остаётся английская" : "Озвучка: оригинальная (английская)", Kind.Info);
                return;
            }
            int ok = 0, err = 0;
            var report = new List<string>();
            try
            {
                foreach (var b in Banks)
                {
                    string t = P(Snd, b.Key + ".bnk"), bak = t + ".orig";
                    if (Sha(t) == b.Value) CopyOver(t, bak);
                    if (Sha(bak) != b.Value) { Log("Озвучка: " + b.Key + ".bnk другой версии, пропускаю", Kind.Warn); continue; }
                    Dictionary<uint, string> d;
                    if (!map.TryGetValue(b.Key, out d)) d = new Dictionary<uint, string>();
                    Log("Озвучка: собираю " + b.Key + " (" + d.Count + " реплик)…", Kind.Info);
                    string tmp = t + ".new";
                    var r = ZaVoice.Bank.Build(bak, tmp, d, 32000, true);
                    Unprotect(t); File.Copy(tmp, t, true); File.Delete(tmp);
                    foreach (var x in r) { report.Add(b.Key + "|" + x); if (x.StartsWith("OK")) ok++; else err++; }
                }
                File.WriteAllLines(P(ToolDir, "voice", "отчёт_сборки.txt"), report, new UTF8Encoding(true));
                if (VoiceTest) Log("ТЕСТ озвучки: все " + ok + " реплик заменены сигналом «бип-бип». Проверьте в игре и потом нажмите «Установить».", Kind.Head);
                else Log("Озвучка: озвучено " + ok + " из " + known.Count + " реплик", Kind.Ok);
                if (err > 0) Log("Озвучка: ошибок " + err + ", подробности в voice\\отчёт_сборки.txt", Kind.Warn);
            }
            catch (Exception ex)
            {
                foreach (var b in Banks) { string t = P(Snd, b.Key + ".bnk"); if (Sha(t + ".orig") == b.Value) CopyOver(t + ".orig", t); }
                Log("Озвучка не собрана: " + ex.Message, Kind.Error);
            }
        }

        // остатки прошлых версий игры: резервная копия бандла перевода со старым именем
        void CleanupStale()
        {
            try
            {
                foreach (var n in LOC_OLD)
                {
                    string old = P(AA, n);
                    if (!File.Exists(old) && File.Exists(old + ".orig")) { Unprotect(old + ".orig"); File.Delete(old + ".orig"); }
                }
            }
            catch { }
        }

        public void Uninstall()
        {
            CleanupStale();
            int i = 0; var items = Items();
            foreach (var it in items)
            {
                Progress(++i * 100 / (items.Count + 1));
                string t = P(Data, it.Rel);
                if (RestoreIfOrig(t, it.Orig)) Log(it.Name + ": оригинал восстановлен", Kind.Ok);
                else Log(it.Name + ": резервной копии нет, восстановите через Steam (Проверить целостность файлов)", Kind.Warn);
            }
            foreach (var b in Banks) RestoreIfOrig(P(Snd, b.Key + ".bnk"), b.Value);
            Log("Озвучка: оригинал восстановлен", Kind.Ok);
            Progress(100);
        }
    }

}
