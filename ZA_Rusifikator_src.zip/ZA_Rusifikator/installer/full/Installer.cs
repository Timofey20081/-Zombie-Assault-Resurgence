// Установщик русификатора «Зомби-штурм: Пробуждение» (Zombie Assault: Resurgence) — MeT1oR & Tianku
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

namespace ZaSetup
{
    public enum Kind { Info, Ok, Warn, Error, Head }

    // ------------------------------------------------------------------ logic
    public class Installer
    {
        public const string Version = "4.0";
        public const string GameBuild = "обновлением от 13 ноября 2026";
        const string LOC = "localization_assets_all_fc03e8144bbdc66b764b78538acd9411.bundle";
        static readonly string[] LOC_OLD = { "weapons_lmg1_frontend_assets_all_655c2c1180398df1c6ce9225f20ed431.bundle", "weapons_pistol1_frontend_assets_all_633014785d1edd7f56df0ba9350cff9c.bundle", "weapons_power1_frontend_assets_all_ce4c741e9d91a96198dbde780d08256a.bundle", "weapons_smg1_frontend_assets_all_e3926a6afea3294d5848506591265053.bundle", "weapons_sniper1_frontend_assets_all_646f19c31d0982b2cc510c08d641b20c.bundle", "localization_assets_all_83cba2f82f55e0748cff4e64852c0669.bundle", "localization_assets_all_c21dd4a971da50c093142a48dc7a25c8.bundle", "localization_assets_all_2bc6d9f6e4d49681f9d6f649d4cde85b.bundle" };
        const string UI = "ui_textures_assets_res_medium_d043f95000830658fb56a4629bcfde8d.bundle";
        const string LVL = "level_shared_assets_all_ea49100409ca94573f4b99950395e9b5.bundle";

        public Action<string, Kind> Log = delegate { };
        public Action<int> Progress = delegate { };
        public string Game;
        public string Lang = "english";
        public string Variant = "author_ru";
        public bool Logos = true;
        public bool Textures = true;
        public string Pad = "";
        public string Kbd = "";   // "", "aura", "windows"
        public bool Discord = false;
        public bool Dlaa = false;
        public bool Voice = true;
        public bool VoiceTest = false;
        public Func<Stream> OpenPayload;

        class Item { public string Name, Rel, Orig, Src, Patch, New, Flag; public bool Required, Optional; }

        static string P(params string[] parts) { return Path.Combine(parts); }
        string Data { get { return P(Game, "zombieassault_Data"); } }
        string AA { get { return P(Data, "StreamingAssets", "aa", "StandaloneWindows64"); } }
        string Snd { get { return P(Data, "StreamingAssets", "Audio", "GeneratedSoundBanks", "Windows", "English(US)"); } }
        public string ToolDir { get { return P(Game, "ZA_Rusifikator"); } }

        static readonly Dictionary<string, string> Banks = new Dictionary<string, string> {
            { "Dialogue", "50EAEF9022CBD38808D3FCC22A103FC9D12569780519CB55320DB948D24BFD46" },
            { "Dialogue_Tutorial", "58ABB8A4CC511ECEFED9470CD030DFC017C7EF712B6AE6DE9A18F93C347CAB97" },
            { "Dialogue_Operations", "2246B9396514F793B46050A632AB27B29BE92E365270F82AF804EF15F728EB73" } };

        List<Item> Items()
        {
            var l = new List<Item>();
            l.Add(new Item { Name = "Тексты и шрифт", Rel = P("StreamingAssets", "aa", "StandaloneWindows64", LOC), Orig = "D4DC0CD935001E3389DEFFF281A539C729F43E77AB908CE98023291FB92E56EC", Src = Variant + "/" + Lang + "/" + LOC, Required = true });
            l.Add(new Item { Name = "Шрифт засекреченного текста", Rel = "resources.assets", Orig = "D497A04B8F529F4A93554C97D5C42A3A190E642BBC07583D5237380FEF80E67F", Patch = "resources.zap", New = "96CE4FCDFBD31C874F0FA457C878C245581353D0E6A8D104AE85C7E673F21141" });
            l.Add(new Item { Name = "Разделитель в диалогах", Rel = P("il2cpp_data", "Metadata", "global-metadata.dat"), Orig = "99B59F675D7250668698CE51D49614B065C8FD9F2A8EA1E282C1B6517DDA76A4", Patch = "metadata.zap", New = "3451BAFF11B709A2B67024C30B23144EEED90B8F8117AC628089751C3D1FD380" });
            l.Add(new Item { Name = "Надписи на текстурах в игре", Optional = true, Flag = "tex", Rel = P("StreamingAssets", "aa", "StandaloneWindows64", LVL), Orig = "77A8F539F778BDEECB5624089F8D7DDE884949810E6E3EA6F1920B036583C048", Patch = "textures.zap", New = "BF86DFB9482903EA32CB5D115E63B745429713CC476AE0A6F9E256006EA595A4" });
            l.Add(new Item { Name = "Надписи на снаряжении", Optional = true, Flag = "tex", Rel = P("StreamingAssets", "aa", "StandaloneWindows64", "armour_hvm1_frontend_assets_all_799c6e54877fd154d74ac8c9d8972780.bundle"), Orig = "31743174D9EA93EC2A7BAF93240EA2F3803207DC51A90CABD1CBA709AF29CAD7", Patch = "gear/armour_hvm1_frontend.zap", New = "EF9169428C9E98512C9DEA9370E1C01ABB78B385FCD454FAE1A2242258D3432B" });
            l.Add(new Item { Name = "Надписи на снаряжении", Optional = true, Flag = "tex", Rel = P("StreamingAssets", "aa", "StandaloneWindows64", "armour_hvm1_ingame_assets_all_8f9e2e7c9b4b25b6f0a706800fa759f2.bundle"), Orig = "80C6B4BCBB6BD0FDEF08F711CCCEC644FF5ED1E92BCD70B9AEB7022DE13EC6B9", Patch = "gear/armour_hvm1_ingame.zap", New = "D49E133349BC5528491B0A2FC2907D42348E84C02843DE0407440648EEEF9091" });
            l.Add(new Item { Name = "Надписи на снаряжении", Optional = true, Flag = "tex", Rel = P("StreamingAssets", "aa", "StandaloneWindows64", "armour_ronson1_frontend_assets_all_fed4e72829c5439d9801910fc4f85000.bundle"), Orig = "D59F56C9AC666977AEF4A207AC024A8110165CF84C38422EFE3771EBDB012AF6", Patch = "gear/armour_ronson1_frontend.zap", New = "91BDFE668B4F06500F773028E2D63D53416B7824FA1A1EBB1F7E8E7E87C51520" });
            l.Add(new Item { Name = "Надписи на снаряжении", Optional = true, Flag = "tex", Rel = P("StreamingAssets", "aa", "StandaloneWindows64", "armour_ronson1_ingame_assets_all_cc00e986939fb2071ce221bf27b2c8b9.bundle"), Orig = "5E5CEF6DB5C986D91BA0FA8A1183DC2991A3708816F8A48AAB226A67A7415DA8", Patch = "gear/armour_ronson1_ingame.zap", New = "68DCC78D6274673DFB7F7541108FD626EF81D5D8EFB9E8FF08D3D9A16CC58CBA" });
            l.Add(new Item { Name = "Надписи на снаряжении", Optional = true, Flag = "tex", Rel = P("StreamingAssets", "aa", "StandaloneWindows64", "weapons_ar1_frontend_assets_all_5f2a9ba9b3c0349d813ba6320f11826f.bundle"), Orig = "53D3555BE37162BBD410E8A5B053D4F04B61C9F9CAFEDAF2BADACF55836DC4EA", Patch = "gear/weapons_ar1_frontend.zap", New = "AB684C144198D172DCB433808A0A9F01E25A7B9D9041685EB712D78E23E92B5C" });
            l.Add(new Item { Name = "Надписи на снаряжении", Optional = true, Flag = "tex", Rel = P("StreamingAssets", "aa", "StandaloneWindows64", "weapons_ar1_ingame_assets_all_28855daf1d70733bcbfcf3c6ad13f419.bundle"), Orig = "1D99AA0423FE024A921AE3628675307509A28008B230A80E6039D0C8311D00E1", Patch = "gear/weapons_ar1_ingame.zap", New = "8FAFC22CABEA65B36AAB41C7EAD6C5236D709FF8A202D2EEDA71A6F11FE57B67" });
            l.Add(new Item { Name = "Надписи на снаряжении", Optional = true, Flag = "tex", Rel = P("StreamingAssets", "aa", "StandaloneWindows64", "weapons_grenade1_frontend_assets_all_79a3d09c24ce29bdc9384a37a696152a.bundle"), Orig = "9857404E5B2B615315CB3BE4EF4E6A3E7FE04639C64412026B3EF849DF6DFBCE", Patch = "gear/weapons_grenade1_frontend.zap", New = "ECFFE7BBBF4358DEE10A023B2B6F2AAE6258DF18DB5B2B13982F0D5B51E4AC36" });
            l.Add(new Item { Name = "Надписи на снаряжении", Optional = true, Flag = "tex", Rel = P("StreamingAssets", "aa", "StandaloneWindows64", "weapons_lmg1_frontend_assets_all_d1992a743ae6118fe73fe258e1b1ba73.bundle"), Orig = "8C84977F6B79A3C06345BCD8FB8872A8E253E8B445147A035FB2D697E59F30CB", Patch = "gear/weapons_lmg1_frontend.zap", New = "44651AB197E849F2BB50824A2C4EFE86B7BF3C2FBAED636B1F5817A9C83FDF8F" });
            l.Add(new Item { Name = "Надписи на снаряжении", Optional = true, Flag = "tex", Rel = P("StreamingAssets", "aa", "StandaloneWindows64", "weapons_lmg1_ingame_assets_all_8d8e54f71a636567ab7754bbf982b46f.bundle"), Orig = "D1F27E2A770158206554E70142CAB758C655071DEC55E03F8DAFC54038D6793B", Patch = "gear/weapons_lmg1_ingame.zap", New = "FA6E4549906F7D196220E1E8831F655660D1F3F6166C90827AE333D3A4EB4F1E" });
            l.Add(new Item { Name = "Надписи на снаряжении", Optional = true, Flag = "tex", Rel = P("StreamingAssets", "aa", "StandaloneWindows64", "weapons_pistol1_frontend_assets_all_21f725a9caf76b6e2669e02a6607cd7d.bundle"), Orig = "AAC7732B0B6280CF1934DC8FC107913D47F0257ADB187E36A8B561926E8CF22A", Patch = "gear/weapons_pistol1_frontend.zap", New = "A85D781428BE49EEE1AEAA57F7EBFC735022E11CF3A1A543EB50D83F6C38166C" });
            l.Add(new Item { Name = "Надписи на снаряжении", Optional = true, Flag = "tex", Rel = P("StreamingAssets", "aa", "StandaloneWindows64", "weapons_pistol1_ingame_assets_all_2eef28ad9d603be968d5dc72a197e5f0.bundle"), Orig = "FC527E65BC565D1E61374A57D7CEED13DA6D8F89ED7FDF739D3EF4B50C3FA4A2", Patch = "gear/weapons_pistol1_ingame.zap", New = "6D7D2EF26AF2109F2A6CCD7FD32ABDD98096FB8E9209A6E4F6EDCD697B6617FA" });
            l.Add(new Item { Name = "Надписи на снаряжении", Optional = true, Flag = "tex", Rel = P("StreamingAssets", "aa", "StandaloneWindows64", "weapons_power1_frontend_assets_all_81fc86df86c73ac2ba632f29a25b3d41.bundle"), Orig = "B29F0737433B251BD3ABF17008DFF60D750F204EE7E0F8149DF0BFCBE35F565C", Patch = "gear/weapons_power1_frontend.zap", New = "2B29EBFBB62F455813671807F485682952278BBE4E3BC8EB2FAE42A815D6483A" });
            l.Add(new Item { Name = "Надписи на снаряжении", Optional = true, Flag = "tex", Rel = P("StreamingAssets", "aa", "StandaloneWindows64", "weapons_power1_ingame_assets_all_78d188d113317b14c61e61b53889e072.bundle"), Orig = "0A23341782F0F338552D3D4D324ADD278B9892061EDA51ACB7592774D6369B16", Patch = "gear/weapons_power1_ingame.zap", New = "929B8DB10531CD9614395A9AA9762324D9582603D3B3E080AC82229B6A8A086E" });
            l.Add(new Item { Name = "Надписи на снаряжении", Optional = true, Flag = "tex", Rel = P("StreamingAssets", "aa", "StandaloneWindows64", "weapons_rl1_frontend_assets_all_99d5735415d5061d0ffa38d12892bc9d.bundle"), Orig = "AED9D0A3CBB9029540B08120FA4AA40B093452C3113FC948B7DD6AFBB7277781", Patch = "gear/weapons_rl1_frontend.zap", New = "0C70D3B1541F9DC09A2DCACD06F37D2CA5256ED5E211507108BC5474B7CE5C51" });
            l.Add(new Item { Name = "Надписи на снаряжении", Optional = true, Flag = "tex", Rel = P("StreamingAssets", "aa", "StandaloneWindows64", "weapons_smg1_frontend_assets_all_ded8f81760745534244632f369a61ebc.bundle"), Orig = "D1644F80842FBB77FCF3CF7B963BC603C2B6A12BBC88588A815468C7E4B2CDD3", Patch = "gear/weapons_smg1_frontend.zap", New = "303ED612D41A427CCC8DC348B7A77FA178DEB419451564456FDB9A1C2AEB59D8" });
            l.Add(new Item { Name = "Надписи на снаряжении", Optional = true, Flag = "tex", Rel = P("StreamingAssets", "aa", "StandaloneWindows64", "weapons_smg1_ingame_assets_all_c43ae58025a5f6acc8d5d6c43157864e.bundle"), Orig = "94B5D2A9E5393979CEED0A3B79DA2CB2F0215019E66F568F49915B3FD71930D3", Patch = "gear/weapons_smg1_ingame.zap", New = "FBED6735F0670EF7B81FC2475C2B9D123ED44AF1037E0F72C81801A45CAD5F9E" });
            l.Add(new Item { Name = "Надписи на снаряжении", Optional = true, Flag = "tex", Rel = P("StreamingAssets", "aa", "StandaloneWindows64", "weapons_sniper1_frontend_assets_all_14e595dcae3c3fca18f69e4f74c39044.bundle"), Orig = "233FC862FE6B12DEA048494B6F54E5A51785DC82B64C99B2E098554ED77D47F3", Patch = "gear/weapons_sniper1_frontend.zap", New = "2DB8606BE0EC5AA2E4EA215E443948C205BC23C6CC82C00CF552DB32953F3523" });
            l.Add(new Item { Name = "Надписи на снаряжении", Optional = true, Flag = "tex", Rel = P("StreamingAssets", "aa", "StandaloneWindows64", "weapons_sniper1_ingame_assets_all_9154e2fa9bdac96c7a5f5813111cb288.bundle"), Orig = "423DB67EA04190ECBC0BB94E2E6A848CB999C21AF9C31797E363BE2B583D8DA0", Patch = "gear/weapons_sniper1_ingame.zap", New = "63615343F4D77C50785C0577110731C85B60D9F9CD55CCCB291BBEF6DCF22C50" });
            l.Add(new Item { Name = "Надписи на снаряжении", Optional = true, Flag = "tex", Rel = P("StreamingAssets", "aa", "StandaloneWindows64", "weapons_turret1_frontend_assets_all_2969ed7d3d0746669ef096e3f9dd5a46.bundle"), Orig = "B5D866483D26F179B1A407C357385943FF8CC39A57E54720596C7E2FE34BF2B0", Patch = "gear/weapons_turret1_frontend.zap", New = "D9A1314D247A83E3941747B551623EE255CD56C4886541B3B12F9D42E5734C1C" });
            l.Add(new Item { Name = "Надписи на снаряжении", Optional = true, Flag = "tex", Rel = P("StreamingAssets", "aa", "StandaloneWindows64", "weapons_turret1_ingame_assets_all_04eb333ae2b1ab360d5112537424cb96.bundle"), Orig = "3EC1A69C60536BBD87D3086AB490C8EDDEB4C2697A0233FD388B0C336E137443", Patch = "gear/weapons_turret1_ingame.zap", New = "972F1E34838AA7A45C55CD22E5BB1855BFBB12D9E22F07A19B81F1A5CA355EEE" });
            l.Add(new Item { Name = "Логотипы и картинки интерфейса", Optional = true, Flag = "logos", Rel = P("StreamingAssets", "aa", "StandaloneWindows64", UI), Orig = "0C4C41366EE5B5CAB30DE761B0D76E1E421A4102095D2A45BB1D11F9D49EFFEE", Patch = "logos.zap", New = "49A853B47A12551CAD7C817405237B0C47F8C4944E4FDA0BB88845116F1F28C8" });
            return l;
        }

        public static string Sha(string p)
        {
            if (!File.Exists(p)) return "";
            using (var s = File.OpenRead(p)) using (var h = SHA256.Create())
                return BitConverter.ToString(h.ComputeHash(s)).Replace("-", "");
        }

        // ---------- game detection
        public static bool IsGame(string p) { return !string.IsNullOrEmpty(p) && File.Exists(P(p, "zombieassault.exe")); }

        public static string FindGame(string near)
        {
            var c = new List<string>();
            if (near != null) { c.Add(near); try { c.Add(Path.GetDirectoryName(near)); } catch { } }
            var steam = new List<string>();
            foreach (var kv in new[] { new[] { "HKCU", @"Software\Valve\Steam", "SteamPath" }, new[] { "HKLM", @"SOFTWARE\WOW6432Node\Valve\Steam", "InstallPath" }, new[] { "HKLM", @"SOFTWARE\Valve\Steam", "InstallPath" } })
            {
                try
                {
                    var root = kv[0] == "HKCU" ? Microsoft.Win32.Registry.CurrentUser : Microsoft.Win32.Registry.LocalMachine;
                    using (var k = root.OpenSubKey(kv[1]))
                        if (k != null && k.GetValue(kv[2]) != null) steam.Add(k.GetValue(kv[2]).ToString().Replace('/', '\\'));
                }
                catch { }
            }
            try { steam.Add(P(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Steam")); } catch { }
            var libs = new List<string>();
            foreach (var s in steam)
            {
                libs.Add(s);
                try
                {
                    var vdf = P(s, "steamapps", "libraryfolders.vdf");
                    if (File.Exists(vdf))
                        foreach (Match m in Regex.Matches(File.ReadAllText(vdf), "\"path\"\\s+\"([^\"]+)\""))
                            libs.Add(m.Groups[1].Value.Replace(@"\\", @"\"));
                }
                catch { }
            }
            try
            {
                foreach (var d in DriveInfo.GetDrives())
                {
                    if (d.DriveType != DriveType.Fixed) continue;
                    foreach (var sub in new[] { "SteamLibrary", "Steam", P("Games", "Steam"), P("Games", "SteamLibrary"), P("Program Files (x86)", "Steam") })
                        libs.Add(P(d.RootDirectory.FullName, sub));
                }
            }
            catch { }
            foreach (var l in libs.Distinct()) c.Add(P(l, "steamapps", "common", "Zombie Assault"));
            foreach (var p in c) if (IsGame(p)) return Path.GetFullPath(p);
            return null;
        }

        // ---------- helpers
        ZipArchive zip;
        ZipArchiveEntry Entry(string name) { return zip.GetEntry(name.Replace('\\', '/')); }

        static void Unprotect(string p) { if (File.Exists(p)) File.SetAttributes(p, FileAttributes.Normal); }
        static void CopyOver(string src, string dst) { Unprotect(dst); File.Copy(src, dst, true); }

        void ExtractTo(ZipArchiveEntry e, string dst)
        {
            Unprotect(dst);
            using (var s = e.Open()) using (var f = File.Create(dst)) s.CopyTo(f);
        }

        void ApplyPatch(string orig, ZipArchiveEntry patch, string outp)
        {
            byte[] o = File.ReadAllBytes(orig);
            using (var ps = patch.Open()) using (var ms = new MemoryStream())
            {
                ps.CopyTo(ms); ms.Position = 0;
                var br = new BinaryReader(ms);
                if (Encoding.ASCII.GetString(br.ReadBytes(4)) != "ZAP1") throw new Exception("повреждённый патч");
                long size = br.ReadInt64(); int n = br.ReadInt32();
                Unprotect(outp);
                using (var fs = File.Create(outp))
                {
                    for (int k = 0; k < n; k++)
                    {
                        if (br.ReadByte() == 0) { long off = br.ReadInt64(); int len = br.ReadInt32(); fs.Write(o, (int)off, len); }
                        else { int len = br.ReadInt32(); byte[] b = br.ReadBytes(len); fs.Write(b, 0, len); }
                    }
                }
                if (new FileInfo(outp).Length != size) throw new Exception("размер не совпал");
            }
        }

        bool RestoreIfOrig(string t, string origSha)
        {
            string bak = t + ".orig";
            if (Sha(bak) == origSha) { CopyOver(bak, t); Unprotect(bak); File.Delete(bak); return true; }
            return Sha(t) == origSha;
        }

        // ---------- install / uninstall
        public bool Install()
        {
            using (var ps = OpenPayload())
            using (zip = new ZipArchive(ps, ZipArchiveMode.Read))
            {
                CleanupStale();
                var items = Items();
                int fail = 0, step = 0, steps = items.Count + 2;
                foreach (var it in items)
                {
                    Progress(++step * 100 / steps);
                    string t = P(Data, it.Rel), bak = t + ".orig";
                    if (it.Optional && !(it.Flag == "tex" ? Textures : Logos))
                    {
                        RestoreIfOrig(t, it.Orig);
                        Log(it.Name + ": пропущено (оригинал)", Kind.Info);
                        continue;
                    }
                    if (!File.Exists(t)) { Log(it.Name + ": файл игры не найден", Kind.Warn); if (it.Required) fail++; continue; }
                    if (Sha(t) == it.Orig) { CopyOver(t, bak); }
                    else if (Sha(bak) != it.Orig)
                    {
                        Log(it.Name + ": файл игры другой версии (игра обновилась?), пропускаю", Kind.Warn);
                        if (it.Required) fail++;
                        continue;
                    }
                    bool ok;
                    try
                    {
                        if (it.Patch != null) { ApplyPatch(bak, Entry(it.Patch), t); ok = Sha(t) == it.New; }
                        else
                        {
                            var e = Entry(it.Src);
                            ExtractTo(e, t);
                            string want; using (var s = e.Open()) using (var h = SHA256.Create()) want = BitConverter.ToString(h.ComputeHash(s)).Replace("-", "");
                            ok = Sha(t) == want;
                        }
                    }
                    catch (Exception ex) { ok = false; Log("   " + ex.Message, Kind.Error); }
                    if (ok) Log(it.Name + ": установлено", Kind.Ok);
                    else
                    {
                        CopyOver(bak, t);
                        Log(it.Name + ": не удалось, возвращён оригинал", Kind.Error);
                        if (it.Required) fail++;
                    }
                }
                Progress(++step * 100 / steps);
                InstallPad();
                UnpackTools();
                Progress(++step * 100 / steps);
                BuildVoice();
                Progress(100);
                return fail == 0;
            }
        }

        // voice kit -> <game>\ZA_Rusifikator\voice (не трогаем уже записанное и отмеченное)
        void UnpackTools()
        {
            int n = 0;
            foreach (var e in zip.Entries)
            {
                if (!e.FullName.StartsWith("voice/") || e.FullName.EndsWith("/")) continue;
                string dst = P(ToolDir, e.FullName.Replace('/', Path.DirectorySeparatorChar));
                bool always = e.FullName == "voice/media.tsv";
                if (File.Exists(dst) && !always) continue;
                Directory.CreateDirectory(Path.GetDirectoryName(dst));
                ExtractTo(e, dst); if (!always) n++;
            }
            if (n > 0) Log("Набор для озвучки распакован: " + P("ZA_Rusifikator", "voice"), Kind.Info);
        }

        public int CountRecordings()
        {
            string rec = P(ToolDir, "voice", "Записи");
            return Directory.Exists(rec) ? Directory.GetFiles(rec, "*.wav", SearchOption.AllDirectories).Length : 0;
        }

        void BuildVoice()
        {
            var recs = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            string recDir = P(ToolDir, "voice", "Записи");
            if (Directory.Exists(recDir))
                foreach (var f in Directory.GetFiles(recDir, "*.wav", SearchOption.AllDirectories)) recs[Path.GetFileName(f)] = f;
            var map = new Dictionary<string, Dictionary<uint, string>>();
            var known = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            string tsv = P(ToolDir, "voice", "media.tsv");
            if (File.Exists(tsv))
                foreach (var line in File.ReadAllLines(tsv, Encoding.UTF8))
                {
                    var f = line.Split('\t'); if (f.Length < 4) continue;
                    known.Add(f[3]);
                    if (!map.ContainsKey(f[0])) map[f[0]] = new Dictionary<uint, string>();
                    if (VoiceTest) map[f[0]][uint.Parse(f[1])] = "<test>";
                    else if (Voice && recs.ContainsKey(f[3])) map[f[0]][uint.Parse(f[1])] = recs[f[3]];
                }
            var unknown = recs.Keys.Where(k => !known.Contains(k)).ToList();
            if (Voice && unknown.Count > 0) Log("Озвучка: файлы с неизвестными именами пропущены: " + string.Join(", ", unknown.Take(10)) + (unknown.Count > 10 ? "…" : ""), Kind.Warn);
            int total = map.Values.Sum(d => d.Count);
            if (total == 0)
            {
                foreach (var b in Banks) RestoreIfOrig(P(Snd, b.Key + ".bnk"), b.Value);
                Log(Voice ? "Озвучка: записей пока нет, остаётся английская" : "Озвучка: оригинальная (английская)", Kind.Info);
                return;
            }
            int ok = 0, err = 0;
            var report = new List<string>();
            try
            {
                foreach (var b in Banks)
                {
                    string t = P(Snd, b.Key + ".bnk"), bak = t + ".orig";
                    if (Sha(t) == b.Value) CopyOver(t, bak);
                    if (Sha(bak) != b.Value) { Log("Озвучка: " + b.Key + ".bnk другой версии, пропускаю", Kind.Warn); continue; }
                    Dictionary<uint, string> d;
                    if (!map.TryGetValue(b.Key, out d)) d = new Dictionary<uint, string>();
                    Log("Озвучка: собираю " + b.Key + " (" + d.Count + " реплик)…", Kind.Info);
                    string tmp = t + ".new";
                    var r = ZaVoice.Bank.Build(bak, tmp, d, 32000, true);
                    Unprotect(t); File.Copy(tmp, t, true); File.Delete(tmp);
                    foreach (var x in r) { report.Add(b.Key + "|" + x); if (x.StartsWith("OK")) ok++; else err++; }
                }
                File.WriteAllLines(P(ToolDir, "voice", "отчёт_сборки.txt"), report, new UTF8Encoding(true));
                if (VoiceTest) Log("ТЕСТ озвучки: все " + ok + " реплик заменены сигналом «бип-бип». Проверьте в игре и потом нажмите «Установить».", Kind.Head);
                else Log("Озвучка: озвучено " + ok + " из " + known.Count + " реплик", Kind.Ok);
                if (err > 0) Log("Озвучка: ошибок " + err + ", подробности в voice\\отчёт_сборки.txt", Kind.Warn);
            }
            catch (Exception ex)
            {
                foreach (var b in Banks) { string t = P(Snd, b.Key + ".bnk"); if (Sha(t + ".orig") == b.Value) CopyOver(t + ".orig", t); }
                Log("Озвучка не собрана: " + ex.Message, Kind.Error);
            }
        }

        // ---------- мод геймпада (version.dll в папке игры)
        string PadDll { get { return P(Game, "version.dll"); } }
        string PadDir { get { return P(ToolDir, "pad"); } }
        static bool IsOurDll(string p)
        {
            try { return File.Exists(p) && Encoding.ASCII.GetString(File.ReadAllBytes(p)).Contains("ZAPad 1."); } catch { return false; }
        }

        static string SetIni(string txt, string sec, string key, string val)
        {
            var m = Regex.Match(txt, @"(?m)^\[" + Regex.Escape(sec) + @"\][^\[]*");
            if (!m.Success) return txt.TrimEnd() + "\r\n\r\n[" + sec + "]\r\n" + key + "=" + val + "\r\n";
            string body = m.Value;
            string nb = Regex.IsMatch(body, @"(?m)^" + key + @"=") ? Regex.Replace(body, @"(?m)^" + key + @"=.*$", key + "=" + val) : body.TrimEnd() + "\r\n" + key + "=" + val + "\r\n\r\n";
            return txt.Substring(0, m.Index) + nb + txt.Substring(m.Index + m.Length);
        }

        void InstallPad()
        {
            if (Pad == "" && Kbd == "" && !Discord && !Dlaa) { RemovePad(false); return; }
            try
            {
                if (File.Exists(PadDll) && !IsOurDll(PadDll))
                {
                    CopyOver(PadDll, PadDll + ".zabak");
                    Log("Найден чужой version.dll, сохранён как version.dll.zabak", Kind.Warn);
                }
                Directory.CreateDirectory(PadDir);
                ExtractTo(Entry("pad/version.dll"), PadDll);
                ExtractTo(Entry("pad/GameInputRedist.dll"), P(PadDir, "GameInputRedist.dll"));
                ExtractTo(Entry("pad/ZASpk.dat"), P(PadDir, "ZASpk.dat"));
                ExtractTo(Entry("pad/ZASfx.dat"), P(PadDir, "ZASfx.dat"));
                try { ExtractTo(Entry("pad/ZAAura.exe"), P(PadDir, "ZAAura.exe")); } catch (IOException) { }   // in use: keep the old copy
                string ini = P(PadDir, "ZAPad.ini");
                if (!File.Exists(ini)) ExtractTo(Entry("pad/ZAPad.ini"), ini);
                string txt = File.ReadAllText(ini);   // UTF-16 with BOM
                txt = SetIni(txt, "Main", "Mode", Pad == "" ? "3" : Pad == "xbox" ? "2" : Pad == "dualsense" ? "1" : "0");
                txt = SetIni(txt, "Keyboard", "Mode", Kbd == "aura" ? "1" : Kbd == "windows" ? "2" : "0");
                txt = SetIni(txt, "Discord", "Enabled", Discord ? "1" : "0");
                txt = SetIni(txt, "DLAA", "Enabled", Dlaa ? "1" : "0");
                if (Dlaa) { try { ExtractTo(Entry("pad/nvngx_dlss.dll"), P(PadDir, "nvngx_dlss.dll")); } catch (IOException) { } }
                File.WriteAllText(ini, txt, Encoding.Unicode);
                if (Pad != "")
                {
                    Log("Мод геймпада: " + (Pad == "xbox" ? "Xbox (вибрация, импульсные триггеры)" : Pad == "dualsense" ? "DualSense (триггеры, HD-вибрация, подсветка, гироскоп, тачпад, рация)" : "DualSense или Xbox, определяется сам") + ", установлен", Kind.Ok);
                    Log("   Настройки: ZA_Rusifikator\\pad\\ZAPad.ini. Steam Input для игры лучше выключить.", Kind.Info);
                }
                if (Dlaa) Log("Сглаживание NVIDIA DLAA (DLSS 4.5): включено. Нужна видеокарта GeForce RTX", Kind.Ok);
                if (Discord) Log("Статус в Discord: персонаж, класс и уровень, включён", Kind.Ok);
                if (Kbd != "") Log("Подсветка клавиатуры: " + (Kbd == "aura" ? "ASUS Aura" : "динамическая подсветка Windows") + ", установлена", Kind.Ok);
            }
            catch (Exception ex) { Log("Мод геймпада не установлен: " + ex.Message, Kind.Error); }
        }

        void RemovePad(bool log)
        {
            try
            {
                bool had = IsOurDll(PadDll);
                if (had) { Unprotect(PadDll); File.Delete(PadDll); }
                if (File.Exists(PadDll + ".zabak") && !File.Exists(PadDll)) { File.Move(PadDll + ".zabak", PadDll); }
                if (had || log) Log("Мод геймпада: удалён", Kind.Ok);
            }
            catch (Exception ex) { Log("Мод геймпада: не удалось удалить version.dll (" + ex.Message + ")", Kind.Warn); }
        }

        // остатки прошлых версий игры: резервная копия бандла перевода со старым именем
        void CleanupStale()
        {
            try
            {
                foreach (var n in LOC_OLD)
                {
                    string old = P(AA, n);
                    if (!File.Exists(old) && File.Exists(old + ".orig")) { Unprotect(old + ".orig"); File.Delete(old + ".orig"); }
                }
            }
            catch { }
        }

        public void Uninstall()
        {
            CleanupStale();
            int i = 0; var items = Items();
            foreach (var it in items)
            {
                Progress(++i * 100 / (items.Count + 1));
                string t = P(Data, it.Rel);
                if (RestoreIfOrig(t, it.Orig)) Log(it.Name + ": оригинал восстановлен", Kind.Ok);
                else Log(it.Name + ": резервной копии нет, восстановите через Steam (Проверить целостность файлов)", Kind.Warn);
            }
            foreach (var b in Banks) RestoreIfOrig(P(Snd, b.Key + ".bnk"), b.Value);
            Log("Озвучка: оригинал восстановлен", Kind.Ok);
            RemovePad(true);
            Progress(100);
        }
    }

}
