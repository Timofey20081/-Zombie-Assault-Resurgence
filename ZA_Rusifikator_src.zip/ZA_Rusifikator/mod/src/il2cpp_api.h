#pragma once
#include <windows.h>
#include <stdint.h>
struct Il2CppDomain; struct Il2CppAssembly; struct Il2CppImage; struct Il2CppClass; struct MethodInfo;
struct FieldInfo; struct Il2CppType; struct Il2CppThread; struct Il2CppObject; struct PropertyInfo;
#define IL2CPP_API_LIST(X) \
 X(Il2CppDomain*, il2cpp_domain_get, ()) \
 X(const Il2CppAssembly**, il2cpp_domain_get_assemblies, (Il2CppDomain*, size_t*)) \
 X(const Il2CppImage*, il2cpp_assembly_get_image, (const Il2CppAssembly*)) \
 X(const char*, il2cpp_image_get_name, (const Il2CppImage*)) \
 X(size_t, il2cpp_image_get_class_count, (const Il2CppImage*)) \
 X(Il2CppClass*, il2cpp_image_get_class, (const Il2CppImage*, size_t)) \
 X(const char*, il2cpp_class_get_name, (Il2CppClass*)) \
 X(const char*, il2cpp_class_get_namespace, (Il2CppClass*)) \
 X(Il2CppClass*, il2cpp_class_get_parent, (Il2CppClass*)) \
 X(const MethodInfo*, il2cpp_class_get_methods, (Il2CppClass*, void**)) \
 X(FieldInfo*, il2cpp_class_get_fields, (Il2CppClass*, void**)) \
 X(Il2CppClass*, il2cpp_class_from_name, (const Il2CppImage*, const char*, const char*)) \
 X(const MethodInfo*, il2cpp_class_get_method_from_name, (Il2CppClass*, const char*, int)) \
 X(FieldInfo*, il2cpp_class_get_field_from_name, (Il2CppClass*, const char*)) \
 X(const char*, il2cpp_method_get_name, (const MethodInfo*)) \
 X(uint32_t, il2cpp_method_get_param_count, (const MethodInfo*)) \
 X(const Il2CppType*, il2cpp_method_get_param, (const MethodInfo*, uint32_t)) \
 X(const char*, il2cpp_method_get_param_name, (const MethodInfo*, uint32_t)) \
 X(const Il2CppType*, il2cpp_method_get_return_type, (const MethodInfo*)) \
 X(uint32_t, il2cpp_method_get_flags, (const MethodInfo*, uint32_t*)) \
 X(char*, il2cpp_type_get_name, (const Il2CppType*)) \
 X(const char*, il2cpp_field_get_name, (FieldInfo*)) \
 X(size_t, il2cpp_field_get_offset, (FieldInfo*)) \
 X(const Il2CppType*, il2cpp_field_get_type, (FieldInfo*)) \
 X(int, il2cpp_field_get_flags, (FieldInfo*)) \
 X(void, il2cpp_field_static_get_value, (FieldInfo*, void*)) \
 X(Il2CppThread*, il2cpp_thread_attach, (Il2CppDomain*)) \
 X(void, il2cpp_free, (void*)) \
 X(Il2CppObject*, il2cpp_string_new, (const char*)) \
 X(Il2CppClass*, il2cpp_object_get_class, (Il2CppObject*)) \
 X(Il2CppClass*, il2cpp_class_from_type, (const Il2CppType*)) \
 X(bool, il2cpp_class_is_assignable_from, (Il2CppClass*, Il2CppClass*)) \
 X(Il2CppObject*, il2cpp_runtime_invoke, (const MethodInfo*, void*, void**, Il2CppObject**)) \
 X(uint32_t, il2cpp_gchandle_new_weakref, (Il2CppObject*, bool)) \
 X(Il2CppObject*, il2cpp_gchandle_get_target, (uint32_t)) \
 X(void, il2cpp_gchandle_free, (uint32_t))
#define DECL(r, n, a) using n##_t = r (*) a; inline n##_t n;
IL2CPP_API_LIST(DECL)
#undef DECL
#define IL2CPP_OPT_LIST(X) \
 X(Il2CppClass*, il2cpp_class_get_declaring_type, (Il2CppClass*)) \
 X(Il2CppClass*, il2cpp_class_get_nested_types, (Il2CppClass*, void**)) \
 X(void*, il2cpp_resolve_icall, (const char*)) \
 X(Il2CppObject*, il2cpp_object_new, (Il2CppClass*)) \
 X(void*, il2cpp_object_unbox, (Il2CppObject*)) \
 X(Il2CppObject*, il2cpp_value_box, (Il2CppClass*, void*)) \
 X(const Il2CppType*, il2cpp_class_get_type, (Il2CppClass*)) \
 X(uint32_t, il2cpp_gchandle_new, (Il2CppObject*, bool)) \
 X(Il2CppClass*, il2cpp_class_get_nested_types_dummy, (void))
#define DECL2(r, n, a) using n##_t = r (*) a; inline n##_t n = nullptr;
IL2CPP_OPT_LIST(DECL2)
#undef DECL2
inline bool LoadIl2cpp(HMODULE ga) {
    bool ok = true;
#define LD2(r, n, a) n = (n##_t)GetProcAddress(ga, #n);
    IL2CPP_OPT_LIST(LD2)
#undef LD2
#define LD(r, n, a) n = (n##_t)GetProcAddress(ga, #n); if (!n) ok = false;
    IL2CPP_API_LIST(LD)
#undef LD
    return ok;
}
inline void* MethodPtr(const MethodInfo* m) { return m ? *(void**)m : nullptr; }
