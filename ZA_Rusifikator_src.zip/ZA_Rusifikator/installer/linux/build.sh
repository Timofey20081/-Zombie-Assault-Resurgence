#!/usr/bin/env bash
# Собирает однофайловый установщик для Linux: install.sh + упакованная папка payload/
# Структура payload/: english/<loc bundle>, portuguese/<loc bundle>, resources.zap, metadata.zap
set -e
cd "$(dirname "$0")"
[ -d payload ] || { echo "Нет папки payload/ (см. README)"; exit 1; }
tar -czf payload.tgz payload
OUT="ZA_Rusifikator_Setup_1.0(Lite)_Linux.sh"
{ cat install.sh; printf '\n__PAYLOAD_BELOW__\n'; cat payload.tgz; } > "$OUT"
chmod +x "$OUT"; rm -f payload.tgz
echo "Готово: $OUT"
