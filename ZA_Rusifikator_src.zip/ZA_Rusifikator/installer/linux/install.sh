#!/usr/bin/env bash
# Русификатор «Зомби-штурм: Пробуждение» 1.0 Lite для Linux / Steam Deck (игра через Proton)
# by MeT1oR & Tianku
set -u
# started by double-click (no terminal): reopen in a terminal window so the questions are visible
if [ ! -t 0 ] && [ -z "${ZA_NOTERM:-}" ] && [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ]; then
  export ZA_NOTERM=1
  for t in konsole gnome-terminal kgx xfce4-terminal mate-terminal lxterminal alacritty kitty xterm; do
    if command -v "$t" >/dev/null 2>&1; then
      case "$t" in gnome-terminal|kgx) exec "$t" -- bash "$0" "$@";; *) exec "$t" -e bash "$0" "$@";; esac
    fi
  done
fi
VER="1.0 Lite"
GAMEBUILD="обновлением от 13 ноября 2026"
LOC="localization_assets_all_fc03e8144bbdc66b764b78538acd9411.bundle"
LOC_SHA="d4dc0cd935001e3389defff281a539c729f43e77ab908ce98023291fb92e56ec"
RES_SHA="d497a04b8f529f4a93554c97d5c42a3a190e642bbc07583d5237380fef80e67f"
RES_NEW="96ce4fcdfbd31c874f0fa457c878c245581353d0e6a8d104ae85c7e673f21141"
MET_SHA="99b59f675d7250668698ce51d49614b065c8fd9f2a8ea1e282c1b6517dda76a4"
MET_NEW="3451baff11b709a2b67024c30b23144eeed90b8f8117ac628089751c3d1fd380"

R=$'\e[31m'; G=$'\e[32m'; Y=$'\e[33m'; B=$'\e[1m'; N=$'\e[0m'
say()  { printf '%s\n' "$*"; }
ok()   { printf '%s  %s%s\n' "$G" "$*" "$N"; }
warn() { printf '%s  %s%s\n' "$Y" "$*" "$N"; }
err()  { printf '%s  %s%s\n' "$R" "$*" "$N"; }
pause(){ if [ -t 0 ]; then read -r -p "Нажмите Enter, чтобы закрыть окно…" _; fi; }
sha()  { [ -f "$1" ] && sha256sum "$1" | cut -d' ' -f1 || echo ""; }

# ---- where the payload is: next to the script, or appended to it (single-file build)
HERE="$(cd "$(dirname "$0")" && pwd)"
PL="$HERE/payload"
if [ ! -d "$PL" ]; then
  TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
  LINE=$(awk '/^__PAYLOAD_BELOW__$/{print NR+1; exit}' "$0")
  if [ -z "$LINE" ]; then err "Не найдены файлы русификатора рядом со скриптом."; pause; exit 1; fi
  tail -n +"$LINE" "$0" | tar -xz -C "$TMP" || { err "Файл повреждён, скачайте русификатор заново."; pause; exit 1; }
  PL="$TMP/payload"
fi

say ""
say "${B}Русификатор «Зомби-штурм: Пробуждение» ${VER} для Linux${N}"
say "Только перевод текста и шрифты с кириллицей, оригинальные названия и логотипы."
say "Для Steam-версии Zombie Assault: Resurgence с ${GAMEBUILD}."
say ""

# ---- find the game
find_game() {
  local roots=() libs=() r f p
  for r in "$HOME/.steam/steam" "$HOME/.steam/root" "$HOME/.local/share/Steam" "$HOME/.var/app/com.valvesoftware.Steam/.local/share/Steam" "$HOME/snap/steam/common/.local/share/Steam"; do
    [ -d "$r" ] && roots+=("$r")
  done
  for r in "${roots[@]}"; do
    libs+=("$r")
    f="$r/steamapps/libraryfolders.vdf"
    if [ -f "$f" ]; then
      while IFS= read -r p; do libs+=("$p"); done < <(grep -oP '"path"\s+"\K[^"]+' "$f" 2>/dev/null)
    fi
  done
  for p in /run/media/*/* /run/media/* /media/*/* /mnt/*; do [ -d "$p/steamapps" ] && libs+=("$p"); done
  for p in "${libs[@]}"; do
    if [ -f "$p/steamapps/common/Zombie Assault/zombieassault.exe" ]; then echo "$p/steamapps/common/Zombie Assault"; return; fi
  done
}
GAME="${ZA_GAME:-$(find_game)}"
if [ -z "$GAME" ] || [ ! -f "$GAME/zombieassault.exe" ]; then
  warn "Игра не найдена автоматически."
  read -r -p "Вставьте путь к папке игры (где лежит zombieassault.exe): " GAME
  GAME="${GAME%/}"
  if [ ! -f "$GAME/zombieassault.exe" ]; then err "В этой папке нет zombieassault.exe."; pause; exit 1; fi
fi
ok "Игра: $GAME"
DATA="$GAME/zombieassault_Data"
T_LOC="$DATA/StreamingAssets/aa/StandaloneWindows64/$LOC"
OLDB="$DATA/StreamingAssets/aa/StandaloneWindows64/localization_assets_all_83cba2f82f55e0748cff4e64852c0669.bundle"
[ ! -f "$OLDB" ] && [ -f "$OLDB.orig" ] && rm -f "$OLDB.orig"
T_RES="$DATA/resources.assets"
T_MET="$DATA/il2cpp_data/Metadata/global-metadata.dat"

if pgrep -fi '([\\/]|^)zombieassault\.exe( |$)' >/dev/null 2>&1; then err "Игра запущена. Закройте её и запустите русификатор снова."; pause; exit 1; fi

restore() { # target origsha
  local t="$1" s="$2"
  if [ "$(sha "$t.orig")" = "$s" ]; then cp -f "$t.orig" "$t" && rm -f "$t.orig"; return 0; fi
  [ "$(sha "$t")" = "$s" ]
}

MODE="${1:-}"
if [ "$MODE" != "--uninstall" ] && [ "$MODE" != "--install" ]; then
  say ""; say "Что сделать?"
  say "  1) Установить русификатор (вместо английского, рекомендуется)"
  say "  2) Установить вместо португальского (английский останется, в игре выбрать Português)"
  say "  3) Удалить русификатор"
  read -r -p "Введите 1, 2 или 3 и нажмите Enter: " ch
  case "$ch" in 1|"") LANG_DIR=english;; 2) LANG_DIR=portuguese;; 3) MODE=--uninstall;; *) err "Не понял ответ."; pause; exit 1;; esac
else LANG_DIR="${ZA_LANG:-english}"; fi

if [ "$MODE" = "--uninstall" ]; then
  say ""
  restore "$T_LOC" "$LOC_SHA" && ok "Тексты: оригинал" || warn "Тексты: другой версии, проверьте целостность файлов в Steam"
  restore "$T_RES" "$RES_SHA" && ok "Шрифт засекреченного текста: оригинал" || warn "resources.assets другой версии"
  restore "$T_MET" "$MET_SHA" && ok "Диалоги: оригинал" || warn "global-metadata.dat другой версии"
  say ""; ok "Русификатор удалён."; pause; exit 0
fi

command -v python3 >/dev/null 2>&1 || { err "Нужен python3 (на Steam Deck он уже есть). Установите его и запустите снова."; pause; exit 1; }
fail=0
backup() { # target origsha -> 0 if ready to write
  local t="$1" s="$2"
  if [ ! -f "$t" ]; then return 1; fi
  if [ "$(sha "$t")" = "$s" ]; then cp -f "$t" "$t.orig"; return 0; fi
  [ "$(sha "$t.orig")" = "$s" ]
}
patch() { # orig zap out
  python3 - "$1" "$2" "$3" <<'PY'
import sys,struct
o=open(sys.argv[1],'rb').read(); p=open(sys.argv[2],'rb').read()
assert p[:4]==b'ZAP1'; size,n=struct.unpack_from('<qi',p,4); i=16; out=bytearray()
for _ in range(n):
    k=p[i]; i+=1
    if k==0: off,ln=struct.unpack_from('<qi',p,i); i+=12; out+=o[off:off+ln]
    else: ln,=struct.unpack_from('<i',p,i); i+=4; out+=p[i:i+ln]; i+=ln
assert len(out)==size; open(sys.argv[3],'wb').write(out)
PY
}
say ""
if backup "$T_LOC" "$LOC_SHA"; then
  cp -f "$PL/$LANG_DIR/$LOC" "$T_LOC" && [ "$(sha "$T_LOC")" = "$(sha "$PL/$LANG_DIR/$LOC")" ] && ok "Тексты и шрифт: установлено" || { cp -f "$T_LOC.orig" "$T_LOC"; err "Тексты: не удалось, возвращён оригинал"; fail=1; }
else err "Тексты: файл игры другой версии (игра обновилась?). Нужна новая версия русификатора."; fail=1; fi
for it in "RES|$T_RES|$RES_SHA|$RES_NEW|resources.zap|Шрифт засекреченного текста" "MET|$T_MET|$MET_SHA|$MET_NEW|metadata.zap|Разделитель в диалогах"; do
  IFS='|' read -r _ t s n z name <<< "$it"
  if backup "$t" "$s"; then
    if patch "$t.orig" "$PL/$z" "$t.new" 2>/dev/null && [ "$(sha "$t.new")" = "$n" ]; then mv -f "$t.new" "$t"; ok "$name: установлено"
    else rm -f "$t.new"; cp -f "$t.orig" "$t"; warn "$name: не удалось, оставлен оригинал"; fi
  else warn "$name: файл игры другой версии, пропускаю"; fi
done
say ""
if [ $fail -eq 0 ]; then
  ok "Готово, игра на русском."
  [ "$LANG_DIR" = portuguese ] && say "  В настройках игры выберите язык Português."
  say "  Удалить: запустите этот файл снова и выберите 3."
  say "  Если Steam обновит игру, перевод может пропасть: скачайте новую версию русификатора."
else err "Установка не завершена. Оригинальные файлы игры не повреждены."; fi
pause; exit $fail
