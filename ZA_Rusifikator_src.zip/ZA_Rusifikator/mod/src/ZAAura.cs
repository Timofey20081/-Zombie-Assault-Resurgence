// ZAAura: drives an ASUS Aura keyboard for ZAPad (the Aura SDK must not be loaded into the game).
// usage: ZAAura.exe <game pid>. Shared memory layout: see kbshm.h
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Text;
using System.Threading;

static class ZAAura
{
    const int Max = 512;
    const int OffReady = 0, OffQuit = 4, OffSeq = 8, OffCount = 12, OffX = 16, OffY = OffX + Max * 4, OffCode = OffY + Max * 4, OffColor = OffCode + Max * 2, OffName = OffColor + Max * 4;
    static StreamWriter log;
    static void L(string s) { try { log.WriteLine(DateTime.Now.ToString("HH:mm:ss.fff ") + s); log.Flush(); } catch { } }

    static dynamic At(dynamic c, int i) { try { return c[i]; } catch { return c.Item(i); } }

    [STAThread]
    static int Main(string[] args)
    {
        string dir = Path.GetDirectoryName(Process.GetCurrentProcess().MainModule.FileName);
        try { log = new StreamWriter(Path.Combine(dir, "ZAAura.log"), true, Encoding.UTF8); } catch { }
        AppDomain.CurrentDomain.UnhandledException += (o, e) => { L("crash: " + e.ExceptionObject); };
        int pid = int.Parse(args[0]);
        Process game;
        try { game = Process.GetProcessById(pid); } catch { L("game process " + pid + " not found"); return 1; }
        MemoryMappedFile mmf;
        try { mmf = MemoryMappedFile.OpenExisting("Local\\ZAKbd_" + pid); } catch (Exception e) { L("no shared memory: " + e.Message); return 4; }
        var v = mmf.CreateViewAccessor();
        dynamic sdk = null, dev = null;
        var lights = new List<dynamic>();
        try
        {
            for (int a = 0; sdk == null; a++)
            {
                try { sdk = Activator.CreateInstance(Type.GetTypeFromProgID("aura.sdk.1")); }
                catch (Exception e) { L("sdk create failed: " + e.Message); if (a >= 10 || game.HasExited) throw; Thread.Sleep(3000); }
            }
            L("sdk created, game pid " + pid);
            dynamic col = null;
            int best = -1, bestKeys = 0;
            for (int t = 0; t < 30 && best < 0; t++)
            {
                if (game.HasExited || v.ReadInt32(OffQuit) != 0) { L("stop while enumerating (game exited: " + game.HasExited + ")"); return 0; }
                int n;
                try { col = sdk.Enumerate(0); n = col.Count; }
                catch (Exception e) { L("enumerate " + t + " failed: " + e.Message); Thread.Sleep(3000); continue; }
                L("enumerate " + t + ": " + n + " devices");
                for (int i = 0; i < n; i++)
                {
                    dynamic d = At(col, i); int keys = 0;
                    try { keys = d.Keys.Count; } catch { }
                    L("  " + d.Name + " type=0x" + ((int)d.Type).ToString("X") + " keys=" + keys);
                    if (keys > bestKeys) { bestKeys = keys; best = i; }
                }
                if (best < 0) Thread.Sleep(2000);
            }
            if (best < 0) { v.Write(OffReady, -1); L("no keyboard"); return 2; }
            sdk.SwitchMode();
            dev = At(col, best);
            float W = Math.Max(1, (int)dev.Width - 1), H = Math.Max(1, (int)dev.Height - 1);
            dynamic ks = dev.Keys; int cnt = 0;
            for (int i = 0; i < (int)ks.Count && cnt < Max; i++)
            {
                dynamic k = At(ks, i); int code = (int)k.Code;
                if (code == 0) continue;
                lights.Add(k);
                v.Write(OffX + cnt * 4, (float)((int)k.X / W)); v.Write(OffY + cnt * 4, (float)((int)k.Y / H)); v.Write(OffCode + cnt * 2, (ushort)code);
                cnt++;
            }
            byte[] nm = Encoding.UTF8.GetBytes((string)dev.Name); int ln = Math.Min(63, nm.Length);
            v.WriteArray(OffName, nm, 0, ln); v.Write(OffName + ln, (byte)0);
            v.Write(OffCount, cnt);
            v.Write(OffReady, 1);
            L("ready: " + dev.Name + ", " + cnt + " keys");
        }
        catch (Exception e) { L("error: " + e.Message); v.Write(OffReady, -1); return 3; }
        var last = new uint[lights.Count];
        for (int i = 0; i < last.Length; i++) last[i] = 0xffffffff;
        int seen = -1; bool applied = false;
        while (!game.HasExited && v.ReadInt32(OffQuit) == 0)
        {
            Thread.Sleep(15);
            int s = v.ReadInt32(OffSeq); if (s == seen) continue; seen = s;
            try
            {
                bool any = false;
                for (int i = 0; i < lights.Count; i++)
                {
                    uint c = v.ReadUInt32(OffColor + i * 4);
                    if (c != last[i]) { last[i] = c; lights[i].Color = c; any = true; }
                }
                if (any) dev.Apply();
                if (!applied) { applied = true; L("first frame applied"); }
            }
            catch (Exception e) { L("lost: " + e.ToString()); break; }
        }
        try { sdk.ReleaseControl(0); } catch { }
        L("exit (game exited: " + game.HasExited + ", quit: " + v.ReadInt32(OffQuit) + ")");
        Process.GetCurrentProcess().Kill();
        return 0;
    }
}
