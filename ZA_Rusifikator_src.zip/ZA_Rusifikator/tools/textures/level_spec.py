EDITS = {}

def sec(x0, y0, x1, y1):
    return dict(box=(x0 + 1, y0 + 1, x1 - 1, y1 - 1), text="СЕКТОР", font="oswald", mode="light", squeeze=0.7, erase="box", pad=1)

EDITS["01200_T_Morlok_Signs_CLR"] = [
    dict(box=(36, 30, 142, 45), text="ТРЕВОГА", font="russo", mode="light"),
    dict(box=(89, 47, 152, 109), text="ПРИ СИГНАЛЕ\nТРЕВОГИ ИДИТЕ\nВ ЗОНУ\nЭВАКУАЦИИ.\n\nЗАЙМИТЕ МЕСТО\nВ ТРАНСПОРТЕ.", font="russo", mode="light", align="l", fit="tight", squeeze=0.5),
    dict(box=(42, 140, 134, 155), text="ВНИМАНИЕ", font="russo", mode="light"),
    dict(box=(90, 158, 153, 219), text="ГРУЗ И\nОБОРУДОВАНИЕ\nХРАНИТЬ\nНА СВОИХ МЕСТАХ.\n\nПРОВЕРЯЙТЕ\nМАРКИРОВКУ.", font="russo", mode="dark", align="l", squeeze=0.5),
    sec(20, 265, 84, 287), sec(96, 265, 160, 287), sec(20, 383, 84, 405), sec(96, 383, 160, 405),
    dict(box=(21, 324, 83, 349), text="ЗАПРЕТНАЯ\nЗОНА", font="oswald", mode="light", gap=0.15, erase="box", pad=1),
    dict(box=(97, 324, 159, 349), text="ЗАПРЕТНАЯ\nЗОНА", font="oswald", mode="light", gap=0.15, erase="box", pad=1),
    dict(box=(21, 444, 83, 469), text="ЗАПРЕТНАЯ\nЗОНА", font="oswald", mode="light", gap=0.15, erase="box", pad=1),
    dict(box=(97, 444, 159, 469), text="ЗАПРЕТНАЯ\nЗОНА", font="oswald", mode="light", gap=0.15, erase="box", pad=1),
    dict(box=(180, 259, 236, 274), text="ОСТОРОЖНО!", font="oswald", mode="light", thr=0.16, erase="box", pad=1),
    dict(box=(181, 331, 235, 362), text="ВЫТЯЖКА", font="oswald", mode="light", thr=0.16, erase="box", pad=1),
]

EDITS["01253_T_AlertSign"] = [
    dict(box=(58, 96, 200, 143), text="ТРЕВОГА", font="oswald", mode="light", erase="box", pad=2),
]
EDITS["01149_T_Into_The_Void_Decals"] = [
    dict(box=(490, 520, 886, 578), text="ОСТОРОЖНО", font="jura", weight=700, mode="alpha", squeeze=0.75),
] + [dict(box=(860, y0, 1148, y0 + 74), text="ДЕЛЬТА", font="oswald", mode="hole", squeeze=0.7, pad=2) for y0 in (992, 1120, 1244)]

def merc_common(k=1.0):
    S = lambda b: tuple(int(round(v * k)) for v in b)
    return [
        dict(box=S((85, 13, 195, 27)), text="БЕРЕГИТЕ ГОЛОВУ", font="russo", mode="alpha"),
        dict(box=S((110, 86, 138, 97)), text="ЗАМОК", font="russo", mode="alpha"),
        dict(box=S((73, 72, 91, 141)), text="ОПАСНО", font="russo", mode="alpha", rot=270),
        dict(box=S((84, 230, 139, 243)), text="ОСТОРОЖНО", font="russo", mode="light", erase="box", pad=1),
        dict(box=S((208, 483, 284, 497)), text="ЭНЕРГОБЛОК", font="russo", mode="dark", erase="box", pad=1),
        dict(box=S((326, 487, 389, 497)), text="ТОЧКА ДОСТУПА", font="russo", mode="dark", erase="box", pad=1),
        dict(box=S((233, 555, 307, 569)), text="ОСТОРОЖНО", font="russo", mode="hole"),
        dict(box=S((506, 6, 584, 23)), text="ЗАХВАТ", font="russo", mode="alpha"),
        dict(box=S((498, 44, 562, 56)), text="НЕ ЗАГРОМОЖДАТЬ", font="russo", mode="alpha"),
    ]

EDITS["01266_T_MercHQDecals"] = merc_common(1.0) + [
    dict(box=(x0 - 4, 876, x1 + 4, 919), inner=(x0, 880, x1, 915), text="ОТСЕК", font="tektur", weight=500, mode="alpha", fit="box", pad=3)
    for x0, x1 in ((95, 215), (300, 435), (535, 665), (765, 885))]

EDITS["01147_T_SnowDecals"] = merc_common(0.5)
EDITS["01270_T_ShipDecals"] = merc_common(0.5)
EDITS["01147_T_SnowDecals"] += [
    dict(box=(11, y0 + 5, 104, y0 + 34), text="БЛОК", font="oswald", mode="hole", squeeze=0.8, pad=1)
    for y0 in (318, 366, 414, 462)] + [
    dict(box=(326, 8, 405, 20), text="ПРОЕКТ", font="jura", weight=600, mode="hole", pad=1, stretch=True),
    dict(box=(326, 20, 405, 38), text="ИМИР", font="jura", weight=600, mode="hole", pad=1, stretch=True),
    dict(box=(419, 8, 498, 20), text="ПРОЕКТ", font="jura", weight=600, mode="hole", pad=1, stretch=True),
    dict(box=(419, 20, 498, 38), text="ИМИР", font="jura", weight=600, mode="hole", pad=1, stretch=True),
]

EDITS["01178_Asteroid_Regen_Decals"] = [
    dict(box=(463, 22, 530, 36), text="ОСТОРОЖНО", font="russo", mode="hole", pad=1),
    dict(box=(548, 22, 678, 48), text="КПП", font="oswald", mode="hole", align="l", pad=1),
    dict(box=(690, 35, 876, 48), text="ТОЛЬКО ДЛЯ ПЕРСОНАЛА", font="russo", mode="alpha"),
    dict(box=(680, 221, 742, 235), text="ОПАСНО", font="russo", mode="alpha"),
    dict(box=(805, 244, 887, 256), text="НЕ ЗАГОРАЖИВАТЬ", font="russo", mode="alpha", rot=180),
    dict(box=(805, 485, 887, 498), text="НЕ ЗАГОРАЖИВАТЬ", font="russo", mode="alpha"),
    dict(box=(715, 330, 730, 410), text="НЕ ЗАГОРАЖИВАТЬ", font="russo", mode="alpha", rot=270),
    dict(box=(962, 332, 976, 410), text="НЕ ЗАГОРАЖИВАТЬ", font="russo", mode="alpha", rot=90),
    dict(box=(630, 376, 693, 385), text="ВНИМАНИЕ", font="russo", mode="light", erase="box", ebox=(629, 375, 694, 386), margin=3),
    dict(box=(628, 389, 694, 407), text="ТОЛЬКО ДЛЯ\nПЕРСОНАЛА", font="russo", mode="dark", erase="box", pad=1, gap=0.2),
    dict(box=(54, 546, 146, 572), text="ЛАБ.", font="tektur", weight=600, mode="alpha", pad=1, margin=0),
    dict(box=(54, 641, 146, 667), text="ЛАБ.", font="tektur", weight=600, mode="alpha", pad=1, margin=0),
    dict(box=(101, 713, 193, 739), text="ЛАБ.", font="tektur", weight=600, mode="alpha", pad=1, margin=0),
    dict(box=(350, 538, 448, 558), text="ЗОНА-01", font="tektur", weight=600, mode="light", erase="box", pad=1),
    dict(box=(463, 538, 565, 558), text="ЗОНА-02", font="tektur", weight=600, mode="light", erase="box", pad=1),
    dict(box=(620, 516, 838, 550), text="КПП 01", font="russo", mode="light", erase="box", pad=1, align="l"),
    dict(box=(873, 768, 937, 784), text="ОСТОРОЖНО", font="russo", mode="alpha", rot=180),
    dict(box=(848, 798, 937, 814), text="НЕ ЗАГОРАЖИВАТЬ", font="russo", mode="alpha", rot=180),
    dict(box=(850, 930, 937, 946), text="ОСТОРОЖНО", font="russo", mode="alpha", rot=180),
]

def L(box, text, font="russo", **k):
    d = dict(box=box, text=text, font=font, mode="light", erase="box", pad=1); d.update(k); return d
def A(box, text, font="russo", **k):
    d = dict(box=box, text=text, font=font, mode="alpha"); d.update(k); return d

EDITS["01152_T_CityDecals"] = [
    L((712, 36, 813, 57), "РАЙОН", "tektur", weight=600, fill="inpaint"),
    L((459, 166, 563, 187), "РАЙОН", "tektur", weight=600, fill="inpaint"),
    L((712, 166, 813, 187), "РАЙОН", "tektur", weight=600, fill="inpaint"),
    A((427, 350, 523, 372), "РАЙОН", "tektur", weight=600, pad=2),
    A((577, 350, 673, 372), "РАЙОН", "tektur", weight=600, pad=2),
    A((724, 350, 821, 372), "РАЙОН", "tektur", weight=600, pad=2),
    L((450, 15, 486, 38), "ВХОД", "tektur", weight=600, squeeze=0.5, fill="inpaint", mode="dark"),
    L((428, 92, 516, 114), "ЗАПРЕЩЁН", "tektur", weight=600, fill="inpaint"),
    dict(box=(30, 450, 102, 464), text="ОПАСНО", font="russo", mode="dark", erase="box", pad=1),
    dict(box=(30, 464, 102, 480), text="НЕ ВХОДИТЬ", font="russo", mode="dark", erase="box", pad=1),
    dict(box=(126, 450, 195, 464), text="ОСТОРОЖНО", font="russo", mode="dark", erase="box", pad=1),
    dict(box=(126, 464, 195, 492), text="ТОЛЬКО\nПО ПРОПУСКУ", font="russo", mode="dark", erase="box", pad=1, gap=0.2),
    dict(box=(310, 453, 405, 464), text="ВЫСОКОЕ НАПРЯЖЕНИЕ", font="russo", mode="dark", erase="box", pad=1, margin=3, color=(30, 26, 16)),
    dict(box=(321, 482, 389, 493), text="ОСТОРОЖНО", font="russo", mode="dark", erase="box", pad=1, margin=3, color=(30, 26, 16)),
    A((350, 655, 645, 705), "ВОССТАНЬ!", "/home/claude/work/tex/fonts/RubikWetPaint.ttf", pad=3),
    A((765, 540, 865, 625), "БОРИСЬ\nЗА\nПРАВОЕ\nДЕЛО", "/home/claude/work/tex/fonts/RubikWetPaint.ttf", pad=3, gap=0.3),
    A((750, 440, 875, 525), "ОТКРОЙ\nСВОИ\nГЛАЗА", "/home/claude/work/tex/fonts/RubikWetPaint.ttf", pad=3, gap=0.3),
    A((705, 645, 920, 670), "ВЕРНИ СВОЁ", "/home/claude/work/tex/fonts/RubikWetPaint.ttf", pad=3),
    A((32, 260, 133, 275), "ОСТОРОЖНО, ЗАЗОР", "russo", pad=1),
    L((436, 749, 619, 778), "СЭНДВИЧИ", "russo"),
    L((621, 745, 719, 778), "ДЕСЕРТЫ\nИ ЗАКУСКИ", "russo", gap=0.15),
    L((486, 807, 714, 835), "СВЕЖИЕ ПРОДУКТЫ", "russo"),
    L((676, 869, 804, 893), "ЭКОПРОДУКТЫ", "russo"),
    L((309, 915, 415, 936), "КАССА", "russo", align="l"),
    L((177, 949, 285, 973), "КАССА", "russo"),
]

EDITS["00761_T_Morlok_Signs_and_Decals_Colour"] = [
    dict(box=(154, 225, 222, 238), text="ОСТОРОЖНО", font="russo", mode="hole", pad=1),
    dict(box=(44, 351, 144, 363), text="ЗАПРЕТНАЯ ЗОНА", font="russo", mode="dark", erase="box", pad=1, margin=3, color=(30, 26, 16)),
    dict(box=(3, 368, 107, 387), text="УР. 02", font="tektur", weight=500, mode="alpha", pad=2, align="l"),
]
EDITS["01211_T_Terraforming_Decals"] = [
    dict(box=(1703, 55, 1830, 98), text="АЛЬФА", font="tektur", weight=500, mode="dark", erase="box", pad=2, fill="inpaint"),
    dict(box=(1185, 676, 1238, 700), text="ВЕНТ.", font="russo", mode="alpha", pad=1),
]
EDITS["01269_T_Posters_01"] = [
    dict(box=(255, 460, 388, 491), text="Добро пожаловать", font="russo", mode="light", erase="box", pad=2, fill="inpaint"),
]
EDITS["00900_T_Drone_Mission_Decals"] = [
    dict(box=(204, 395, 226, 495), text="НЕ ОСТАНАВЛИВАТЬСЯ", font="russo", mode="alpha", rot=90, pad=1),
    dict(box=(204, 762, 226, 865), text="НЕ ОСТАНАВЛИВАТЬСЯ", font="russo", mode="alpha", rot=90, pad=1),
]
