"""Put out/var/<variant>.xml into the localisation bundles (out/v4/<variant>/<lang>/...bundle, used as templates)."""
import UnityPy, sys
W = "/home/claude/work"; BN = "localization_assets_all_fc03e8144bbdc66b764b78538acd9411.bundle"
for v in sys.argv[1:] or ("author_ru", "author_en", "exact_ru", "exact_en"):
    text = open(f"{W}/out/var/{v}.xml", encoding="utf-8").read()
    for lang in ("english", "portuguese"):
        p = f"{W}/out/v4/{v}/{lang}/{BN}"
        env = UnityPy.load(p)
        for o in env.objects:
            if o.type.name == "TextAsset":
                t = o.read_typetree()
                if t["m_Name"].lower() == lang: t["m_Script"] = text; o.save_typetree(t); break
        else: raise SystemExit("no " + lang)
        data = env.file.save(packer="lz4"); open(p, "wb").write(data); print(v, lang, len(data))
