// Forwarding stubs for version.dll (the real one is loaded from System32).
#pragma once
#include <windows.h>
static HMODULE g_realVersion;
static FARPROC RV(const char* n) {
    if (!g_realVersion) {
        wchar_t p[MAX_PATH]; GetSystemDirectoryW(p, MAX_PATH); lstrcatW(p, L"\\version.dll");
        g_realVersion = LoadLibraryW(p);
    }
    return g_realVersion ? GetProcAddress(g_realVersion, n) : nullptr;
}
#define FWD(ret, name, params, args) \
    __pragma(comment(linker, "/export:" #name "=Px_" #name)) \
    extern "C" ret WINAPI Px_##name params { \
        using Fn_t = ret (WINAPI*) params; static Fn_t fp_ = (Fn_t)RV(#name); return fp_ ? fp_ args : (ret)0; }
FWD(BOOL, GetFileVersionInfoA, (LPCSTR a, DWORD b, DWORD c, LPVOID d), (a, b, c, d))
FWD(BOOL, GetFileVersionInfoW, (LPCWSTR a, DWORD b, DWORD c, LPVOID d), (a, b, c, d))
FWD(BOOL, GetFileVersionInfoExA, (DWORD f0, LPCSTR a, DWORD b, DWORD c, LPVOID d), (f0, a, b, c, d))
FWD(BOOL, GetFileVersionInfoExW, (DWORD f0, LPCWSTR a, DWORD b, DWORD c, LPVOID d), (f0, a, b, c, d))
FWD(DWORD, GetFileVersionInfoSizeA, (LPCSTR a, LPDWORD b), (a, b))
FWD(DWORD, GetFileVersionInfoSizeW, (LPCWSTR a, LPDWORD b), (a, b))
FWD(DWORD, GetFileVersionInfoSizeExA, (DWORD f0, LPCSTR a, LPDWORD b), (f0, a, b))
FWD(DWORD, GetFileVersionInfoSizeExW, (DWORD f0, LPCWSTR a, LPDWORD b), (f0, a, b))
FWD(BOOL, GetFileVersionInfoByHandle, (DWORD a, HANDLE b, LPVOID c, DWORD d), (a, b, c, d))
FWD(DWORD, VerFindFileA, (DWORD a, LPCSTR b, LPCSTR c, LPCSTR d, LPSTR e, PUINT f6, LPSTR g, PUINT h), (a, b, c, d, e, f6, g, h))
FWD(DWORD, VerFindFileW, (DWORD a, LPCWSTR b, LPCWSTR c, LPCWSTR d, LPWSTR e, PUINT f6, LPWSTR g, PUINT h), (a, b, c, d, e, f6, g, h))
FWD(DWORD, VerInstallFileA, (DWORD a, LPCSTR b, LPCSTR c, LPCSTR d, LPCSTR e, LPCSTR f6, LPSTR g, PUINT h), (a, b, c, d, e, f6, g, h))
FWD(DWORD, VerInstallFileW, (DWORD a, LPCWSTR b, LPCWSTR c, LPCWSTR d, LPCWSTR e, LPCWSTR f6, LPWSTR g, PUINT h), (a, b, c, d, e, f6, g, h))
FWD(DWORD, VerLanguageNameA, (DWORD a, LPSTR b, DWORD c), (a, b, c))
FWD(DWORD, VerLanguageNameW, (DWORD a, LPWSTR b, DWORD c), (a, b, c))
FWD(BOOL, VerQueryValueA, (LPCVOID a, LPCSTR b, LPVOID* c, PUINT d), (a, b, c, d))
FWD(BOOL, VerQueryValueW, (LPCVOID a, LPCWSTR b, LPVOID* c, PUINT d), (a, b, c, d))
