"""Build the 4 translation variants.

  author_ru : ru -> lit -> adapt (author's version, Russian names)       = current build
  author_en : author's text, company/product names back to English
  exact_en  : literal base layer (ru_*), English names, + required fixes
  exact_ru  : literal base layer with Russian names (forms taken from the author's text)

usage: za_variants.py OUTDIR   -> OUTDIR/<variant>.xml (+ .tsv dump)
"""
import glob, json, re, sys, os
sys.path.insert(0, os.path.dirname(__file__))
import za_build as B

W = "/home/claude/work/tr"
def load(pat):
    d = {}
    for f in sorted(glob.glob(f"{W}/{pat}")):
        for l in open(f, encoding="utf-8"):
            l = l.rstrip("\n")
            if "\t" in l:
                k, v = l.split("\t", 1); d[k] = v.replace("¶", "\n")
    return d

base = load("ru_*.tsv"); lit = load("lit_*.tsv"); ad = load("adapt_*.tsv")
fin = dict(base); fin.update(lit); fin.update(ad)
en = B.en

# ---------------------------------------------------------------- name table
# (english, russian nominative, quoted?)
NAMES = [
    ("Rubicon Industries", "Рубикон Индастриз", False),
    ("Rubicon", "Рубикон", True), ("Morlok", "Морлок", True), ("Ronson", "Ронсон", True),
    ("HIKS", "ХИКС", True), ("Shotlite", "Шотлайт", True), ("Teknoboom", "Технобах", True),
    ("Rancor", "Дикие", True), ("SmokeStack", "Завеса", True), ("Atomic", "Атом", True),
    ("Spaceskin", "Бронесфера", True), ("Critical Mass", "Критмасса", True),
    ("Shiplite", "Шиплайт", True), ("Regen", "Феникс", True),
    ("Kevlar 5", "Кевлар-5", True), ("Exo Plating", "Экзоброня", True), ("Mammoth", "Мамонт", True),
    ("Gorgon", "Горгона", True), ("R-Warden", "Огнестраж", True), ("Arctic", "Арктика", True),
    ("Nanoribbon", "Нанолента", True), ("Atlas", "Атлант", True), ("Hawkmoth", "Бражник", True),
    ("HVM", "ВСБ", False), ("U.S.I.", "С.О.С.", False), ("USI", "СОС", False), ("IRBM", "БРСД", False),
    ("Horizon Medical", "Горизонт-Мед", False), ("Jinsoku", "Дзинсоку", False),
    ("Delrose", "Дельроуз", False), ("Lakatan", "Лакатан", False),
    ("United Systems Initiative", "Союз Объединённых Систем", False),
]
EN_ALIASES = {"SmokeStack": ["Smoke Stack", "Smokestack", "SmokeStack"], "Regen": ["Regen", "REGEN"],
              "Kevlar 5": ["Kevlar 5", "Kevlar5"]}
NAME_KEY = re.compile(r"^(Manufacturer_|CharacterName_\w*Vendor$|CharacterName_USIRep$|Bounty_\w*_Provider$|Armor_\w+_(Helmet|Vest|Gloves|Pants|Boots)$|Location_Trusgan_RegenFacility$)|_[Nn]ame$")
NAME_KEY_EXCL = re.compile(r"^(Store_Upgrade_|ChooseYourName|RandomName|MenuGameEnd_)")

# weapon/turret/product names from the name keys: english -> russian nominative
for k, v in ad.items():
    if re.search(r"_[Nn]ame$", k) and not NAME_KEY_EXCL.match(k) and re.search("[А-Яа-я]", v) and k in en:
        NAMES.append((en[k], v, True))

def stem(w):
    return w if len(w) <= 3 else w[: max(2, len(w) - 2)]

def match_quoted(q):
    """quoted russian phrase -> english name or None (handles inflection)."""
    best, bl = None, 0
    ws = q.split()
    for e, r, quoted in NAMES:
        rw = r.split()
        if not quoted or len(rw) != len(ws):
            continue
        ok = all(a.lower().startswith(stem(b).lower()) and len(a) <= len(b) + 3 for a, b in zip(ws, rw))
        if ok and len(r) > bl:
            best, bl = e, len(r)
    if best and q.isupper():
        best = best.upper()
    return best

def to_english_names(k, v):
    if NAME_KEY.search(k) and not NAME_KEY_EXCL.match(k):
        return base.get(k)            # literal layer keeps english names (None -> stays english)
    def rq(m):
        e = match_quoted(m.group(1))
        return e if e else m.group(0)
    v = re.sub(r"«([^«»]{1,40})»", rq, v)
    v = re.sub(r"(Инициатив|Союз)[а-яё]* Объединённых Систем", "United Systems Initiative", v)
    for e, r, quoted in NAMES:
        if not quoted and e != "United Systems Initiative":
            v = re.sub(r"(?<![А-Яа-яЁё.])" + re.escape(r) + r"(?![А-Яа-яЁё])", e, v)
    v = v.replace("НТУ USI", "Департамент науки и техники USI")
    return v

COMPANIES = {"Rubicon", "Morlok", "Ronson", "HIKS", "Shotlite", "Teknoboom", "Rancor", "SmokeStack", "Atomic",
             "Spaceskin", "Critical Mass", "Shiplite", "Regen"}
PREP = {"с": "ablt", "со": "ablt", "в": "loct", "во": "loct", "на": "loct", "о": "loct", "об": "loct", "при": "loct",
        "из": "gent", "от": "gent", "у": "gent", "для": "gent", "без": "gent", "до": "gent", "из-за": "gent",
        "после": "gent", "около": "gent", "среди": "gent", "против": "gent", "кроме": "gent", "вокруг": "gent",
        "к": "datv", "ко": "datv", "по": "datv", "благодаря": "datv",
        "за": "ablt", "под": "ablt", "над": "ablt", "перед": "ablt", "между": "ablt"}
GENERIC = ("компани", "корпораци", "концерн", "фирм", "брон", "технологи", "серии", "сери", "марк", "бренд", "линейк")
GENERIC_REGEN = GENERIC + ("комплекс",)
def decline(word, case):
    if case == "nomn": return word
    head, sep, last = word.rpartition("-")
    pre = head + sep
    if last.isupper():                    # abbreviations (ХИКС, ВСБ) stay as they are
        return word
    if last == "Дикие":
        return {"gent": "Диких", "datv": "Диким", "ablt": "Дикими", "loct": "Диких"}[case]
    if last[-1] in "аАя":
        st = last[:-1]
        end = {"gent": "ы" if st[-1] not in "кгхжшщчКГХ" else "и", "datv": "е", "ablt": "ой", "loct": "е"}[case]
        return pre + st + end
    if last[-1].isalpha() and last[-1].lower() not in "аеёиоуыэюяь5":
        end = {"gent": "а", "datv": "у", "ablt": "ом", "loct": "е"}[case]
        return pre + last + end
    return word

def guess_case(text, pos, company, regen=False):
    left = re.sub(r"<[^<>]+>|\[/?[a-z]+\]", " ", text[:pos])
    if re.search(r"[.!?:;—,(«\n]\s*$", left) or not left.strip():
        return "nomn"
    if company and re.search(r"[A-Za-z&]+\s*$", left):
        return "gent"
    m = re.search(r"([А-Яа-яЁё-]+)[ ]*$", left)
    if not m:
        return "nomn"
    w = m.group(1).lower()
    if w in PREP: return PREP[w]
    if not company: return "nomn"
    if w.startswith(GENERIC_REGEN if regen else GENERIC): return "nomn"
    if w in ("пор", "однако", "тем", "затем"): return "nomn"
    p = MORPH.parse(w)[0]
    if p.tag.POS in ("NOUN",) : return "gent"
    return "nomn"

import pymorphy3
MORPH = pymorphy3.MorphAnalyzer()
CASE_LOG = []
def to_russian_names(k, v):
    if NAME_KEY.search(k) and not NAME_KEY_EXCL.match(k) and k in fin:
        return fin[k]
    pats = []
    for e, r, quoted in NAMES:
        for a in EN_ALIASES.get(e, [e]):
            pats.append((a, e, r, quoted))
    pats.sort(key=lambda x: -len(x[0]))
    rx = re.compile("|".join(r"«?(?<![A-Za-z])" + re.escape(a) + r"(?![A-Za-z])»?" for a, *_ in pats))
    lut = {a: (e, r, q) for a, e, r, q in pats}
    def rep(m):
        a = m.group(0).strip("«»")
        e, r, quoted = lut[a]
        before, after = v[:m.start()], v[m.end():]
        if re.search(r"[A-Za-z0-9][ -]?$", before) and not re.search(r"[А-Яа-я]", before[-3:]) and e not in COMPANIES:
            return m.group(0)
        if re.match(r"[ -]?([A-Za-z]|\d)", after) and not re.match(r" (\\\\|\{)", after):
            return m.group(0)
        if not quoted:
            return r
        c = guess_case(v, m.start(), e in COMPANIES, e == "Regen")
        w = r if " " in r else decline(r, c)
        if a.isupper() and len(a) > 4: w = w.upper()
        CASE_LOG.append((k, a, c, w))
        if c == "nomn":
            AGREE.append((k, w))
        return "«" + w + "»"
    v = agree(rx.sub(rep, v))
    for a, b in FIXUPS:
        v = v.replace(a, b)
    return v

FIXUPS = [("[r]в «Фениксе»[/r]", "[r]в «Феникс»[/r]"), ("выпущенная «Технобах»", "выпущенная «Технобахом»"),
          ("выпущенный «Критмасса»", "выпущенный «Критмассой»"), ("созданных «Феникс»", "созданных «Фениксом»"),
          ("Принадлежащая «Феникс»", "Принадлежащая «Фениксу»"), ("поможете «Морлок»", "поможете «Морлоку»"),
          ("сторону «Гальванизатор»", "сторону «Гальванизатора»"), ("проектов «Завеса»", "проектов «Завесы»"),
          ("комплексов «Морлок»", "комплексов «Морлока»"), ("R&D «Завеса»", "R&D «Завесы»"),
          ("ТЕРРАФОРМИРОВАНИЯ «ФЕНИКСА»", "ТЕРРАФОРМИРОВАНИЯ «ФЕНИКС»")]

AGREE = []
GENDER = {"Дикие": "plur", "Завеса": "femn", "Критмасса": "femn", "Бронесфера": "femn", "Горгона": "femn",
          "Арктика": "femn", "Нанолента": "femn", "Экзоброня": "femn"}
def agree(v):
    """«Морлок» забыла -> «Морлок» забыл: fix past-tense verbs right after a nominative name."""
    def fix(m):
        name, gap, verb = m.group(1), m.group(2), m.group(3)
        g = GENDER.get(name, "masc")
        if " " in name or "-" in name and name not in ("Ствол-Лайт", "Корабел-Лайт"):
            pass
        for p in MORPH.parse(verb):
            if p.tag.POS == "VERB" and "past" in p.tag:
                cur = "plur" if "plur" in p.tag else str(p.tag.gender)
                if cur == g: return m.group(0)
                tgt = p.inflect({"plur"} if g == "plur" else {"sing", g})
                if tgt:
                    w = tgt.word
                    if verb[0].isupper(): w = w.capitalize()
                    return "«" + name + "»" + gap + w
                break
        return m.group(0)
    return re.sub(r"«([^«»]+)»((?:\s+[а-яё]+){0,2}?\s+)([а-яё]+(?:ла|ли|ло|л|лся|лась|лись)(?:сь|ся)?)\b", fix, v)

# ---------------------------------------------------------------- exact layer
FIX_KEYS = ["Equipment_WeaponCategory_SMG", "Equipment_WeaponCategory_SMG_Category",
            "Equipment_Stat_MovementSpeedEquipped", "Equipment_Stat_MovementSpeedFiring",
            "BonusStat_EquippedMovementReductionMultiplier", "BonusStat_FiringMovementReductionMultiplier"]
exact = dict(base)
for k in list(lit) + list(ad):            # strings that only exist in later layers (new game strings, separators)
    if k not in base and not (NAME_KEY.search(k) and not NAME_KEY_EXCL.match(k)) and k in en:
        exact[k] = ad.get(k, lit.get(k))
for k in FIX_KEYS:
    if k in ad: exact[k] = ad[k]

variants = {
    "author_ru": dict(fin),
    "author_en": {k: x for k, v in fin.items() if (x := to_english_names(k, v)) is not None},
    "exact_en": dict(exact),
    "exact_ru": {k: to_russian_names(k, v) for k, v in exact.items()},
}
# descriptions whose Russian-name edits live in adapt_002 (manual review): the English-names variant keeps the earlier text
_pre = dict(base); _pre.update(lit)
for _f in sorted(glob.glob(f"{W}/adapt_*.tsv")):
    if not _f.endswith("adapt_002.tsv"):
        for _l in open(_f, encoding="utf-8"):
            _l = _l.rstrip("\n")
            if "\t" in _l: _k, _v = _l.split("\t", 1); _pre[_k] = _v.replace("¶", "\n")
NAMEDESC = {"CMPolaris_desc", "HIKSG44_desc", "CMPulsar_desc", "HIKSGG44_desc", "ShotliteShiden_desc", "RubiconStrike_desc", "RubiconShard_desc",
            "CMPlanetRaider_desc", "HIKSM890_desc", "TeknoboomVernichter_desc", "RubiconRIA T35 Scorch_desc", "TeknoboomEnergiewerfer_desc",
            "HVMMPG_desc", "Grenade_Flashbang_desc", "Turret_HeavyshotGuardian_desc", "Turret_RubiconTower_desc"}
for k in NAMEDESC:
    if k in _pre and (x := to_english_names(k, _pre[k])) is not None:
        variants["author_en"][k] = x
for k, v in fin.items():                  # russian-named keys missing from the literal layer
    if NAME_KEY.search(k) and not NAME_KEY_EXCL.match(k):
        variants["exact_ru"].setdefault(k, v)

if __name__ == "__main__":
    out = sys.argv[1]; os.makedirs(out, exist_ok=True)
    for name, d in variants.items():
        where = {k: name for k in d}
        errs = B.check(d, where)
        n = B.build(d, f"{out}/{name}.xml")
        with open(f"{out}/{name}.tsv", "w", encoding="utf-8") as fo:
            for k in en:
                if k in d: fo.write(k + "\t" + d[k].replace("\n", "¶") + "\n")
        print(name, "entries", len(d), "replaced", n, "errors", errs)
